# OSIRIS Phase 2 — Ubuntu Acceptance Testing & Source Bundle Guide
**Digital Forensics Platform Verification, Service Lifecycle & Integrity Documentation**

---

## 1. Executive Summary & Purpose

This acceptance source bundle contains the complete, production-tested **OSIRIS Phase 2** digital forensics and incident reconstruction platform. It captures the exact working state of the `phase-2` branch (HEAD `6323d24412a2e9b2fe87d90ce9495f1c2fc5bd4d`) including:
- **36 Modified Tracked Files**: Core platform enhancements across FastAPI routes, database layer, P0 security hardening, real-time WebSocket telemetry, frontend views, and comprehensive unit/integration test suites.
- **Untracked Production Extensions**: Real-time event IPC broadcast, WebSocket endpoint, collector supervisor daemon, host management, frontend router and inspector views, deployment systemd units, service management scripts, and dedicated test suites.
- **Automated Test Validation**: 1,613 passing automated tests (1,636 total tests) covering all backend services, automatic host registration, detection rules, database migrations, WebSocket streams, UI contracts, deployment ownership, and runtime directory isolation (with 23 Linux collector skips on non-Linux platforms).
- **Zero Sensitive Data or Cache Contamination**: All `.env` credential files, `.git` metadata, virtual environments (`.venv`), Python bytecode caches (`__pycache__`), test caches (`.pytest_cache`), local logs, and OS-specific files (`.DS_Store`) have been strictly excluded.

---

## 2. Archive Verification

Before extracting, verify the integrity of the downloaded archive using SHA-256:

```bash
# Verify archive integrity
sha256sum -c OSIRIS_phase2_acceptance_bundle.sha256
```

Expected output:
```text
OSIRIS_phase2_acceptance_bundle.tar.gz: OK
```

---

## 3. Deployment Path & Extraction Setup

The OSIRIS systemd service units and standard configuration expect the platform to be deployed at:
`/opt/osiris`

> [!WARNING]
> **Safety Guard — Do Not Overwrite Existing Installations:**
> Prior to extraction or directory creation, you MUST check whether `/opt/osiris` already exists. If `/opt/osiris` is already present on the target host, do NOT overwrite it. Back up or rename the existing checkout first, or select an alternative isolated review directory.

```bash
# 1. Verify destination path does not already exist
if [ -d "/opt/osiris" ]; then
    echo "ERROR: /opt/osiris already exists. Aborting extraction to prevent overwriting an existing checkout."
    echo "Please inspect, backup, or remove the existing directory before proceeding."
    exit 1
fi

# 2. Create target deployment directory
sudo mkdir -p /opt/osiris

# 3. Extract bundle preserving permissions and directory hierarchy
sudo tar -xzf OSIRIS_phase2_acceptance_bundle.tar.gz -C /opt/osiris

# 4. Enter directory
cd /opt/osiris

# 5. Verify full file manifest integrity
sha256sum -c MANIFEST.txt
```

Every constituent file will report `OK`, verifying that no corruption or alteration occurred during packaging or transfer.

---

## 4. Ubuntu Environment Prerequisites & Installation

The OSIRIS platform is tested and fully supported on **Ubuntu 22.04 LTS** and **Ubuntu 24.04 LTS**.

### Step 4.1: Install System Packages
```bash
sudo apt update
sudo apt install -y \
    python3 \
    python3-venv \
    python3-pip \
    postgresql \
    postgresql-contrib \
    libpq-dev \
    nodejs \
    curl \
    openssl
```

> [!NOTE]
> `nodejs` is required to run frontend contract syntax validation tests (`node --check`). If `nodejs` is not installed, the test suite will cleanly skip JavaScript syntax checks with an informative notice.

### Step 4.2: Create Dedicated Service User & Establish Privilege Separation
```bash
# Create dedicated unprivileged system user and group for OSIRIS services
id -u osiris >/dev/null 2>&1 || sudo useradd -r -s /usr/sbin/nologin -U osiris

# Establish root-owned deployment model: root executes collectors, osiris runs backend
# Application source, executable dependencies, and configuration MUST NOT be writable by backend
sudo chown -R root:osiris /opt/osiris
sudo find /opt/osiris -type d -exec chmod 0750 {} +
sudo find /opt/osiris -type f -exec chmod 0640 {} +
sudo chmod 0750 /opt/osiris/scripts/*.sh /opt/osiris/scripts/*.py
```

### Step 4.3: Set Up Python Virtual Environment
```bash
# Create dedicated root-owned virtual environment within /opt/osiris
sudo python3 -m venv /opt/osiris/.venv

# Install all core & development dependencies as root
sudo /opt/osiris/.venv/bin/pip install --upgrade pip
sudo /opt/osiris/.venv/bin/pip install -r /opt/osiris/requirements.txt
sudo /opt/osiris/.venv/bin/pip install -r /opt/osiris/requirements-dev.txt

# Secure virtual environment: owned by root:osiris, not writable by backend user
sudo chown -R root:osiris /opt/osiris/.venv
sudo find /opt/osiris/.venv -type d -exec chmod 0750 {} +
sudo find /opt/osiris/.venv -type f -exec chmod 0640 {} +
sudo chmod -R 0750 /opt/osiris/.venv/bin
```

### Step 4.4: Configure Environment Variables

> [!IMPORTANT]
> **Reviewing `.env.example` & Secrets Requirement:**
> The `.env.example` file in the repository contains placeholder default values (e.g., `CHANGE-ME-IN-PRODUCTION` and generic connection strings) intended solely as a structural reference.
> - **Do NOT copy `.env.example` directly into production or acceptance testing without modifying it.**
> - **Never use weak, hardcoded passwords** (such as `osiris` or `password`).
> - **Always generate strong, random secrets** for both the database role and `OSIRIS_SECRET_KEY`.
> - In production mode (`OSIRIS_DEBUG=false`), `backend/main.py` enforces `validate_secret_key()` and will fail fast at startup if `OSIRIS_SECRET_KEY` is trivial, missing, or matches insecure templates.

Create your customized `.env` configuration:

```bash
# 1. Generate strong cryptographic secrets
APP_SECRET="$(openssl rand -hex 32)"
DB_PASSWORD="$(openssl rand -hex 24)"

# 2. Define acceptance database credentials (dedicated disposable database and role)
ACCEPTANCE_DB_USER="osiris_acceptance_app"
ACCEPTANCE_DB_NAME="osiris_acceptance_phase2"

# 3. Create .env with genuine generated values
sudo tee /opt/osiris/.env > /dev/null <<EOF
# OSIRIS Acceptance Environment Configuration
OSIRIS_DATABASE_URL=postgresql://${ACCEPTANCE_DB_USER}:${DB_PASSWORD}@localhost:5432/${ACCEPTANCE_DB_NAME}
OSIRIS_SECRET_KEY=${APP_SECRET}
OSIRIS_DEBUG=false
OSIRIS_HOST_ID=ubuntu-acceptance-host
OSIRIS_CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000
EOF

# Ensure secure file ownership and permissions on .env (root:osiris mode 0640)
# Backend and collector can read it; backend user CANNOT modify it.
sudo chown root:osiris /opt/osiris/.env
sudo chmod 0640 /opt/osiris/.env
```

---

## 5. Database Setup & Alembic Migrations

> [!CRITICAL]
> **Database Isolation & Safety Boundaries:**
> - The existing databases `osiris`, `osiris_phase2_review`, `osiris_phase2_demo`, and all other validation/production databases **MUST REMAIN UNTOUCHED**.
> - Never assume that a database named `osiris` can be created, dropped, or modified.
> - Acceptance testing requires a **separately named, dedicated disposable database** (e.g. `osiris_acceptance_phase2`) and a dedicated **least-privilege application role** (e.g. `osiris_acceptance_app`).
> - The application role must have only standard privileges on its own database (`NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT`).

### Step 5.1: Create Dedicated Least-Privilege Role & Acceptance Database
```bash
# Start and enable PostgreSQL service
sudo systemctl enable --now postgresql

# Provision the dedicated role and disposable acceptance database using the secrets defined above:
sudo -u postgres psql <<EOF
-- Create unprivileged application role
CREATE ROLE ${ACCEPTANCE_DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD}' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;

-- Create disposable acceptance database owned by that role
CREATE DATABASE ${ACCEPTANCE_DB_NAME} OWNER ${ACCEPTANCE_DB_USER};

-- Grant least-privilege permissions on public schema
\c ${ACCEPTANCE_DB_NAME}
GRANT ALL ON SCHEMA public TO ${ACCEPTANCE_DB_USER};
EOF
```

### Step 5.2: Apply Canonical Alembic Migrations
Run schema migrations against the newly created acceptance database:
```bash
source .venv/bin/activate
alembic upgrade head
```
This applies revisions 0001 through 0008 sequentially, creating all required tables, indexes, constraints, and initial schema states.

### Step 5.3: Automatic Host Registration vs. Optional Seed Execution

#### Automatic Host Registration on First Startup (Live Operation)
OSIRIS implements **automatic, idempotent local-host registration**:
- When the collector starts up (via `systemd` unit `osiris-collector.service`, `python -m collectors.supervisor --watch`, or `python -m collectors.runner`), it derives the exact canonical host UUID from the configured `OSIRIS_HOST_ID` (e.g. `ubuntu-acceptance-host`) using `resolve_host_uuid()`.
- Before the first collection cycle persists Linux users, processes, events, resource snapshots, or filesystem inventory records, the orchestrator verifies whether the corresponding `Host` record exists in the database.
- If it does not exist, the collector automatically registers the host using its canonical UUID, populates `hostname` from `OSIRIS_HOSTNAME` or the system hostname (`socket.gethostname()`), populates `os_info` from `/etc/os-release`, and leaves `ip_address` as `None` (no fabricated IPs).
- Concurrent startup and repeated cycles are strictly concurrency-safe and idempotent. Existing valid administrator-maintained metadata is always preserved.
- Consequently, **database seeding is NOT required for live collection**. All foreign key dependencies (`Event.host_id`, `Process.host_id`, `LinuxUser.host_id`, `File.host_id`, `ResourceSnapshot.host_id`) are satisfied dynamically on a completely fresh database.

#### Optional Demonstration Seed Execution
> [!CAUTION]
> Seeding is an **explicit, optional action** intended **ONLY for demonstration sample data** and Phase 1 baseline inspection.
> **Never run seeds against shared, existing, or production databases.**

If you wish to populate additional synthetic sample entities for offline demo/inspection:
```bash
# Optional: Seed synthetic sample demonstration data into the disposable database ONLY
python -m database.seeds.seed_phase1
```


---

## 6. Running the Automated Test Suite

OSIRIS includes a specialized, cross-platform test runner designed specifically for Ubuntu test isolation:

```bash
# Activate virtual environment
source .venv/bin/activate

# Export test configuration
export OSIRIS_DEBUG=true
export OSIRIS_SECRET_KEY="acceptance-testing-key-32chars-minimum-length"

# Run complete test suite
python scripts/run_tests.py -v
```

### Why `scripts/run_tests.py` is Required on Ubuntu:
The OSIRIS File Integrity Monitoring (FIM) subsystem intentionally excludes volatile temporary directories (`/tmp*` and `/var/tmp*`) as a core security baseline to prevent alert fatigue. On Linux (including Ubuntu), standard `pytest` creates temporary test directories under `/tmp/pytest-of-<user>/`, which the production scanner correctly excludes.

`scripts/run_tests.py` automatically allocates an isolated, unique temporary directory under `~/.osiris_test_tmp/run_<pid>_<uuid>/`, passes it via pytest's `--basetemp` flag, and safely cleans up only its own temporary directory upon exit.

### Expected Test Results:
- **Total collected test cases**: 1,636 (including 23 dedicated automatic host registration & empty-db persistence integration tests, 21 dedicated deployment ownership, write-protection, and runtime directory isolation tests, 33 dedicated IPC security & permission tests, 96 configuration and preflight validation tests, and 7 CORS tests)
- **Passing tests**: 1,613 (on Darwin/macOS) to 1,636 (on Linux/Ubuntu where Linux-specific kernel collectors are active).
- **Hardened test suite**: 1,613 passed, 23 skipped on host; 1,588+ passed in clean bundle extraction without pre-configured database.
- **Skipped tests on Darwin**: 23 (11 Linux-only kernel collectors like inotify, /proc, and 12 live PostgreSQL integration tests when PostgreSQL service is not configured).
- **Execution time**: ~3 minutes.


---

## 7. Service Deployment & Systemd Lifecycle Safety

The acceptance bundle includes production-grade systemd units located in `deployment/systemd/` and an automated service management utility in `scripts/osiris-service.sh`.

### Unit Files & Lifecycle Architecture:
1. `deployment/systemd/osiris-backend.service`: Runs the FastAPI ASGI server (`0.0.0.0:8000`) as `User=osiris`, `Group=osiris`. Loads mandatory `/opt/osiris/.env` (`EnvironmentFile=/opt/osiris/.env`), executes fail-closed preflight configuration validation (`scripts/validate_deployment_env.py`) and database readiness checks (`scripts/wait_for_db.py`). Hosts the Unix domain socket bridge (`/run/osiris/osiris_ipc.sock`, mode 0660). Synchronized with `osiris.target` via `PartOf=osiris.target`.
2. `deployment/systemd/osiris-collector.service`: Runs the unified Collector Supervisor (`collectors/supervisor.py --watch`) as `User=root`, `Group=osiris`. Loads mandatory `/opt/osiris/.env` (`EnvironmentFile=/opt/osiris/.env`), executes fail-closed preflight configuration validation (`scripts/validate_deployment_env.py`) and database readiness checks (`scripts/wait_for_db.py`). Enforces PID locking in a dedicated root-owned directory (`/run/osiris-collector/osiris_collector_supervisor.pid`) and health status reporting (`/run/osiris-collector/osiris_collector_health.json`). Synchronized with `osiris.target` via `PartOf=osiris.target`.
3. `deployment/systemd/osiris.target`: Synchronizes the lifecycle of backend and collector into a single atomic target unit.

### Systemd Safety & Process Isolation Details:
- **Mandatory Environment & Fail-Closed Preflight Validation**:
  - Both `osiris-backend.service` and `osiris-collector.service` require `/opt/osiris/.env` (optional `-` prefix removed). Systemd will immediately refuse startup if `.env` is absent.
  - Both services execute `scripts/validate_deployment_env.py` as an `ExecStartPre` step, enforcing:
    - Regular file verification (symlinks strictly rejected).
    - Restrictive permissions (mode `0600` or `0640`; world and group write bits rejected).
    - Expected ownership (service user `osiris` or `root`).
    - Explicit `OSIRIS_DEBUG=false` required for deployment.
    - Explicit, cryptographically strong `OSIRIS_SECRET_KEY` (minimum 32 characters, no placeholders).
    - Explicit `OSIRIS_DATABASE_URL` with non-default credentials and dedicated database name (default `osiris:osiris` credentials and protected database names `osiris`, `osiris_phase2_review`, `osiris_phase2_demo`, and validation databases strictly rejected).
    - Masking of all passwords and secrets in logs and diagnostic outputs.
  - The default connection URL pointing to `osiris` has been removed from `backend/config.py` to prevent silent fallback.
- **Dependency Ordering**: `postgresql.service` -> `osiris-backend.service` -> `osiris-collector.service` -> `osiris.target`. Backend starts after database readiness is confirmed; collector starts after backend.
- **Synchronized Shutdown & Restart (`PartOf=osiris.target`)**: Stopping or restarting `osiris.target` automatically propagates stop and restart signals to both services.
- **Separated Protected Runtime Directories**:
  - **Root Collector Runtime Directory (`/run/osiris-collector`)**:
    - Configured with `RuntimeDirectory=osiris-collector`, `RuntimeDirectoryMode=0755`, `User=root`, `Group=osiris`, `UMask=0022`, and `RuntimeDirectoryPreserve=yes`.
    - Mode 0755 prevents group write access, guaranteeing that the unprivileged backend user `osiris` cannot unlink, replace, or tamper with the collector supervisor's PID lock file (`osiris_collector_supervisor.pid`).
    - Backend user `osiris` retains read-only access to `/run/osiris-collector/osiris_collector_health.json` (mode 0644) for status monitoring.
  - **OSIRIS Backend IPC Runtime Directory (`/run/osiris`)**:
    - Configured with `RuntimeDirectory=osiris`, `RuntimeDirectoryMode=0775`, `User=osiris`, `Group=osiris`.
    - Unix domain socket (`/run/osiris/osiris_ipc.sock`) is created with mode `0660` (restricted to OSIRIS backend and collector service identities; world-readable/writable permissions are strictly removed).
    - Enforces Linux `SO_PEERCRED` caller verification fail-closed: failure to obtain credentials rejects the connection immediately.
    - Message size bounds (64 KB max), token-bucket rate-limiting (200 msgs/sec), and authoritative health hydration rejecting untrusted heartbeat injection.
    - Development environments fall back to a private per-instance directory with mode `0700` (`/tmp/osiris_<uid>_<hash>/`). The insecure shared `/tmp/osiris_ipc.sock` fallback is removed.
- **CORS Security Configuration**:
  - Configurable explicit allowed origins via `OSIRIS_CORS_ALLOWED_ORIGINS` (defaults to local development origins `localhost`, `127.0.0.1` on ports 8000, 3000, 5173).
  - Unrestricted wildcard (`"*"`) with credentialed CORS is strictly prohibited and rejected on startup in production mode (`debug=False`).
- **Collector Shutdown & PID Locking**:
  - Single-instance enforcement via `PIDLock` using `O_NOFOLLOW` and `flock(LOCK_EX | LOCK_NB)`.
  - Clean shutdown on `SIGTERM` via `KillMode=mixed` and `TimeoutStopSec=15s`: the supervisor cleanly shuts down collector loops, writes terminal health status, releases the PID lock, and exits with code 0 before timeout.
- **Isolation Scope**:
  - The backend runs under a dedicated unprivileged user (`osiris`).
  - The collector runs as `root` (with group `osiris`), which is required for inotify monitoring across system paths, `/proc` telemetry inspection, and reading system auth logs.
  - We do not claim kernel namespace sandboxing (`ProtectSystem`, `PrivateTmp`, etc.) since unit files use standard process and user privilege separation rather than systemd containerization namespaces.

### Step 7.1: Automated Installation via `scripts/osiris-service.sh`
```bash
# Install unit files to /etc/systemd/system/, provision system user, and enable target
sudo ./scripts/osiris-service.sh install
```

### Step 7.2: Platform Lifecycle Commands
The script provides safe, non-destructive platform operations:
- When systemd units are installed, `scripts/osiris-service.sh` uses `systemctl` exclusively.
- It does **NOT** issue broad `pkill` commands against arbitrary process patterns.
- It does not fall through into manual process termination when systemd is active.
- In development/fallback mode, it uses dedicated PID files, validates process identity and ownership, and only deletes PID files after shutdown is verified.

```bash
# Start all OSIRIS services
sudo ./scripts/osiris-service.sh start

# Check complete platform status (target, backend, collector, database readiness, collector health)
./scripts/osiris-service.sh status

# Restart platform services cleanly
sudo ./scripts/osiris-service.sh restart

# Cleanly stop platform services
sudo ./scripts/osiris-service.sh stop
```

### Step 7.3: Running in User-Space (Development Mode)
Alternatively, you may run the platform services directly in foreground terminal sessions for development or review:

```bash
# Terminal 1: Backend API & Web Dashboard
source .venv/bin/activate
uvicorn backend.main:app --host 0.0.0.0 --port 8000

# Terminal 2: Collector Supervisor
source .venv/bin/activate
python -m collectors.supervisor --watch
```

Navigate your browser to `http://<server-ip>:8000` to access the OSIRIS dashboard.

---

## 8. Directory Structure & File Manifest Summary

```text
/opt/osiris/
├── alembic.ini                   # Alembic database migration configuration
├── backend/                      # Central FastAPI application server
│   ├── api/                      # REST routes, schemas, and WebSocket endpoint
│   ├── config.py                 # Pydantic v2 application settings
│   ├── db/                       # SQLAlchemy declarative models and session factory
│   └── services/                 # Detection, FIM, Incidents, Snapshots, Timeline, Workspace
├── collectors/                   # Unified collector daemon, orchestrator, and collectors
│   ├── filesystem/               # Inotify filesystem monitor
│   ├── process/                  # /proc process telemetry collector
│   ├── resource/                 # System CPU/Memory/Disk telemetry collector
│   ├── syslog/                   # Auth/Syslog parser and collector
│   └── supervisor.py             # Multi-collector daemon with PID locking
├── database/                     # Database migrations (0001-0008) and seed scripts
├── deployment/systemd/           # Systemd unit files (backend, collector, target)
├── docs/                         # Architecture, database design, demo guide, service mgmt
├── frontend/                     # SPA dashboard (HTML shell, CSS styles, JS views)
├── pyproject.toml                # Project metadata and test configuration
├── README.md                     # Main project overview and architecture documentation
├── README_ACCEPTANCE.md          # This acceptance guide
├── requirements.txt              # Core runtime dependencies
├── requirements-dev.txt          # Development, linting, and testing dependencies
├── scripts/                      # Service management, test runner, wait_for_db, preflight validator, agent enrollment
├── tests/                        # 1,611 automated unit, integration, and contract tests
├── walkthrough.md                # Demonstration and validation walkthrough
└── MANIFEST.txt                  # Complete SHA-256 checksum manifest of all included files
```

---

## 9. Security & Cleanliness Guarantee

This acceptance source bundle has been generated with strict adherence to security boundaries:
- **No Credentials**: No `.env`, secret keys, or live tokens are included.
- **No Git Metadata**: `.git` repository histories, hooks, and refs are excluded.
- **No Machine Artifacts**: macOS `.DS_Store` files and runtime PID/log files are excluded.
- **No Pre-compiled Caches**: Virtual environments (`.venv`), Python bytecode (`__pycache__`, `*.pyc`), and test caches (`.pytest_cache`) are excluded.
