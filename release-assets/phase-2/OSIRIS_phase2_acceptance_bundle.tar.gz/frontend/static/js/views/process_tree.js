/**
 * OSIRIS Unified Digital Forensics Platform - Interactive Process Tree Controller
 *
 * Responsibilities:
 * - Scoped to active host.
 * - Reconstructs hierarchical parent-child process tree (PID -> PPID).
 * - Collapsible branches, command execution inspection, user identity mapping.
 * - Forensics pivots: Pivot to Timeline, Pivot to Session, Pin to Evidence.
 */

(function (window) {
  'use strict';

  var container = null;
  var treeContainer = null;
  var emptyStateEl = null;
  var errorBoxEl = null;
  var processMap = {};
  var childrenMap = {};
  var rootPids = [];

  function init() {
    container = document.getElementById('view-process-tree');
    if (!container) {
      return;
    }
    treeContainer = document.getElementById('process-tree-content');
    emptyStateEl = document.getElementById('process-tree-empty-state');
    errorBoxEl = document.getElementById('process-tree-error-box');

    var refreshBtn = document.getElementById('process-tree-refresh-btn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        loadProcessTree();
      });
    }

    var searchInput = document.getElementById('process-tree-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', function () {
        filterTree(searchInput.value.trim().toLowerCase());
      });
    }
  }

  function loadProcessTree() {
    if (!container) {
      return;
    }
    if (errorBoxEl) {
      errorBoxEl.classList.add('hidden');
      errorBoxEl.textContent = '';
    }

    if (!window.OsirisApi || !window.OsirisApi.getToken()) {
      return;
    }

    var hostId = window.OsirisApi.getActiveHostId();
    var params = { limit: 100 };
    if (hostId) {
      params.host_id = hostId;
    }

    window.OsirisApi.getProcesses(params)
      .then(function (res) {
        var items = (res && res.items) ? res.items : (Array.isArray(res) ? res : []);
        buildTree(items);
        renderTree();
      })
      .catch(function (err) {
        if (errorBoxEl) {
          errorBoxEl.textContent = 'Failed to load process tree: ' + (err.message || 'Network error');
          errorBoxEl.classList.remove('hidden');
        }
      });
  }

  function buildTree(processes) {
    processMap = {};
    childrenMap = {};
    rootPids = [];

    processes.forEach(function (p) {
      processMap[p.pid] = p;
      childrenMap[p.pid] = [];
    });

    processes.forEach(function (p) {
      var ppid = p.ppid;
      if (ppid !== null && ppid !== undefined && processMap[ppid] && ppid !== p.pid) {
        childrenMap[ppid].push(p.pid);
      } else {
        rootPids.push(p.pid);
      }
    });
  }

  function createTreeNode(pid, depth) {
    var p = processMap[pid];
    if (!p) {
      return null;
    }

    var li = document.createElement('li');
    li.className = 'tree-node';
    li.setAttribute('data-pid', String(pid));

    var row = document.createElement('div');
    row.className = 'tree-row';
    if (depth > 0) {
      row.style.paddingLeft = (depth * 24) + 'px';
    }

    // Toggle icon if has children
    var children = childrenMap[pid] || [];
    var toggle = document.createElement('span');
    toggle.className = 'tree-toggle ' + (children.length > 0 ? 'has-children' : 'leaf');
    toggle.textContent = children.length > 0 ? '▾' : '•';
    row.appendChild(toggle);

    // PID badge
    var pidBadge = document.createElement('span');
    pidBadge.className = 'badge badge-secondary mono-token';
    pidBadge.textContent = 'PID ' + p.pid;
    row.appendChild(pidBadge);

    // Process Name / Executable
    var execSpan = document.createElement('span');
    execSpan.className = 'tree-exec';
    execSpan.textContent = p.executable || p.command || 'unknown';
    row.appendChild(execSpan);

    // Command line preview
    var cmdSpan = document.createElement('span');
    cmdSpan.className = 'tree-cmd cell-muted';
    cmdSpan.textContent = p.command || '';
    row.appendChild(cmdSpan);

    // User badge
    if (p.username) {
      var userBadge = document.createElement('span');
      userBadge.className = 'badge badge-secondary cell-sm';
      userBadge.textContent = p.username;
      row.appendChild(userBadge);
    }

    // Inspect button
    var inspectBtn = document.createElement('button');
    inspectBtn.className = 'btn btn-outline btn-xs tree-action-btn';
    inspectBtn.type = 'button';
    inspectBtn.textContent = 'Inspect';
    inspectBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (window.OsirisInspector) {
        window.OsirisInspector.inspect('Process', (p.executable || p.command) + ' (PID ' + p.pid + ')', p);
      }
    });
    row.appendChild(inspectBtn);

    // Pivot to Timeline
    var tlBtn = document.createElement('button');
    tlBtn.className = 'btn btn-outline btn-xs tree-action-btn';
    tlBtn.type = 'button';
    tlBtn.textContent = 'Timeline';
    tlBtn.title = 'Pivot to Forensic Timeline';
    tlBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (window.OsirisRouter) {
        window.OsirisRouter.navigate('timeline', { process_id: p.id, pid: p.pid });
      }
    });
    row.appendChild(tlBtn);

    // Pivot to Session
    var sessBtn = document.createElement('button');
    sessBtn.className = 'btn btn-outline btn-xs tree-action-btn';
    sessBtn.type = 'button';
    sessBtn.textContent = 'Sessions';
    sessBtn.title = 'Pivot to User Sessions';
    sessBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (window.OsirisRouter) {
        window.OsirisRouter.navigate('sessions', { host_id: p.host_id });
      }
    });
    row.appendChild(sessBtn);

    li.appendChild(row);

    // Render children recursively
    if (children.length > 0) {
      var ul = document.createElement('ul');
      ul.className = 'tree-children';
      children.forEach(function (childPid) {
        var childNode = createTreeNode(childPid, depth + 1);
        if (childNode) {
          ul.appendChild(childNode);
        }
      });
      li.appendChild(ul);

      // Click row to toggle branch
      toggle.addEventListener('click', function (e) {
        e.stopPropagation();
        var isCollapsed = ul.classList.toggle('collapsed');
        toggle.textContent = isCollapsed ? '▸' : '▾';
      });
    }

    return li;
  }

  function renderTree() {
    if (!treeContainer) {
      return;
    }

    while (treeContainer.firstChild) {
      treeContainer.removeChild(treeContainer.firstChild);
    }

    if (rootPids.length === 0) {
      if (emptyStateEl) {
        emptyStateEl.classList.remove('hidden');
      }
      return;
    }

    if (emptyStateEl) {
      emptyStateEl.classList.add('hidden');
    }

    var ul = document.createElement('ul');
    ul.className = 'tree-root';

    rootPids.forEach(function (rootPid) {
      var node = createTreeNode(rootPid, 0);
      if (node) {
        ul.appendChild(node);
      }
    });

    treeContainer.appendChild(ul);
  }

  function filterTree(query) {
    if (!treeContainer) {
      return;
    }
    var nodes = treeContainer.querySelectorAll('.tree-node');
    nodes.forEach(function (n) {
      var text = (n.textContent || '').toLowerCase();
      if (!query || text.indexOf(query) !== -1) {
        n.classList.remove('hidden');
      } else {
        n.classList.add('hidden');
      }
    });
  }

  function resetState() {
    processMap = {};
    childrenMap = {};
    rootPids = [];
    if (treeContainer) {
      while (treeContainer.firstChild) {
        treeContainer.removeChild(treeContainer.firstChild);
      }
    }
  }

  window.OsirisProcessTree = Object.freeze({
    init: init,
    loadProcessTree: loadProcessTree,
    resetState: resetState,
  });

})(typeof window !== 'undefined' ? window : this);
