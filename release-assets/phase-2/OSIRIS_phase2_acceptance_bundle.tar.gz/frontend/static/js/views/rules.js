/**
 * OSIRIS Unified Digital Forensics Platform - Detection Rules Controller
 *
 * Responsibilities:
 * - Render detection rules catalog from /api/detections/rules.
 * - Severity filters and status toggles.
 * - Rule condition inspection drawer.
 */

(function (window) {
  'use strict';

  var container = null;
  var rulesTableBody = null;
  var emptyStateEl = null;
  var errorBoxEl = null;
  var rulesList = [];

  function init() {
    container = document.getElementById('view-detection-rules');
    if (!container) {
      return;
    }
    rulesTableBody = document.getElementById('rules-tbody');
    emptyStateEl = document.getElementById('rules-empty-state');
    errorBoxEl = document.getElementById('rules-error-box');

    var refreshBtn = document.getElementById('rules-refresh-btn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        loadRules();
      });
    }

    var filterCategory = document.getElementById('filter-rule-category');
    if (filterCategory) {
      filterCategory.addEventListener('change', function () {
        renderRules();
      });
    }

    var filterSeverity = document.getElementById('filter-rule-severity');
    if (filterSeverity) {
      filterSeverity.addEventListener('change', function () {
        renderRules();
      });
    }
  }

  function loadRules() {
    if (!container) {
      return;
    }
    if (errorBoxEl) {
      errorBoxEl.classList.add('hidden');
      errorBoxEl.textContent = '';
    }

    if (!window.OsirisApi || !window.OsirisApi.getToken()) {
      return;
    }

    window.OsirisApi.getDetectionRules()
      .then(function (rules) {
        rulesList = Array.isArray(rules) ? rules : [];
        renderRules();
      })
      .catch(function (err) {
        if (errorBoxEl) {
          errorBoxEl.textContent = 'Failed to load detection rules: ' + (err.message || 'Network error');
          errorBoxEl.classList.remove('hidden');
        }
      });
  }

  function renderRules() {
    if (!rulesTableBody) {
      return;
    }

    while (rulesTableBody.firstChild) {
      rulesTableBody.removeChild(rulesTableBody.firstChild);
    }

    var filterCat = document.getElementById('filter-rule-category');
    var catVal = filterCat ? filterCat.value : '';

    var filterSev = document.getElementById('filter-rule-severity');
    var sevVal = filterSev ? filterSev.value : '';

    var filtered = rulesList.filter(function (r) {
      if (catVal && r.category !== catVal) {
        return false;
      }
      if (sevVal && r.severity !== sevVal) {
        return false;
      }
      return true;
    });

    if (emptyStateEl) {
      if (filtered.length === 0) {
        emptyStateEl.classList.remove('hidden');
      } else {
        emptyStateEl.classList.add('hidden');
      }
    }

    filtered.forEach(function (rule) {
      var tr = document.createElement('tr');
      tr.className = 'rule-row';

      // Rule ID
      var tdId = document.createElement('td');
      var code = document.createElement('code');
      code.className = 'code-token';
      code.textContent = rule.rule_id || rule.id || '';
      tdId.appendChild(code);
      tr.appendChild(tdId);

      // Name & Description
      var tdName = document.createElement('td');
      var nameEl = document.createElement('div');
      nameEl.className = 'cell-strong';
      nameEl.textContent = rule.name || '';
      var descEl = document.createElement('div');
      descEl.className = 'cell-muted cell-sm';
      descEl.textContent = rule.description || '';
      tdName.appendChild(nameEl);
      tdName.appendChild(descEl);
      tr.appendChild(tdName);

      // Category
      var tdCat = document.createElement('td');
      var catBadge = document.createElement('span');
      catBadge.className = 'badge badge-secondary';
      catBadge.textContent = rule.category || 'general';
      tdCat.appendChild(catBadge);
      tr.appendChild(tdCat);

      // Severity
      var tdSev = document.createElement('td');
      var sevBadge = document.createElement('span');
      var sevClass = 'badge-secondary';
      if (rule.severity === 'critical') sevClass = 'badge-critical';
      else if (rule.severity === 'high') sevClass = 'badge-danger';
      else if (rule.severity === 'medium') sevClass = 'badge-warning';
      else if (rule.severity === 'low') sevClass = 'badge-info';
      sevBadge.className = 'badge ' + sevClass;
      sevBadge.textContent = (rule.severity || 'info').toUpperCase();
      tdSev.appendChild(sevBadge);
      tr.appendChild(tdSev);

      // Status
      var tdStatus = document.createElement('td');
      var statusBadge = document.createElement('span');
      statusBadge.className = rule.enabled ? 'badge badge-success' : 'badge badge-secondary';
      statusBadge.textContent = rule.enabled ? 'ENABLED' : 'DISABLED';
      tdStatus.appendChild(statusBadge);
      tr.appendChild(tdStatus);

      // Action
      var tdAction = document.createElement('td');
      var viewBtn = document.createElement('button');
      viewBtn.className = 'btn btn-outline btn-sm';
      viewBtn.textContent = 'Inspect';
      viewBtn.type = 'button';
      viewBtn.addEventListener('click', function () {
        if (window.OsirisInspector) {
          window.OsirisInspector.inspect('Rule', rule.rule_id || rule.name, rule);
        }
      });
      tdAction.appendChild(viewBtn);
      tr.appendChild(tdAction);

      rulesTableBody.appendChild(tr);
    });
  }

  function resetState() {
    rulesList = [];
    if (rulesTableBody) {
      while (rulesTableBody.firstChild) {
        rulesTableBody.removeChild(rulesTableBody.firstChild);
      }
    }
  }

  window.OsirisRules = Object.freeze({
    init: init,
    loadRules: loadRules,
    resetState: resetState,
  });

})(typeof window !== 'undefined' ? window : this);
