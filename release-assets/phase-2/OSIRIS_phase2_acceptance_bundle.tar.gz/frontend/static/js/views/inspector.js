/**
 * OSIRIS Unified Digital Forensics Platform - Reusable Slide-over Inspector Drawer
 *
 * Responsibilities:
 * - Unified forensic inspection of Events, Processes, Detections, Hosts, Files, Sessions, Rules.
 * - Formatted key-value property grid (never raw unformatted JSON dump).
 * - Contextual investigation action pivots (Pivot to Process Tree, Timeline, Session, Evidence).
 */

(function (window) {
  'use strict';

  var drawerEl = null;
  var titleEl = null;
  var badgeEl = null;
  var bodyEl = null;
  var actionsEl = null;
  var closeBtn = null;

  function init() {
    drawerEl = document.getElementById('inspector-drawer');
    if (!drawerEl) {
      return;
    }
    titleEl = document.getElementById('inspector-title');
    badgeEl = document.getElementById('inspector-type-badge');
    bodyEl = document.getElementById('inspector-body');
    actionsEl = document.getElementById('inspector-actions');
    closeBtn = document.getElementById('inspector-close-btn');

    if (closeBtn) {
      closeBtn.addEventListener('click', close);
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && drawerEl && !drawerEl.classList.contains('hidden')) {
        close();
      }
    });
  }

  function open() {
    if (drawerEl) {
      drawerEl.classList.remove('hidden');
    }
  }

  function close() {
    if (drawerEl) {
      drawerEl.classList.add('hidden');
    }
  }

  function inspect(entityType, entityTitle, entityData) {
    if (!drawerEl || !bodyEl) {
      return;
    }

    if (titleEl) {
      titleEl.textContent = entityTitle || 'Entity Details';
    }
    if (badgeEl) {
      badgeEl.textContent = (entityType || 'ENTITY').toUpperCase();
    }

    while (bodyEl.firstChild) {
      bodyEl.removeChild(bodyEl.firstChild);
    }
    if (actionsEl) {
      while (actionsEl.firstChild) {
        actionsEl.removeChild(actionsEl.firstChild);
      }
    }

    // Render key-value property table
    var propsTable = document.createElement('div');
    propsTable.className = 'inspector-props-table';

    if (entityData && typeof entityData === 'object') {
      Object.keys(entityData).forEach(function (key) {
        var val = entityData[key];
        if (key === 'payload' && typeof val === 'object' && val !== null) {
          // Render payload sub-properties
          var subHeader = document.createElement('div');
          subHeader.className = 'inspector-section-header';
          subHeader.textContent = 'Payload Telemetry';
          propsTable.appendChild(subHeader);

          Object.keys(val).forEach(function (subKey) {
            var subVal = val[subKey];
            propsTable.appendChild(createPropertyRow(subKey, subVal));
          });
        } else {
          propsTable.appendChild(createPropertyRow(key, val));
        }
      });
    }

    bodyEl.appendChild(propsTable);

    // Render investigation action pivots
    if (actionsEl) {
      renderActions(entityType, entityData);
    }

    open();
  }

  function createPropertyRow(key, val) {
    var row = document.createElement('div');
    row.className = 'inspector-prop-row';

    var keyCol = document.createElement('span');
    keyCol.className = 'inspector-prop-key';
    keyCol.textContent = key;
    row.appendChild(keyCol);

    var valCol = document.createElement('span');
    valCol.className = 'inspector-prop-val';

    if (val === null || val === undefined) {
      valCol.className += ' text-muted';
      valCol.textContent = 'None';
    } else if (typeof val === 'boolean') {
      valCol.textContent = val ? 'true' : 'false';
    } else if (typeof val === 'object') {
      valCol.textContent = JSON.stringify(val);
    } else {
      valCol.textContent = String(val);
      if (typeof val === 'string' && (val.indexOf('/') !== -1 || val.indexOf('-') !== -1 || val.length > 20)) {
        valCol.className += ' mono-token';
      }
    }

    row.appendChild(valCol);
    return row;
  }

  function renderActions(entityType, data) {
    var type = (entityType || '').toLowerCase();

    // Pivot to Process Tree
    if (type === 'process' || (data && (data.pid || data.process_id))) {
      var ptreeBtn = document.createElement('button');
      ptreeBtn.type = 'button';
      ptreeBtn.className = 'btn btn-secondary btn-sm';
      ptreeBtn.textContent = 'Pivot to Process Tree';
      ptreeBtn.addEventListener('click', function () {
        close();
        if (window.OsirisRouter) {
          window.OsirisRouter.navigate('process-tree', { pid: data.pid || '' });
        }
      });
      actionsEl.appendChild(ptreeBtn);
    }

    // Pivot to Timeline
    if (type === 'process' || type === 'event' || type === 'detection' || type === 'session') {
      var tlBtn = document.createElement('button');
      tlBtn.type = 'button';
      tlBtn.className = 'btn btn-secondary btn-sm';
      tlBtn.textContent = 'Pivot to Timeline';
      tlBtn.addEventListener('click', function () {
        close();
        if (window.OsirisRouter) {
          var params = {};
          if (data.process_id) params.process_id = data.process_id;
          if (data.pid) params.pid = data.pid;
          window.OsirisRouter.navigate('timeline', params);
        }
      });
      actionsEl.appendChild(tlBtn);
    }

    // Promote to Incident / Pin to Evidence
    if (type === 'detection' || type === 'process' || type === 'event') {
      var incidentBtn = document.createElement('button');
      incidentBtn.type = 'button';
      incidentBtn.className = 'btn btn-primary btn-sm';
      incidentBtn.textContent = 'Promote to Incident';
      incidentBtn.addEventListener('click', function () {
        close();
        if (window.OsirisRouter) {
          window.OsirisRouter.navigate('incidents');
        }
      });
      actionsEl.appendChild(incidentBtn);
    }
  }

  window.OsirisInspector = Object.freeze({
    init: init,
    open: open,
    close: close,
    inspect: inspect,
  });

})(typeof window !== 'undefined' ? window : this);
