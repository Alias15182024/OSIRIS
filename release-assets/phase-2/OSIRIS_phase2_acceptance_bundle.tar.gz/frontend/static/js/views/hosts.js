/**
 * OSIRIS Unified Digital Forensics Platform - Hosts & Collectors Controller
 *
 * Responsibilities:
 * - Render registered hosts inventory and online/offline statuses.
 * - Expose local collector supervisor metrics and collector health.
 * - Global host context switching.
 */

(function (window) {
  'use strict';

  var container = null;
  var hostsListContainer = null;
  var emptyStateEl = null;
  var errorBoxEl = null;
  var collectorHealthBox = null;
  var hostsList = [];

  function init() {
    container = document.getElementById('view-hosts');
    if (!container) {
      return;
    }
    hostsListContainer = document.getElementById('hosts-grid');
    emptyStateEl = document.getElementById('hosts-empty-state');
    errorBoxEl = document.getElementById('hosts-error-box');
    collectorHealthBox = document.getElementById('collector-health-summary');

    var refreshBtn = document.getElementById('hosts-refresh-btn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function () {
        loadHosts();
      });
    }
  }

  function loadHosts() {
    if (!container) {
      return;
    }
    if (errorBoxEl) {
      errorBoxEl.classList.add('hidden');
      errorBoxEl.textContent = '';
    }

    if (!window.OsirisApi || !window.OsirisApi.getToken()) {
      return;
    }

    // Load hosts list
    window.OsirisApi.getHosts()
      .then(function (res) {
        hostsList = (res && res.items) ? res.items : (Array.isArray(res) ? res : []);
        renderHosts();
      })
      .catch(function (err) {
        if (errorBoxEl) {
          errorBoxEl.textContent = 'Failed to load hosts: ' + (err.message || 'Network error');
          errorBoxEl.classList.remove('hidden');
        }
      });

    // Load collector health summary
    window.OsirisApi.getStatus()
      .then(function (statusRes) {
        renderCollectorHealth(statusRes);
      })
      .catch(function () {
        // status check error ignored
      });
  }

  function renderCollectorHealth(statusRes) {
    if (!collectorHealthBox) {
      return;
    }
    while (collectorHealthBox.firstChild) {
      collectorHealthBox.removeChild(collectorHealthBox.firstChild);
    }

    var collectors = (statusRes && statusRes.collectors) ? statusRes.collectors : null;
    var card = document.createElement('div');
    card.className = 'collector-summary-card';

    var title = document.createElement('h3');
    title.className = 'summary-title';
    title.textContent = 'Local Collector Supervisor';
    card.appendChild(title);

    var grid = document.createElement('div');
    grid.className = 'collector-metrics-grid';

    // Supervisor Status
    var supMetric = document.createElement('div');
    supMetric.className = 'metric-item';
    var supLabel = document.createElement('span');
    supLabel.className = 'metric-label';
    supLabel.textContent = 'Supervisor Daemon';
    var supVal = document.createElement('span');
    var isRunning = collectors && collectors.status === 'running';
    supVal.className = 'metric-val ' + (isRunning ? 'text-success' : 'text-danger');
    supVal.textContent = isRunning ? 'RUNNING (PID ' + collectors.supervisor_pid + ')' : 'INACTIVE';
    supMetric.appendChild(supLabel);
    supMetric.appendChild(supVal);
    grid.appendChild(supMetric);

    // Cycles count
    var cyclesMetric = document.createElement('div');
    cyclesMetric.className = 'metric-item';
    var cyclesLabel = document.createElement('span');
    cyclesLabel.className = 'metric-label';
    cyclesLabel.textContent = 'Completed Cycles';
    var cyclesVal = document.createElement('span');
    cyclesVal.className = 'metric-val';
    cyclesVal.textContent = collectors ? String(collectors.cycle_count || 0) : '0';
    cyclesMetric.appendChild(cyclesLabel);
    cyclesMetric.appendChild(cyclesVal);
    grid.appendChild(cyclesMetric);

    // Observations count
    var obsMetric = document.createElement('div');
    obsMetric.className = 'metric-item';
    var obsLabel = document.createElement('span');
    obsLabel.className = 'metric-label';
    obsLabel.textContent = 'Total Observations';
    var obsVal = document.createElement('span');
    obsVal.className = 'metric-val';
    obsVal.textContent = collectors ? String(collectors.observations_count || 0) : '0';
    obsMetric.appendChild(obsLabel);
    obsMetric.appendChild(obsVal);
    grid.appendChild(obsMetric);

    // Collectors detail list
    var subCollectors = collectors ? collectors.collectors : {};
    var subList = document.createElement('div');
    subList.className = 'subcollectors-strip';
    ['proc', 'resource', 'fs'].forEach(function (name) {
      var colData = subCollectors ? subCollectors[name] : null;
      var chip = document.createElement('span');
      var healthy = colData && colData.healthy;
      chip.className = 'badge ' + (healthy ? 'badge-success' : 'badge-secondary');
      chip.textContent = name.toUpperCase() + ': ' + (healthy ? 'HEALTHY' : 'IDLE');
      subList.appendChild(chip);
    });

    card.appendChild(grid);
    card.appendChild(subList);
    collectorHealthBox.appendChild(card);
  }

  function renderHosts() {
    if (!hostsListContainer) {
      return;
    }

    while (hostsListContainer.firstChild) {
      hostsListContainer.removeChild(hostsListContainer.firstChild);
    }

    if (hostsList.length === 0) {
      if (emptyStateEl) {
        emptyStateEl.classList.remove('hidden');
      }
      return;
    }

    if (emptyStateEl) {
      emptyStateEl.classList.add('hidden');
    }

    var activeHostId = window.OsirisApi ? window.OsirisApi.getActiveHostId() : '';

    hostsList.forEach(function (host) {
      var card = document.createElement('div');
      var isActive = host.id === activeHostId;
      card.className = 'host-card ' + (isActive ? 'active-host-card' : '');

      var header = document.createElement('div');
      header.className = 'host-card-header';

      var titleBox = document.createElement('div');
      var title = document.createElement('h3');
      title.className = 'host-card-title';
      title.textContent = host.hostname;
      var ip = document.createElement('span');
      ip.className = 'host-card-ip mono-token';
      ip.textContent = host.ip_address || 'No IP';
      titleBox.appendChild(title);
      titleBox.appendChild(ip);
      header.appendChild(titleBox);

      var statusBadge = document.createElement('span');
      statusBadge.className = 'badge ' + (host.status === 'online' ? 'badge-success' : 'badge-secondary');
      statusBadge.textContent = (host.status || 'offline').toUpperCase();
      header.appendChild(statusBadge);

      card.appendChild(header);

      // Body details
      var body = document.createElement('div');
      body.className = 'host-card-body';

      var osRow = document.createElement('div');
      osRow.className = 'prop-row';
      var osLabel = document.createElement('span');
      osLabel.className = 'prop-label';
      osLabel.textContent = 'Operating System';
      var osVal = document.createElement('span');
      osVal.className = 'prop-val';
      osVal.textContent = host.os_info || 'Linux';
      osRow.appendChild(osLabel);
      osRow.appendChild(osVal);
      body.appendChild(osRow);

      var idRow = document.createElement('div');
      idRow.className = 'prop-row';
      var idLabel = document.createElement('span');
      idLabel.className = 'prop-label';
      idLabel.textContent = 'Host UUID';
      var idVal = document.createElement('span');
      idVal.className = 'prop-val mono-token cell-sm';
      idVal.textContent = host.id;
      idRow.appendChild(idLabel);
      idRow.appendChild(idVal);
      body.appendChild(idRow);

      var seenRow = document.createElement('div');
      seenRow.className = 'prop-row';
      var seenLabel = document.createElement('span');
      seenLabel.className = 'prop-label';
      seenLabel.textContent = 'Last Seen';
      var seenVal = document.createElement('span');
      seenVal.className = 'prop-val';
      seenVal.textContent = host.last_seen_at ? new Date(host.last_seen_at).toLocaleTimeString() : 'Never';
      seenRow.appendChild(seenLabel);
      seenRow.appendChild(seenVal);
      body.appendChild(seenRow);

      card.appendChild(body);

      // Footer action
      var footer = document.createElement('div');
      footer.className = 'host-card-footer';

      var selectBtn = document.createElement('button');
      selectBtn.type = 'button';
      selectBtn.className = 'btn ' + (isActive ? 'btn-primary' : 'btn-outline') + ' btn-sm';
      selectBtn.textContent = isActive ? 'Active Context' : 'Set as Active Context';
      selectBtn.disabled = isActive;
      selectBtn.addEventListener('click', function () {
        if (window.OsirisApp && typeof window.OsirisApp.selectHost === 'function') {
          window.OsirisApp.selectHost(host.id);
          renderHosts();
        }
      });
      footer.appendChild(selectBtn);

      card.appendChild(footer);
      hostsListContainer.appendChild(card);
    });
  }

  function resetState() {
    hostsList = [];
    if (hostsListContainer) {
      while (hostsListContainer.firstChild) {
        hostsListContainer.removeChild(hostsListContainer.firstChild);
      }
    }
  }

  window.OsirisHosts = Object.freeze({
    init: init,
    loadHosts: loadHosts,
    resetState: resetState,
  });

})(typeof window !== 'undefined' ? window : this);
