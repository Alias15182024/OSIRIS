/**
 * OSIRIS Unified Digital Forensics Platform - Main Application Controller
 *
 * Responsibilities:
 * - App initialization & session hydration on page load via /api/auth/me.
 * - Login form handling, submission state, error presentation, and modal controls.
 * - Logout action and client state cleanup.
 * - View navigation switching across all 14 Observe, Detect, and Reconstruct modules.
 * - Global host context synchronization and active host switching.
 * - Real-time WebSocket connection lifecycle and streaming badge status.
 * - Non-sensitive UI updates (textContent only).
 * - Automatic session-expiry callback handling.
 */

(function (window, document) {
  'use strict';

  // DOM Element References
  let elements = {};

  /**
   * Cache DOM elements used throughout the application.
   */
  function cacheElements() {
    elements = {
      // Header & Auth elements
      userProfileArea: document.getElementById('user-profile-area'),
      userStatusIndicator: document.getElementById('user-status-indicator'),
      userDisplayName: document.getElementById('user-display-name'),
      userRoleBadge: document.getElementById('user-role-badge'),
      loginTriggerBtn: document.getElementById('login-trigger-btn'),
      logoutBtn: document.getElementById('logout-btn'),
      globalAlertContainer: document.getElementById('global-alert-container'),
      globalAlertMessage: document.getElementById('global-alert-message'),

      // Global Host Context & WebSocket Stream Badge
      globalHostSelect: document.getElementById('global-host-select'),
      wsStatusBadge: document.getElementById('ws-status-badge'),

      // Navigation links
      navLinks: document.querySelectorAll('.nav-link[data-view]'),

      // View panels
      viewPanels: {
        dashboard: document.getElementById('view-dashboard'),
        events: document.getElementById('view-events'),
        processes: document.getElementById('view-processes'),
        resources: document.getElementById('view-resources'),
        files: document.getElementById('view-files'),
        hosts: document.getElementById('view-hosts'),
        timeline: document.getElementById('view-timeline'),
        sessions: document.getElementById('view-sessions'),
        detections: document.getElementById('view-detections'),
        'detection-rules': document.getElementById('view-detection-rules'),
        fim: document.getElementById('view-fim'),
        incidents: document.getElementById('view-incidents'),
        workspace: document.getElementById('view-workspace'),
        'process-tree': document.getElementById('view-process-tree'),
        graph: document.getElementById('view-graph'),
        evidence: document.getElementById('view-evidence'),
        reports: document.getElementById('view-reports'),
        settings: document.getElementById('view-settings'),
      },

      // Modal elements
      loginModal: document.getElementById('login-modal-container'),
      loginModalCloseBtn: document.getElementById('login-modal-close'),
      loginForm: document.getElementById('login-form'),
      loginUsernameInput: document.getElementById('login-username'),
      loginPasswordInput: document.getElementById('login-password'),
      loginSubmitBtn: document.getElementById('login-submit-btn'),
      loginErrorBox: document.getElementById('login-error'),
    };
  }

  /**
   * Populate global host selector dropdown from /api/hosts.
   */
  function populateHosts() {
    if (!window.OsirisApi || !elements.globalHostSelect) return;
    window.OsirisApi.getHosts().then(function (res) {
      var hosts = (res && res.items) ? res.items : (Array.isArray(res) ? res : []);
      if (hosts.length === 0) return;

      while (elements.globalHostSelect.firstChild) {
        elements.globalHostSelect.removeChild(elements.globalHostSelect.firstChild);
      }

      var currentActive = window.OsirisApi.getActiveHostId();
      var foundActive = false;

      hosts.forEach(function (h) {
        var opt = document.createElement('option');
        opt.value = h.id;
        opt.textContent = h.hostname + (h.is_live ? ' (Live Host)' : ' (Node)');
        if (h.id === currentActive || h.hostname === currentActive) {
          opt.selected = true;
          foundActive = true;
          currentActive = h.id;
        }
        elements.globalHostSelect.appendChild(opt);
      });

      if (!foundActive && hosts.length > 0) {
        elements.globalHostSelect.value = hosts[0].id;
        selectHost(hosts[0].id);
      } else if (currentActive) {
        if (elements.globalHostSelect.value !== currentActive) {
          elements.globalHostSelect.value = currentActive;
        }
        if (window.OsirisApi && typeof window.OsirisApi.setActiveHostId === 'function') {
          window.OsirisApi.setActiveHostId(currentActive);
        }
        if (window.OsirisWs && typeof window.OsirisWs.subscribeHost === 'function') {
          window.OsirisWs.subscribeHost(currentActive);
        }
      }
    }).catch(function () {});
  }

  /**
   * Switch the global host scope and notify all listeners and WebSocket.
   * @param {string} hostId
   */
  function selectHost(hostId) {
    if (!hostId) return;

    var oldHost = window.OsirisApi && typeof window.OsirisApi.getActiveHostId === 'function'
      ? window.OsirisApi.getActiveHostId()
      : '';

    if (elements.globalHostSelect && elements.globalHostSelect.value !== hostId) {
      elements.globalHostSelect.value = hostId;
    }

    if (window.OsirisApi && typeof window.OsirisApi.setActiveHostId === 'function') {
      window.OsirisApi.setActiveHostId(hostId);
    }

    if (window.OsirisWs) {
      if (oldHost && oldHost.toLowerCase() !== String(hostId).toLowerCase() && typeof window.OsirisWs.unsubscribeHost === 'function') {
        window.OsirisWs.unsubscribeHost(oldHost);
      }
      if (typeof window.OsirisWs.subscribeHost === 'function') {
        window.OsirisWs.subscribeHost(hostId);
      }
    }

    // Refresh currently visible view
    var activeLink = document.querySelector('.nav-link.active[data-view]');
    if (activeLink) {
      var currentView = activeLink.getAttribute('data-view');
      triggerViewLoad(currentView);
    }
  }

  /**
   * Update the WebSocket status indicator badge in the top bar.
   * @param {string} status
   */
  function updateWsStatus(status) {
    if (!elements.wsStatusBadge) return;
    elements.wsStatusBadge.className = 'status-pill';
    if (status === 'connected') {
      elements.wsStatusBadge.classList.add('status-online');
      elements.wsStatusBadge.textContent = 'Live Stream';
    } else if (status === 'connecting' || status === 'reconnecting') {
      elements.wsStatusBadge.classList.add('status-warning');
      elements.wsStatusBadge.textContent = status === 'connecting' ? 'Connecting...' : 'Reconnecting...';
    } else {
      elements.wsStatusBadge.classList.add('status-offline');
      elements.wsStatusBadge.textContent = 'Disconnected';
    }
  }

  /**
   * Handle real-time telemetry events pushed over WebSocket.
   * @param {Object} data
   */
  function handleLiveTelemetryEvent(data) {
    if (!data) return;

    var activeHost = window.OsirisApi ? window.OsirisApi.getActiveHostId() : '';
    if (data.host_id && activeHost && String(data.host_id).toLowerCase() !== String(activeHost).toLowerCase() && data.type !== 'heartbeat') {
      return;
    }

    if (data.type === 'detection') {
      if (window.OsirisDetections && typeof window.OsirisDetections.handleIncomingDetection === 'function') {
        window.OsirisDetections.handleIncomingDetection(data.data);
      }
      if (window.OsirisDetections && typeof window.OsirisDetections.updateSummaryStats === 'function') {
        window.OsirisDetections.updateSummaryStats();
      }
    }
    if (data.type === 'fim' && window.OsirisFim && typeof window.OsirisFim.updateSummaryStats === 'function') {
      window.OsirisFim.updateSummaryStats();
    }
    if (data.type === 'incident' && window.OsirisIncidents && typeof window.OsirisIncidents.loadIncidents === 'function') {
      window.OsirisIncidents.loadIncidents(true);
    }
    if (data.type === 'resource') {
      if (window.OsirisDashboard && typeof window.OsirisDashboard.loadDashboard === 'function') {
        window.OsirisDashboard.loadDashboard({ force: true });
      }
      if (window.OsirisResources && typeof window.OsirisResources.handleIncomingResourceSnapshot === 'function') {
        window.OsirisResources.handleIncomingResourceSnapshot(data.data);
      }
    }
    if (data.type === 'event') {
      if (window.OsirisEvents && typeof window.OsirisEvents.handleIncomingEvent === 'function') {
        window.OsirisEvents.handleIncomingEvent(data.data);
      }
      if (window.OsirisDashboard && typeof window.OsirisDashboard.loadDashboard === 'function') {
        window.OsirisDashboard.loadDashboard({ force: true });
      }
    }
    if (data.type === 'host' || data.type === 'heartbeat') {
      if (typeof populateHosts === 'function') {
        populateHosts();
      }
      if (window.OsirisHosts && typeof window.OsirisHosts.loadHosts === 'function') {
        window.OsirisHosts.loadHosts();
      }
      if (window.OsirisDashboard && typeof window.OsirisDashboard.loadStatus === 'function') {
        window.OsirisDashboard.loadStatus();
      }
    }
  }

  /**
   * Set UI to an authenticated user state.
   * Uses textContent exclusively to avoid HTML injection risks.
   *
   * @param {Object} user - UserResponse object from /api/auth/me or login
   */
  function setAuthenticatedState(user) {
    if (!user) return;

    if (elements.userStatusIndicator) {
      elements.userStatusIndicator.classList.remove('status-offline');
      elements.userStatusIndicator.classList.add('status-online');
      elements.userStatusIndicator.setAttribute('aria-label', 'Status: Authenticated');
    }

    if (elements.userDisplayName) {
      elements.userDisplayName.textContent = user.display_name || user.username || 'User';
    }

    if (elements.userRoleBadge) {
      elements.userRoleBadge.textContent = user.role || 'viewer';
      elements.userRoleBadge.className = 'badge ' + (user.role === 'admin' ? 'badge-danger' : 'badge-info');
    }

    if (elements.loginTriggerBtn) {
      elements.loginTriggerBtn.classList.add('hidden');
    }

    if (elements.logoutBtn) {
      elements.logoutBtn.classList.remove('hidden');
    }

    closeLoginModal();
    hideGlobalAlert();

    // Populate registered hosts
    populateHosts();

    // Establish WebSocket real-time telemetry stream
    if (window.OsirisWs) {
      window.OsirisWs.onStatusChange(updateWsStatus);
      window.OsirisWs.onEvent(handleLiveTelemetryEvent);
      window.OsirisWs.connect();
    }

    // Hydrate initial dashboard overview
    if (window.OsirisDashboard && typeof window.OsirisDashboard.loadDashboard === 'function') {
      window.OsirisDashboard.loadDashboard();
    }

    // Hydrate detection stats badge if available
    if (window.OsirisDetections && typeof window.OsirisDetections.updateSummaryStats === 'function') {
      window.OsirisDetections.updateSummaryStats();
    }

    // Hydrate FIM stats badge if available
    if (window.OsirisFim && typeof window.OsirisFim.updateSummaryStats === 'function') {
      window.OsirisFim.updateSummaryStats();
    }
  }

  /**
   * Set UI to an unauthenticated/guest state and purge sensitive views.
   */
  function setUnauthenticatedState() {
    if (elements.userStatusIndicator) {
      elements.userStatusIndicator.classList.remove('status-online');
      elements.userStatusIndicator.classList.add('status-offline');
      elements.userStatusIndicator.setAttribute('aria-label', 'Status: Offline');
    }

    if (elements.userDisplayName) {
      elements.userDisplayName.textContent = 'Not Authenticated';
    }

    if (elements.userRoleBadge) {
      elements.userRoleBadge.textContent = 'Guest';
      elements.userRoleBadge.className = 'badge badge-secondary';
    }

    if (elements.loginTriggerBtn) {
      elements.loginTriggerBtn.classList.remove('hidden');
    }

    if (elements.logoutBtn) {
      elements.logoutBtn.classList.add('hidden');
    }

    // Disconnect real-time stream
    if (window.OsirisWs && typeof window.OsirisWs.disconnect === 'function') {
      window.OsirisWs.disconnect();
    }
    if (elements.wsStatusBadge) {
      elements.wsStatusBadge.className = 'status-pill status-offline';
      elements.wsStatusBadge.textContent = 'Disconnected';
    }

    // Close slide-over inspector drawer
    if (window.OsirisInspector && typeof window.OsirisInspector.close === 'function') {
      window.OsirisInspector.close();
    }

    // Reset all view states in DOM memory
    if (window.OsirisDashboard && typeof window.OsirisDashboard.resetDashboard === 'function') {
      window.OsirisDashboard.resetDashboard();
    }
    if (window.OsirisEvents && typeof window.OsirisEvents.resetEvents === 'function') {
      window.OsirisEvents.resetEvents();
    }
    if (window.OsirisProcesses && typeof window.OsirisProcesses.resetProcesses === 'function') {
      window.OsirisProcesses.resetProcesses();
    }
    if (window.OsirisResources && typeof window.OsirisResources.resetResources === 'function') {
      window.OsirisResources.resetResources();
    }
    if (window.OsirisFiles && typeof window.OsirisFiles.resetFiles === 'function') {
      window.OsirisFiles.resetFiles();
    }
    if (window.OsirisTimeline && typeof window.OsirisTimeline.resetTimeline === 'function') {
      window.OsirisTimeline.resetTimeline();
    }
    if (window.OsirisSessions && typeof window.OsirisSessions.resetSessions === 'function') {
      window.OsirisSessions.resetSessions();
    }
    if (window.OsirisDetections && typeof window.OsirisDetections.resetDetections === 'function') {
      window.OsirisDetections.resetDetections();
    }
    if (window.OsirisFim && typeof window.OsirisFim.resetFim === 'function') {
      window.OsirisFim.resetFim();
    }
    if (window.OsirisIncidents && typeof window.OsirisIncidents.resetIncidents === 'function') {
      window.OsirisIncidents.resetIncidents();
    }
    if (window.OsirisWorkspace && typeof window.OsirisWorkspace.resetWorkspace === 'function') {
      window.OsirisWorkspace.resetWorkspace();
    }
    if (window.OsirisHosts && typeof window.OsirisHosts.resetState === 'function') {
      window.OsirisHosts.resetState();
    }
    if (window.OsirisRules && typeof window.OsirisRules.resetState === 'function') {
      window.OsirisRules.resetState();
    }
    if (window.OsirisProcessTree && typeof window.OsirisProcessTree.resetState === 'function') {
      window.OsirisProcessTree.resetState();
    }
  }

  /**
   * Show global notification message.
   * @param {string} message
   */
  function showGlobalAlert(message) {
    if (elements.globalAlertContainer && elements.globalAlertMessage) {
      elements.globalAlertMessage.textContent = message;
      elements.globalAlertContainer.classList.remove('hidden');
    }
  }

  /**
   * Hide global notification banner.
   */
  function hideGlobalAlert() {
    if (elements.globalAlertContainer) {
      elements.globalAlertContainer.classList.add('hidden');
      if (elements.globalAlertMessage) {
        elements.globalAlertMessage.textContent = '';
      }
    }
  }

  /**
   * Open the login modal dialog.
   */
  function openLoginModal() {
    if (elements.loginModal) {
      elements.loginModal.classList.remove('hidden');
      clearLoginError();
      if (elements.loginUsernameInput) {
        elements.loginUsernameInput.focus();
      }
    }
  }

  /**
   * Close the login modal dialog.
   */
  function closeLoginModal() {
    if (elements.loginModal) {
      elements.loginModal.classList.add('hidden');
      clearLoginForm();
      clearLoginError();
    }
  }

  /**
   * Clear login input fields.
   */
  function clearLoginForm() {
    if (elements.loginUsernameInput) elements.loginUsernameInput.value = '';
    if (elements.loginPasswordInput) elements.loginPasswordInput.value = '';
  }

  /**
   * Display an error message in the login dialog.
   * @param {string} message
   */
  function showLoginError(message) {
    if (elements.loginErrorBox) {
      elements.loginErrorBox.textContent = message;
      elements.loginErrorBox.classList.remove('hidden');
    }
  }

  /**
   * Clear error message in the login dialog.
   */
  function clearLoginError() {
    if (elements.loginErrorBox) {
      elements.loginErrorBox.textContent = '';
      elements.loginErrorBox.classList.add('hidden');
    }
  }

  /**
   * Set submitting/loading state on the login submit button.
   * @param {boolean} isSubmitting
   */
  function setLoginSubmitting(isSubmitting) {
    if (elements.loginSubmitBtn) {
      elements.loginSubmitBtn.disabled = isSubmitting;
      const btnText = elements.loginSubmitBtn.querySelector('.btn-text');
      if (btnText) {
        btnText.textContent = isSubmitting ? 'Authenticating...' : 'Sign In';
      }
    }
    if (elements.loginUsernameInput) elements.loginUsernameInput.disabled = isSubmitting;
    if (elements.loginPasswordInput) elements.loginPasswordInput.disabled = isSubmitting;
  }

  /**
   * Handle login form submission.
   * @param {Event} e
   */
  async function handleLoginSubmit(e) {
    e.preventDefault();
    clearLoginError();

    const username = elements.loginUsernameInput ? elements.loginUsernameInput.value.trim() : '';
    const password = elements.loginPasswordInput ? elements.loginPasswordInput.value : '';

    if (!username || !password) {
      showLoginError('Please enter both username and password.');
      return;
    }

    try {
      setLoginSubmitting(true);
      const data = await window.OsirisApi.login(username, password);

      if (data && data.user) {
        setAuthenticatedState(data.user);
      } else {
        const user = await window.OsirisApi.getCurrentUser();
        setAuthenticatedState(user);
      }
    } catch (err) {
      showLoginError(err.message || 'Invalid username or password.');
    } finally {
      setLoginSubmitting(false);
    }
  }

  /**
   * Handle user logout action.
   */
  function handleLogout() {
    window.OsirisApi.logout();
    setUnauthenticatedState();
    showGlobalAlert('You have been logged out.');
  }

  /**
   * Switch the active view panel in the navigation shell.
   *
   * @param {string} viewName - Target view ID key ('dashboard', 'events', etc.)
   * @param {boolean} [updateHash=true] - Whether to synchronize URL hash
   */
  function switchView(viewName, updateHash) {
    if (!elements.viewPanels[viewName]) return;

    if (updateHash !== false && window.OsirisRouter && typeof window.OsirisRouter.navigateTo === 'function') {
      window.OsirisRouter.navigateTo(viewName);
    }

    // Update navigation link states
    elements.navLinks.forEach((link) => {
      const isTarget = link.getAttribute('data-view') === viewName;
      if (isTarget) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      } else {
        link.classList.remove('active');
        link.removeAttribute('aria-current');
      }
    });

    // Toggle view panels
    Object.keys(elements.viewPanels).forEach((key) => {
      const panel = elements.viewPanels[key];
      if (panel) {
        if (key === viewName) {
          panel.classList.remove('hidden');
          panel.classList.add('active');
        } else {
          panel.classList.add('hidden');
          panel.classList.remove('active');
        }
      }
    });

    triggerViewLoad(viewName);
  }

  /**
   * Trigger data loading for the requested view.
   * @param {string} viewName
   */
  function triggerViewLoad(viewName) {
    switch (viewName) {
      case 'dashboard':
        if (window.OsirisDashboard && typeof window.OsirisDashboard.loadDashboard === 'function') {
          window.OsirisDashboard.loadDashboard();
        }
        break;
      case 'events':
        if (window.OsirisEvents && typeof window.OsirisEvents.loadEvents === 'function') {
          window.OsirisEvents.loadEvents();
        }
        break;
      case 'processes':
        if (window.OsirisProcesses && typeof window.OsirisProcesses.loadProcesses === 'function') {
          window.OsirisProcesses.loadProcesses();
        }
        break;
      case 'resources':
        if (window.OsirisResources && typeof window.OsirisResources.loadResources === 'function') {
          window.OsirisResources.loadResources();
        }
        break;
      case 'files':
        if (window.OsirisFiles && typeof window.OsirisFiles.loadFiles === 'function') {
          window.OsirisFiles.loadFiles();
        }
        break;
      case 'hosts':
        if (window.OsirisHosts && typeof window.OsirisHosts.loadHosts === 'function') {
          window.OsirisHosts.loadHosts();
        }
        break;
      case 'timeline':
        if (window.OsirisTimeline && typeof window.OsirisTimeline.loadTimeline === 'function') {
          window.OsirisTimeline.loadTimeline();
        }
        break;
      case 'sessions':
        if (window.OsirisSessions && typeof window.OsirisSessions.loadSessions === 'function') {
          window.OsirisSessions.loadSessions();
        }
        break;
      case 'detections':
        if (window.OsirisDetections && typeof window.OsirisDetections.loadDetections === 'function') {
          window.OsirisDetections.loadDetections();
        }
        break;
      case 'detection-rules':
        if (window.OsirisRules && typeof window.OsirisRules.loadRules === 'function') {
          window.OsirisRules.loadRules();
        }
        break;
      case 'fim':
        if (window.OsirisFim && typeof window.OsirisFim.loadFim === 'function') {
          window.OsirisFim.loadFim();
        }
        break;
      case 'incidents':
        if (window.OsirisIncidents && typeof window.OsirisIncidents.loadIncidents === 'function') {
          window.OsirisIncidents.loadIncidents();
        }
        break;
      case 'workspace':
        if (window.OsirisWorkspace && typeof window.OsirisWorkspace.loadWorkspaces === 'function') {
          window.OsirisWorkspace.loadWorkspaces();
        }
        break;
      case 'process-tree':
        if (window.OsirisProcessTree && typeof window.OsirisProcessTree.loadProcessTree === 'function') {
          window.OsirisProcessTree.loadProcessTree();
        }
        break;
      default:
        break;
    }
  }

  /**
   * Bind event listeners for UI interactions.
   */
  function bindEvents() {
    // Navigation link clicks
    elements.navLinks.forEach((link) => {
      link.addEventListener('click', () => {
        const view = link.getAttribute('data-view');
        if (view) {
          switchView(view);
        }
      });
    });

    // Host selector change
    if (elements.globalHostSelect) {
      elements.globalHostSelect.addEventListener('change', (e) => {
        selectHost(e.target.value);
      });
    }

    // Pivot buttons for placeholder links
    var graphWsBtn = document.getElementById('entity-graph-open-workspace-btn');
    if (graphWsBtn) {
      graphWsBtn.addEventListener('click', () => {
        switchView('workspace');
      });
    }

    var evidenceWsBtn = document.getElementById('evidence-open-workspace-btn');
    if (evidenceWsBtn) {
      evidenceWsBtn.addEventListener('click', () => {
        switchView('workspace');
      });
    }

    var reportsIncBtn = document.getElementById('reports-open-incidents-btn');
    if (reportsIncBtn) {
      reportsIncBtn.addEventListener('click', () => {
        switchView('incidents');
      });
    }

    // Login modal trigger & close buttons
    if (elements.loginTriggerBtn) {
      elements.loginTriggerBtn.addEventListener('click', openLoginModal);
    }
    if (elements.loginModalCloseBtn) {
      elements.loginModalCloseBtn.addEventListener('click', closeLoginModal);
    }

    // Close modal when clicking backdrop outside dialog
    if (elements.loginModal) {
      elements.loginModal.addEventListener('click', (e) => {
        if (e.target === elements.loginModal) {
          closeLoginModal();
        }
      });
    }

    // Login form submission
    if (elements.loginForm) {
      elements.loginForm.addEventListener('submit', handleLoginSubmit);
    }

    // Logout button
    if (elements.logoutBtn) {
      elements.logoutBtn.addEventListener('click', handleLogout);
    }

    // Register API authentication expiry callback (401 handler)
    if (window.OsirisApi && typeof window.OsirisApi.onAuthExpired === 'function') {
      window.OsirisApi.onAuthExpired(() => {
        setUnauthenticatedState();
        showGlobalAlert('Your session has expired. Please log in again.');
        openLoginModal();
      });
    }
  }

  /**
   * Initialize application state on page load.
   */
  async function initApp() {
    cacheElements();
    bindEvents();

    // Initialize submodules
    if (window.OsirisInspector && typeof window.OsirisInspector.init === 'function') {
      window.OsirisInspector.init();
    }
    if (window.OsirisHosts && typeof window.OsirisHosts.init === 'function') {
      window.OsirisHosts.init();
    }
    if (window.OsirisRules && typeof window.OsirisRules.init === 'function') {
      window.OsirisRules.init();
    }
    if (window.OsirisProcessTree && typeof window.OsirisProcessTree.init === 'function') {
      window.OsirisProcessTree.init();
    }
    if (window.OsirisRouter && typeof window.OsirisRouter.init === 'function') {
      window.OsirisRouter.init(switchView);
    }

    // Check for existing session token
    const token = window.OsirisApi ? window.OsirisApi.getToken() : null;

    if (!token) {
      setUnauthenticatedState();
      return;
    }

    // Validate stored token against backend
    try {
      const user = await window.OsirisApi.getCurrentUser();
      setAuthenticatedState(user);
    } catch {
      // Token is expired, tampered, or invalid
      setUnauthenticatedState();
    }
  }

  // Run initialization when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }

  // Export minimal app controller for testing/extension
  window.OsirisApp = Object.freeze({
    switchView,
    selectHost,
    populateHosts,
    setAuthenticatedState,
    setUnauthenticatedState,
    openLoginModal,
    closeLoginModal,
  });

})(typeof window !== 'undefined' ? window : this, typeof document !== 'undefined' ? document : {});
