/**
 * OSIRIS Unified Digital Forensics Platform - Client URL Hash Router
 *
 * Responsibilities:
 * - URL Hash Routing: #observe/events, #detect/rules, #reconstruct/process-tree, etc.
 * - Bidirectional synchronization with sidebar and view switching.
 * - Parsing and serialization of URL search parameters within the hash fragment.
 * - Deep-linking support on page reload or history navigation.
 */

(function (window) {
  'use strict';

  var ROUTE_MAP = {
    '': 'dashboard',
    'overview': 'dashboard',
    'dashboard': 'dashboard',
    'observe': 'events',
    'observe/events': 'events',
    'events': 'events',
    'observe/processes': 'processes',
    'processes': 'processes',
    'observe/resources': 'resources',
    'resources': 'resources',
    'observe/files': 'files',
    'files': 'files',
    'observe/hosts': 'hosts',
    'hosts': 'hosts',
    'detect': 'detections',
    'detect/detections': 'detections',
    'detections': 'detections',
    'detect/rules': 'detection-rules',
    'rules': 'detection-rules',
    'detection-rules': 'detection-rules',
    'detect/fim': 'fim',
    'fim': 'fim',
    'reconstruct': 'workspace',
    'investigations': 'workspace',
    'reconstruct/investigations': 'workspace',
    'reconstruct/workspaces': 'workspace',
    'workspace': 'workspace',
    'reconstruct/sessions': 'sessions',
    'sessions': 'sessions',
    'reconstruct/timeline': 'timeline',
    'timeline': 'timeline',
    'reconstruct/process-tree': 'process-tree',
    'process-tree': 'process-tree',
    'reconstruct/graph': 'graph',
    'graph': 'graph',
    'reconstruct/incidents': 'incidents',
    'incidents': 'incidents',
    'reconstruct/evidence': 'evidence',
    'evidence': 'evidence',
    'reconstruct/reports': 'reports',
    'reports': 'reports',
    'settings': 'settings',
  };

  var VIEW_TO_HASH = {
    'dashboard': 'overview',
    'events': 'observe/events',
    'processes': 'observe/processes',
    'resources': 'observe/resources',
    'files': 'observe/files',
    'hosts': 'observe/hosts',
    'detections': 'detect/detections',
    'detection-rules': 'detect/rules',
    'fim': 'detect/fim',
    'workspace': 'reconstruct/workspaces',
    'sessions': 'reconstruct/sessions',
    'timeline': 'reconstruct/timeline',
    'process-tree': 'reconstruct/process-tree',
    'graph': 'reconstruct/graph',
    'incidents': 'reconstruct/incidents',
    'evidence': 'reconstruct/evidence',
    'reports': 'reconstruct/reports',
    'settings': 'settings',
  };

  var routeChangeListeners = [];

  function parseHash() {
    var rawHash = window.location.hash || '';
    if (rawHash.startsWith('#')) {
      rawHash = rawHash.slice(1);
    }
    if (rawHash.startsWith('/')) {
      rawHash = rawHash.slice(1);
    }

    var parts = rawHash.split('?');
    var path = parts[0] || '';
    var qs = parts[1] || '';

    var params = {};
    if (qs) {
      var searchParams = new URLSearchParams(qs);
      searchParams.forEach(function (val, key) {
        params[key] = val;
      });
    }

    var viewName = ROUTE_MAP[path] || 'dashboard';
    return {
      path: path,
      view: viewName,
      params: params,
    };
  }

  function navigate(viewOrPath, params) {
    var path = VIEW_TO_HASH[viewOrPath] || viewOrPath || 'overview';
    var qs = '';
    if (params && typeof params === 'object') {
      var searchParams = new URLSearchParams();
      Object.keys(params).forEach(function (k) {
        var v = params[k];
        if (v !== undefined && v !== null && v !== '') {
          searchParams.append(k, String(v));
        }
      });
      var str = searchParams.toString();
      if (str) {
        qs = '?' + str;
      }
    }
    window.location.hash = '/' + path + qs;
  }

  function handleHashChange() {
    var route = parseHash();
    if (window.OsirisApp && typeof window.OsirisApp.switchView === 'function') {
      window.OsirisApp.switchView(route.view, false);
    }
    routeChangeListeners.forEach(function (cb) {
      try {
        cb(route);
      } catch (err) {
        // suppressed
      }
    });
  }

  function on(cb) {
    if (typeof cb === 'function') {
      routeChangeListeners.push(cb);
    }
  }

  function init() {
    window.addEventListener('hashchange', handleHashChange);
    // Parse initial route
    setTimeout(function () {
      if (window.location.hash) {
        handleHashChange();
      }
    }, 50);
  }

  window.OsirisRouter = Object.freeze({
    init: init,
    parseHash: parseHash,
    navigate: navigate,
    navigateTo: navigate,
    on: on,
    ROUTE_MAP: ROUTE_MAP,
    VIEW_TO_HASH: VIEW_TO_HASH,
  });

})(typeof window !== 'undefined' ? window : this);
