/**
 * OSIRIS Unified Digital Forensics Platform - Real-time WebSocket Client
 *
 * Responsibilities:
 * - Authenticated single-use ticket handshake via first-message protocol (no URL ticket leakage).
 * - Automatic reconnection with bounded exponential backoff and jitter.
 * - Host switching: explicit unsubscription of previous host and scoping to active host.
 * - Stale message isolation: prevents cross-host telemetry leakage during rapid host switching.
 * - Event deduplication and cursor tracking (last_event_id, timestamp).
 * - Missed event replay recovery upon reconnection.
 * - Automated REST fallback polling during network disconnects.
 * - Structured event dispatching to view controllers.
 */

(function (window) {
  'use strict';

  var socket = null;
  var isExplicitDisconnect = false;
  var reconnectAttempts = 0;
  var reconnectTimer = null;
  var pingInterval = null;
  var fallbackPollInterval = null;
  var activeHostId = '';
  var connectionState = 'disconnected'; // 'connected' | 'connecting' | 'disconnected'
  var isFallbackActive = false;

  var lastEventId = null;
  var lastEventTimestamp = null;
  var seenEventIds = new Set();
  var MAX_SEEN_IDS = 2000;

  var listeners = {
    event: [],
    resource: [],
    detection: [],
    fim: [],
    incident: [],
    file: [],
    heartbeat: [],
    statusChange: [],
  };

  function updateStatus(state) {
    connectionState = state;
    var badge = document.getElementById('ws-status-badge');
    if (badge) {
      if (state === 'connected') {
        badge.className = 'status-pill status-online';
        badge.textContent = 'Live Stream';
      } else if (state === 'connecting') {
        badge.className = 'status-pill status-warning';
        badge.textContent = 'Connecting...';
      } else {
        badge.className = 'status-pill ' + (isFallbackActive ? 'status-warning' : 'status-offline');
        badge.textContent = isFallbackActive ? 'Polling Fallback' : 'Disconnected';
      }
    }
    listeners.statusChange.forEach(function (cb) {
      try {
        cb(state);
      } catch (err) {
        // suppressed
      }
    });
  }

  function getWsUrl() {
    var protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    var host = window.location.host;
    return protocol + '//' + host + '/ws';
  }

  function startRestFallback() {
    if (fallbackPollInterval || isExplicitDisconnect) return;
    isFallbackActive = true;
    updateStatus(connectionState);

    // Initial immediate poll
    triggerFallbackPoll();

    // Poll every 5s while disconnected
    fallbackPollInterval = setInterval(function () {
      triggerFallbackPoll();
    }, 5000);
  }

  function stopRestFallback() {
    if (fallbackPollInterval) {
      clearInterval(fallbackPollInterval);
      fallbackPollInterval = null;
    }
    isFallbackActive = false;
  }

  function triggerFallbackPoll() {
    if (!window.OsirisApi || !window.OsirisApi.getToken()) return;

    // 1. Refresh global status / collector health
    if (typeof window.OsirisApi.getStatus === 'function') {
      window.OsirisApi.getStatus().then(function (statusData) {
        if (statusData && listeners.heartbeat) {
          listeners.heartbeat.forEach(function (cb) {
            try { cb(statusData, null); } catch (e) {}
          });
        }
      }).catch(function () {});
    }

    // 2. Poll active host view data if relevant
    var hostId = activeHostId || (window.OsirisApi ? window.OsirisApi.getActiveHostId() : '');
    if (hostId) {
      if (window.OsirisResources && typeof window.OsirisResources.loadResources === 'function') {
        window.OsirisResources.loadResources({ force: true });
      }
      if (window.OsirisDetections && typeof window.OsirisDetections.updateSummaryStats === 'function') {
        window.OsirisDetections.updateSummaryStats();
      }
    }
  }

  function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
      return;
    }

    if (!window.OsirisApi || !window.OsirisApi.getToken()) {
      updateStatus('disconnected');
      return;
    }

    isExplicitDisconnect = false;
    updateStatus('connecting');

    window.OsirisApi.getWsTicket()
      .then(function (res) {
        if (!res || !res.ticket) {
          throw new Error('Failed to obtain WebSocket authentication ticket');
        }

        var wsUrl = getWsUrl();
        socket = new WebSocket(wsUrl);

        socket.onopen = function () {
          // Handshake: Deliver single-use ticket as the very first message over WebSocket
          socket.send(JSON.stringify({
            action: 'authenticate',
            ticket: res.ticket,
          }));
        };

        socket.onmessage = function (event) {
          try {
            var msg = JSON.parse(event.data);
            var type = msg.type;

            // Handshake confirmed
            if (type === 'authenticated') {
              reconnectAttempts = 0;
              stopRestFallback();
              updateStatus('connected');

              // Subscribe to currently active host if set
              var hostId = activeHostId || (window.OsirisApi ? window.OsirisApi.getActiveHostId() : '');
              if (hostId) {
                activeHostId = String(hostId).toLowerCase();
                socket.send(JSON.stringify({
                  action: 'subscribe',
                  host_id: activeHostId,
                }));
              }

              // Replay missed events if we have a last seen cursor
              if (lastEventTimestamp || lastEventId) {
                socket.send(JSON.stringify({
                  action: 'replay',
                  host_id: activeHostId || '*',
                  since: lastEventTimestamp,
                  last_event_id: lastEventId,
                  limit: 100,
                }));
              }

              // Start heartbeat ping every 25s
              if (pingInterval) {
                clearInterval(pingInterval);
              }
              pingInterval = setInterval(function () {
                if (socket && socket.readyState === WebSocket.OPEN) {
                  socket.send(JSON.stringify({ action: 'ping' }));
                }
              }, 25000);
              return;
            }

            // Host isolation: Discard events belonging to an inactive host
            if (msg.host_id && activeHostId && type !== 'heartbeat') {
              var msgHost = String(msg.host_id).toLowerCase();
              if (msgHost !== activeHostId) {
                return; // Suppress stale cross-host message
              }
            }

            // Deduplication: Suppress duplicate events (at-least-once recovery safeguard)
            if (msg.data && msg.data.id) {
              var itemId = String(msg.data.id);
              if (seenEventIds.has(itemId)) {
                return; // Duplicate suppressed
              }
              seenEventIds.add(itemId);
              if (seenEventIds.size > MAX_SEEN_IDS) {
                var first = seenEventIds.values().next().value;
                seenEventIds.delete(first);
              }

              // Update cursor
              lastEventId = itemId;
              if (msg.data.timestamp) {
                lastEventTimestamp = msg.data.timestamp;
              }
            }

            // Dispatch to registered listeners
            if (type && listeners[type]) {
              listeners[type].forEach(function (cb) {
                try {
                  cb(msg.data, msg.host_id);
                } catch (err) {
                  // callback error suppressed
                }
              });
            }
          } catch (err) {
            // malformed json suppressed
          }
        };

        socket.onclose = function () {
          if (pingInterval) {
            clearInterval(pingInterval);
            pingInterval = null;
          }
          updateStatus('disconnected');
          if (!isExplicitDisconnect) {
            startRestFallback();
            scheduleReconnect();
          }
        };

        socket.onerror = function () {
          if (socket) {
            socket.close();
          }
        };
      })
      .catch(function () {
        updateStatus('disconnected');
        if (!isExplicitDisconnect) {
          startRestFallback();
          scheduleReconnect();
        }
      });
  }

  function scheduleReconnect() {
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
    }
    reconnectAttempts += 1;
    // Bounded exponential backoff with jitter: min 1s, max 30s
    var delay = Math.min(30000, Math.pow(1.5, reconnectAttempts) * 1000);
    var jitter = (Math.random() - 0.5) * 1000;
    var finalDelay = Math.max(1000, delay + jitter);

    reconnectTimer = setTimeout(function () {
      connect();
    }, finalDelay);
  }

  function disconnect() {
    isExplicitDisconnect = true;
    stopRestFallback();
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    if (pingInterval) {
      clearInterval(pingInterval);
      pingInterval = null;
    }
    if (socket) {
      if (activeHostId && socket.readyState === WebSocket.OPEN) {
        try {
          socket.send(JSON.stringify({
            action: 'unsubscribe',
            host_id: activeHostId,
          }));
        } catch (e) {}
      }
      socket.close();
      socket = null;
    }
    activeHostId = '';
    updateStatus('disconnected');
  }

  function subscribeHost(hostId) {
    var newHost = hostId ? String(hostId).toLowerCase() : '';
    // Unsubscribe from previous host if switching
    if (activeHostId && activeHostId !== newHost && socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        action: 'unsubscribe',
        host_id: activeHostId,
      }));
    }

    activeHostId = newHost;
    if (socket && socket.readyState === WebSocket.OPEN && activeHostId) {
      socket.send(JSON.stringify({
        action: 'subscribe',
        host_id: activeHostId,
      }));
    }
  }

  function unsubscribeHost(hostId) {
    var h = hostId ? String(hostId).toLowerCase() : activeHostId;
    if (socket && socket.readyState === WebSocket.OPEN && h) {
      socket.send(JSON.stringify({
        action: 'unsubscribe',
        host_id: h,
      }));
    }
    if (activeHostId === h) {
      activeHostId = '';
    }
  }

  function on(type, callback) {
    if (listeners[type] && typeof callback === 'function') {
      listeners[type].push(callback);
    }
  }

  function off(type, callback) {
    if (listeners[type]) {
      listeners[type] = listeners[type].filter(function (cb) {
        return cb !== callback;
      });
    }
  }

  function onStatusChange(callback) {
    on('statusChange', callback);
  }

  function onEvent(callback) {
    if (typeof callback !== 'function') return;
    ['event', 'resource', 'detection', 'fim', 'incident', 'file', 'heartbeat'].forEach(function (type) {
      on(type, function (data, hostId) {
        callback({ type: type, host_id: hostId, data: data });
      });
    });
  }

  function getStatus() {
    return connectionState;
  }

  function getLastEventId() {
    return lastEventId;
  }

  function getLastEventTimestamp() {
    return lastEventTimestamp;
  }

  function isFallbackMode() {
    return isFallbackActive;
  }

  window.OsirisWs = Object.freeze({
    connect: connect,
    disconnect: disconnect,
    subscribeHost: subscribeHost,
    unsubscribeHost: unsubscribeHost,
    on: on,
    off: off,
    onStatusChange: onStatusChange,
    onEvent: onEvent,
    getStatus: getStatus,
    getLastEventId: getLastEventId,
    getLastEventTimestamp: getLastEventTimestamp,
    isFallbackMode: isFallbackMode,
  });

})(typeof window !== 'undefined' ? window : this);
