"""Pydantic schemas for Host API routes."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class HostResponse(BaseModel):
    """Schema for monitored host metadata."""

    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    hostname: str
    os_info: Optional[str] = None
    ip_address: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    status: str = "online"
    last_seen_at: Optional[datetime] = None


class PaginatedHostResponse(BaseModel):
    """Paginated list of monitored hosts."""

    total: int = Field(..., ge=0, description="Total number of matching hosts")
    items: list[HostResponse] = Field(..., description="Page items")
    limit: int = Field(..., ge=1, description="Page limit")
    offset: int = Field(..., ge=0, description="Page offset")


class HostQueryParams(BaseModel):
    """Query parameters for filtering and paginating hosts."""

    search: Optional[str] = Field(None, description="Search hostname or IP address")
    limit: int = Field(50, ge=1, le=500, description="Page size")
    offset: int = Field(0, ge=0, description="Page offset")
