"""WebSocket Connection Manager and real-time event broadcasting for OSIRIS.

Provides:
- In-memory single-use short-lived tickets with TTL cleanup.
- Bounded, priority-aware client message queues preventing critical event loss.
- High-frequency resource/heartbeat coalescing under backpressure.
- Role-based and host-scoped subscription authorization.
- Cross-process IPC notification hydration and dispatching.
- Event replay recovery for reconnected clients.
"""

from __future__ import annotations

import asyncio
import collections
import logging
import time
import uuid
from typing import Any, Callable

from fastapi import WebSocket
from sqlalchemy.orm import Session

logger = logging.getLogger("osiris.api.websocket")

# In-memory single-use short-lived tickets (valid for 30 seconds)
_ws_tickets: dict[str, dict[str, Any]] = {}
_TICKET_TTL_SECONDS = 30.0


def issue_ws_ticket(
    user_id: uuid.UUID | str,
    username: str,
    role: str,
    allowed_hosts: list[str] | None = None,
) -> str:
    """Issue a single-use short-lived ticket for WebSocket handshake authentication."""
    _clean_expired_tickets()
    ticket = str(uuid.uuid4())
    _ws_tickets[ticket] = {
        "user_id": str(user_id),
        "username": username,
        "role": role,
        "allowed_hosts": allowed_hosts,
        "expires_at": time.time() + _TICKET_TTL_SECONDS,
    }
    return ticket


def validate_and_consume_ws_ticket(ticket: str | None) -> dict[str, Any] | None:
    """Validate and immediately consume a single-use WebSocket ticket."""
    if not ticket:
        return None
    _clean_expired_tickets()
    info = _ws_tickets.pop(ticket, None)
    if info is None:
        return None
    if time.time() > info["expires_at"]:
        return None
    return info


def _clean_expired_tickets() -> None:
    """Remove expired tickets from memory."""
    now = time.time()
    expired = [k for k, v in _ws_tickets.items() if v["expires_at"] < now]
    for k in expired:
        _ws_tickets.pop(k, None)


def is_host_authorized(user_info: dict[str, Any], host_id: str) -> bool:
    """Validate if authenticated user has permission to subscribe to target host."""
    if not host_id or not isinstance(host_id, str):
        return False
    target = host_id.strip()
    role = user_info.get("role", "viewer")

    # Wildcard subscriptions strictly require admin role
    if target == "*":
        return role == "admin"

    # Explicit allowed_hosts whitelist on ticket if provided
    allowed_hosts = user_info.get("allowed_hosts")
    if allowed_hosts is not None:
        target_lower = target.lower()
        allowed_lower = [str(h).lower() for h in allowed_hosts]
        return target_lower in allowed_lower

    # Otherwise validate that host_id is a valid UUID or registered server host
    try:
        uuid.UUID(target)
        return True
    except ValueError:
        from backend.config import settings

        return target == settings.host_id


class ConnectionMessageQueue:
    """Bounded, priority-aware outgoing message queue for a WebSocket client.

    Guarantees:
    - Critical detections (type 'detection' or severity 'critical'/'high')
      are NEVER dropped.
    - High-frequency resource updates and heartbeats are coalesced under backpressure.
    - FIFO ordering for same-priority messages.
    - Strict memory boundary: non-critical queue size capped, critical buffer bounded.
    - Backpressure metrics: tracks dropped, coalesced, and overflow occurrences.
    """

    def __init__(self, maxsize: int = 100, critical_limit: int = 500) -> None:
        self.maxsize = maxsize
        self.critical_limit = critical_limit
        self._queue: collections.deque[dict[str, Any]] = collections.deque()
        self._cv = asyncio.Condition()
        self.dropped_count: int = 0
        self.coalesced_count: int = 0
        self.overflow_count: int = 0

    @staticmethod
    def is_critical(envelope: dict[str, Any]) -> bool:
        """Determine if envelope carries a critical security event or detection."""
        msg_type = envelope.get("type")
        data = envelope.get("data", {})
        if msg_type == "detection":
            return True
        if msg_type == "event" and isinstance(data, dict):
            sev = str(data.get("severity", "")).lower()
            if sev in ("critical", "high"):
                return True
        return False

    async def put(self, envelope: dict[str, Any]) -> bool:
        """Enqueue envelope with backpressure, coalescing, and priority preservation."""
        async with self._cv:
            msg_type = envelope.get("type")
            critical = self.is_critical(envelope)

            if len(self._queue) >= self.maxsize:
                self.overflow_count += 1
                if not critical:
                    # Attempt coalescing for high-frequency updates
                    if msg_type in ("resource", "heartbeat"):
                        for i in range(len(self._queue) - 1, -1, -1):
                            if self._queue[i].get("type") == msg_type:
                                self._queue[i] = envelope
                                self.coalesced_count += 1
                                self._cv.notify()
                                return True
                        self.dropped_count += 1
                        logger.warning(
                            "WebSocket queue full: dropping non-critical %s "
                            "(total dropped: %d)",
                            msg_type,
                            self.dropped_count,
                        )
                        return False
                    else:
                        # Drop oldest non-critical item in queue
                        for idx, item in enumerate(self._queue):
                            if not self.is_critical(item):
                                del self._queue[idx]
                                self.dropped_count += 1
                                self._queue.append(envelope)
                                self._cv.notify()
                                return True
                        # Entire queue is critical; drop incoming non-critical
                        self.dropped_count += 1
                        logger.warning(
                            "WebSocket queue full of critical items: dropping %s",
                            msg_type,
                        )
                        return False
                else:
                    # Incoming message IS CRITICAL: MUST NEVER BE SILENTLY DISCARDED!
                    for idx, item in enumerate(self._queue):
                        if not self.is_critical(item):
                            del self._queue[idx]
                            self.dropped_count += 1
                            self._queue.append(envelope)
                            self._cv.notify()
                            return True
                    # All items are critical; allow expansion up to critical_limit
                    if len(self._queue) < self.critical_limit:
                        self._queue.append(envelope)
                        logger.warning(
                            "WebSocket queue saturated with critical detections "
                            "(size: %d/%d)",
                            len(self._queue),
                            self.critical_limit,
                        )
                        self._cv.notify()
                        return True
                    else:
                        logger.error(
                            "CRITICAL QUEUE EXHAUSTION: queue hit limit %d",
                            self.critical_limit,
                        )
                        self._queue.popleft()
                        self.dropped_count += 1
                        self._queue.append(envelope)
                        self._cv.notify()
                        return True

            self._queue.append(envelope)
            self._cv.notify()
            return True

    async def get(self) -> dict[str, Any]:
        """Dequeue oldest envelope, waiting asynchronously until available."""
        async with self._cv:
            while not self._queue:
                await self._cv.wait()
            return self._queue.popleft()

    def qsize(self) -> int:
        """Return current queue depth."""
        return len(self._queue)


class WebSocketManager:
    """Manages authenticated WebSocket connections, host subs, and IPC delivery."""

    def __init__(self, session_factory: Callable[[], Session] | None = None) -> None:
        self._connections: dict[WebSocket, dict[str, Any]] = {}
        self._lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None
        self.total_dropped_messages: int = 0
        self.total_coalesced_messages: int = 0
        self._session_factory = session_factory

    def get_session(self) -> Session:
        """Provide a database session via custom factory or fallback to SessionLocal."""
        if self._session_factory is not None:
            return self._session_factory()
        from backend.db.session import SessionLocal

        return SessionLocal()

    def has_active_connections(self) -> bool:
        """Return True if at least one client is currently connected."""
        return len(self._connections) > 0

    def get_stats(self) -> dict[str, Any]:
        """Return operational and backpressure metrics."""
        active = len(self._connections)
        current_queued = sum(
            info["queue"].qsize() for info in self._connections.values()
        )
        dropped = self.total_dropped_messages + sum(
            info["queue"].dropped_count for info in self._connections.values()
        )
        coalesced = self.total_coalesced_messages + sum(
            info["queue"].coalesced_count for info in self._connections.values()
        )
        overflows = sum(
            info["queue"].overflow_count for info in self._connections.values()
        )
        return {
            "active_connections": active,
            "current_queued_messages": current_queued,
            "total_dropped_messages": dropped,
            "total_coalesced_messages": coalesced,
            "total_overflow_events": overflows,
        }

    async def connect(self, websocket: WebSocket, user_info: dict[str, Any]) -> None:
        """Accept WebSocket connection and initialize bounded priority queue."""
        if self._loop is None or self._loop.is_closed():
            try:
                self._loop = asyncio.get_running_loop()
            except RuntimeError:
                pass

        queue = ConnectionMessageQueue(maxsize=100, critical_limit=500)
        task = asyncio.create_task(self._send_loop(websocket, queue))
        async with self._lock:
            self._connections[websocket] = {
                "user": user_info,
                "subscriptions": set(),
                "queue": queue,
                "task": task,
            }
        logger.info(
            "WebSocket client connected for user: %s (active: %d)",
            user_info.get("username"),
            len(self._connections),
        )

    async def disconnect(self, websocket: WebSocket) -> None:
        """Remove connection and cancel background worker task."""
        async with self._lock:
            info = self._connections.pop(websocket, None)
        if info:
            queue: ConnectionMessageQueue = info["queue"]
            self.total_dropped_messages += queue.dropped_count
            self.total_coalesced_messages += queue.coalesced_count
            task: asyncio.Task = info["task"]
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        logger.info(
            "WebSocket client disconnected (remaining: %d)", len(self._connections)
        )

    def subscribe(self, websocket: WebSocket, host_id: str) -> bool:
        """Subscribe websocket to updates for a specific authorized host."""
        if websocket not in self._connections:
            return False
        user_info = self._connections[websocket]["user"]
        if not is_host_authorized(user_info, host_id):
            logger.warning(
                "Unauthorized host subscription attempt by %s for host %s",
                user_info.get("username"),
                host_id,
            )
            return False
        self._connections[websocket]["subscriptions"].add(str(host_id).lower())
        return True

    def unsubscribe(self, websocket: WebSocket, host_id: str) -> None:
        """Unsubscribe websocket from a specific host."""
        if websocket in self._connections:
            self._connections[websocket]["subscriptions"].discard(str(host_id).lower())

    async def _send_loop(
        self, websocket: WebSocket, queue: ConnectionMessageQueue
    ) -> None:
        """Background task sending messages to client with backpressure."""
        try:
            while True:
                msg = await queue.get()
                await websocket.send_json(msg)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.debug("WebSocket send error: %s", exc)

    async def broadcast_message(
        self, msg_type: str, host_id: str | None, data: dict[str, Any]
    ) -> None:
        """Deliver a structured message to interested client connections."""
        target_host = str(host_id).lower() if host_id else None
        envelope = {
            "type": msg_type,
            "host_id": host_id,
            "timestamp": time.time(),
            "data": data,
        }

        async with self._lock:
            connections = list(self._connections.items())

        for ws, info in connections:
            subs = info["subscriptions"]
            if target_host is None or target_host in subs or "*" in subs:
                queue: ConnectionMessageQueue = info["queue"]
                await queue.put(envelope)

    async def broadcast_event(self, host_id: str, event_data: dict[str, Any]) -> None:
        """Broadcast persisted event observation."""
        await self.broadcast_message("event", host_id, event_data)

    async def broadcast_resource(
        self, host_id: str, resource_data: dict[str, Any]
    ) -> None:
        """Broadcast resource telemetry sample."""
        await self.broadcast_message("resource", host_id, resource_data)

    async def broadcast_detection(
        self, host_id: str, detection_data: dict[str, Any]
    ) -> None:
        """Broadcast security detection."""
        await self.broadcast_message("detection", host_id, detection_data)

    async def broadcast_heartbeat(self, status_data: dict[str, Any]) -> None:
        """Broadcast collector / system heartbeat."""
        await self.broadcast_message("heartbeat", None, status_data)

    def broadcast_sync(
        self, msg_type: str, host_id: str | None, data: dict[str, Any]
    ) -> None:
        """Deliver a structured message safely from synchronous threads or routes."""
        target_loop = None
        try:
            target_loop = asyncio.get_running_loop()
        except RuntimeError:
            if self._loop is not None and not self._loop.is_closed():
                target_loop = self._loop

        if target_loop is not None and not target_loop.is_closed():
            asyncio.run_coroutine_threadsafe(
                self.broadcast_message(msg_type, host_id, data),
                target_loop,
            )

        # Cross-process IPC delivery
        try:
            from backend.services.events.ipc_broadcast import send_ipc_notification

            item_id = data.get("id") if isinstance(data, dict) else None
            ipc_payload = {
                "type": msg_type,
                "host_id": host_id,
                "id": str(item_id) if item_id else None,
                "data": data if msg_type == "heartbeat" else None,
            }
            send_ipc_notification(ipc_payload)
        except Exception as ipc_err:
            logger.debug("IPC broadcast notification skipped: %s", ipc_err)

    async def replay_events_for_client(
        self,
        websocket: WebSocket,
        host_id: str,
        since: str | None = None,
        last_event_id: str | None = None,
        limit: int = 100,
        session: Session | None = None,
    ) -> None:
        """Replay missed persisted events from the database after client reconnect."""
        from sqlalchemy import select

        from backend.db.models.event import Event

        close_session = False
        if session is None:
            session = self.get_session()
            close_session = True
        try:
            stmt = select(Event).order_by(Event.timestamp.asc(), Event.id.asc())
            if host_id != "*":
                try:
                    h_uuid = uuid.UUID(host_id)
                    stmt = stmt.where(Event.host_id == h_uuid)
                except ValueError:
                    pass

            last_ev = None
            if last_event_id:
                try:
                    last_ev_uuid = uuid.UUID(str(last_event_id))
                    last_ev = session.get(Event, last_ev_uuid)
                except (ValueError, TypeError):
                    pass

            if last_ev is not None:
                stmt = stmt.where(
                    (Event.timestamp > last_ev.timestamp)
                    | ((Event.timestamp == last_ev.timestamp) & (Event.id > last_ev.id))
                )
            elif since:
                try:
                    from datetime import datetime

                    dt = datetime.fromisoformat(since.replace("Z", "+00:00"))
                    stmt = stmt.where(Event.timestamp >= dt)
                except Exception:
                    pass

            bounded_limit = max(1, min(limit, 500))
            stmt = stmt.limit(bounded_limit)
            events = session.execute(stmt).scalars().all()

            await websocket.send_json(
                {
                    "type": "replay_start",
                    "host_id": host_id,
                    "count": len(events),
                }
            )

            for ev in events:
                if last_event_id and str(ev.id) == str(last_event_id):
                    continue
                payload = {
                    "id": str(ev.id),
                    "event_type": ev.event_type,
                    "source": ev.source,
                    "severity": ev.severity,
                    "timestamp": (
                        ev.timestamp.isoformat()
                        if hasattr(ev.timestamp, "isoformat")
                        else str(ev.timestamp)
                    ),
                    "process_id": str(ev.process_id) if ev.process_id else None,
                    "pid": ev.pid,
                    "uid": ev.uid,
                    "username": ev.username,
                    "action": ev.action,
                }
                await websocket.send_json(
                    {
                        "type": "event",
                        "host_id": str(ev.host_id),
                        "timestamp": time.time(),
                        "data": payload,
                        "is_replay": True,
                    }
                )

            await websocket.send_json(
                {
                    "type": "replay_end",
                    "host_id": host_id,
                    "replayed": len(events),
                }
            )
        except Exception as exc:
            logger.error("Error replaying events for client: %s", exc)
        finally:
            if close_session and session is not None:
                session.close()

    async def handle_ipc_notification(
        self,
        payload: dict[str, Any],
        session: Session | None = None,
    ) -> None:
        """Hydrate authoritative record from DB and broadcast to WebSockets."""
        msg_type = payload.get("type")
        record_id = payload.get("id")
        ids = payload.get("ids", [])
        if record_id and not ids:
            ids = [record_id]

        if not ids and msg_type != "heartbeat":
            return

        close_session = False
        if session is None:
            session = self.get_session()
            close_session = True
        try:
            if msg_type == "event" or payload.get("table") == "events":
                from sqlalchemy import select

                from backend.db.models.event import Event

                parsed_uuids = []
                for raw_id in ids:
                    try:
                        parsed_uuids.append(uuid.UUID(str(raw_id)))
                    except ValueError:
                        pass
                if parsed_uuids:
                    stmt = (
                        select(Event)
                        .where(Event.id.in_(parsed_uuids))
                        .order_by(Event.timestamp.asc())
                    )
                    events = session.execute(stmt).scalars().all()
                    for ev in events:
                        ev_data = {
                            "id": str(ev.id),
                            "event_type": ev.event_type,
                            "source": ev.source,
                            "severity": ev.severity,
                            "timestamp": (
                                ev.timestamp.isoformat()
                                if hasattr(ev.timestamp, "isoformat")
                                else str(ev.timestamp)
                            ),
                            "process_id": (
                                str(ev.process_id) if ev.process_id else None
                            ),
                            "pid": ev.pid,
                            "uid": ev.uid,
                            "username": ev.username,
                            "action": ev.action,
                            "command": ev.command,
                        }
                        await self.broadcast_event(str(ev.host_id), ev_data)

            elif msg_type == "detection" or payload.get("table") == "detections":
                from sqlalchemy import select

                from backend.db.models.detection import Detection

                for raw_id in ids:
                    try:
                        det_uuid = uuid.UUID(str(raw_id))
                        det_stmt = select(Detection).where(Detection.id == det_uuid)
                        det = session.execute(det_stmt).scalar_one_or_none()
                        if det:
                            det_data = {
                                "id": str(det.id),
                                "rule_id": str(det.rule_id),
                                "title": det.title,
                                "severity": det.severity,
                                "category": det.category,
                                "status": det.status,
                                "timestamp": (
                                    det.timestamp.isoformat()
                                    if hasattr(det.timestamp, "isoformat")
                                    else str(det.timestamp)
                                ),
                                "host_id": str(det.host_id),
                                "event_id": (
                                    str(det.event_id) if det.event_id else None
                                ),
                                "process_id": (
                                    str(det.process_id) if det.process_id else None
                                ),
                                "matched_conditions": det.matched_conditions,
                                "evidence": det.evidence,
                            }
                            await self.broadcast_detection(str(det.host_id), det_data)
                    except Exception as det_err:
                        logger.debug(
                            "Error hydrating detection %s: %s", raw_id, det_err
                        )

            elif msg_type == "resource" or payload.get("table") == "resource_snapshots":
                from sqlalchemy import select

                from backend.db.models.resource_snapshot import ResourceSnapshot

                for raw_id in ids:
                    try:
                        res_uuid = uuid.UUID(str(raw_id))
                        res_stmt = select(ResourceSnapshot).where(
                            ResourceSnapshot.id == res_uuid
                        )
                        res = session.execute(res_stmt).scalar_one_or_none()
                        if res:
                            res_data = {
                                "id": str(res.id),
                                "host_id": str(res.host_id),
                                "timestamp": (
                                    res.timestamp.isoformat()
                                    if hasattr(res.timestamp, "isoformat")
                                    else str(res.timestamp)
                                ),
                                "cpu_percent": res.cpu_percent,
                                "memory_percent": res.memory_percent,
                                "memory_used": res.memory_used,
                                "memory_total": res.memory_total,
                                "disk_read_bytes": res.disk_read_bytes,
                                "disk_write_bytes": res.disk_write_bytes,
                                "disk_usage_percent": res.disk_usage_percent,
                            }
                            await self.broadcast_resource(str(res.host_id), res_data)
                    except Exception as res_err:
                        logger.debug("Error hydrating resource %s: %s", raw_id, res_err)

            elif msg_type == "heartbeat":
                from backend.services.events.ipc_broadcast import (
                    verify_and_hydrate_heartbeat,
                )

                auth_heartbeat = verify_and_hydrate_heartbeat(payload.get("data"))
                if auth_heartbeat is not None:
                    await self.broadcast_heartbeat(auth_heartbeat)
                else:
                    logger.warning(
                        "Rejecting unverified or spoofed heartbeat notification: %s",
                        payload,
                    )
        except Exception as exc:
            logger.error("IPC notification hydration error: %s", exc)
        finally:
            if close_session and session is not None:
                session.close()


# Global singleton manager
ws_manager = WebSocketManager()
