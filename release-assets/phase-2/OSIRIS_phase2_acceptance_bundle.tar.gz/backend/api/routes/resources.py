"""Resource snapshot route handlers for OSIRIS Phase 1.5 Backend API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from backend.api.deps import get_current_user, get_db
from backend.api.schemas.resources import (
    PaginatedResourceSnapshotResponse,
    ResourceSnapshotQueryParams,
    ResourceSnapshotResponse,
)
from backend.db.models.app_user import AppUser
from backend.db.models.event import Event
from backend.db.models.resource_snapshot import ResourceSnapshot

router = APIRouter()


@router.get("", response_model=PaginatedResourceSnapshotResponse)
def list_resource_snapshots(
    params: ResourceSnapshotQueryParams = Depends(),
    db: Session = Depends(get_db),
    current_user: AppUser = Depends(get_current_user),
) -> PaginatedResourceSnapshotResponse:
    """List point-in-time system resource snapshots with filtering and pagination.

    Supported query parameters:
    - host_id: UUID of monitored host
    - start_time: Earliest snapshot timestamp (inclusive)
    - end_time: Latest snapshot timestamp (inclusive)
    - limit: Page size (default 50, minimum 1)
    - offset: Page offset (default 0, minimum 0)
    """
    if params.start_time and params.end_time:
        try:
            if params.start_time > params.end_time:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="start_time must be less than or equal to end_time",
                )
        except TypeError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot compare timezone-aware and naive datetimes",
            )

    conditions = []
    if params.host_id is not None:
        conditions.append(ResourceSnapshot.host_id == params.host_id)
    if params.start_time is not None:
        conditions.append(ResourceSnapshot.timestamp >= params.start_time)
    if params.end_time is not None:
        conditions.append(ResourceSnapshot.timestamp <= params.end_time)
    # 1. Total count query over filtered records
    count_stmt = select(func.count(ResourceSnapshot.id))
    if conditions:
        count_stmt = count_stmt.where(*conditions)
    total = db.scalar(count_stmt) or 0

    order_func = (
        ResourceSnapshot.timestamp.desc()
        if params.order == "desc"
        else ResourceSnapshot.timestamp.asc()
    )
    id_order_func = (
        ResourceSnapshot.id.desc()
        if params.order == "desc"
        else ResourceSnapshot.id.asc()
    )

    if total > 0:
        # 2. Paged items query with deterministic ordering
        stmt = select(ResourceSnapshot)
        if conditions:
            stmt = stmt.where(*conditions)
        stmt = (
            stmt.order_by(order_func, id_order_func)
            .offset(params.offset)
            .limit(params.limit)
        )

        orm_snapshots = db.execute(stmt).scalars().all()
        items = [ResourceSnapshotResponse.model_validate(s) for s in orm_snapshots]
    else:
        # Project from Event table where event_type == 'resource.snapshot'
        ev_conditions = [Event.event_type == "resource.snapshot"]
        if params.host_id is not None:
            ev_conditions.append(Event.host_id == params.host_id)
        if params.start_time is not None:
            ev_conditions.append(Event.timestamp >= params.start_time)
        if params.end_time is not None:
            ev_conditions.append(Event.timestamp <= params.end_time)

        ev_count_stmt = select(func.count(Event.id)).where(*ev_conditions)
        total = db.scalar(ev_count_stmt) or 0

        ev_order_func = (
            Event.timestamp.desc()
            if params.order == "desc"
            else Event.timestamp.asc()
        )
        ev_id_order_func = (
            Event.id.desc()
            if params.order == "desc"
            else Event.id.asc()
        )
        ev_stmt = (
            select(Event)
            .where(*ev_conditions)
            .order_by(ev_order_func, ev_id_order_func)
            .offset(params.offset)
            .limit(params.limit)
        )
        events = db.execute(ev_stmt).scalars().all()
        items = []
        for ev in events:
            payload = ev.payload or {}
            items.append(
                ResourceSnapshotResponse(
                    id=ev.id,
                    host_id=ev.host_id,
                    timestamp=ev.timestamp,
                    cpu_percent=payload.get("cpu_percent"),
                    memory_total=payload.get("memory_total"),
                    memory_used=payload.get("memory_used"),
                    memory_percent=payload.get("memory_percent"),
                    disk_read_bytes=payload.get("disk_read_bytes"),
                    disk_write_bytes=payload.get("disk_write_bytes"),
                    disk_usage_percent=payload.get("disk_usage_percent"),
                    created_at=ev.created_at,
                )
            )

    return PaginatedResourceSnapshotResponse(
        total=total,
        items=items,
        limit=params.limit,
        offset=params.offset,
    )
