"""Host route handlers for OSIRIS."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from backend.api.deps import get_current_user, get_db
from backend.api.schemas.hosts import (
    HostQueryParams,
    HostResponse,
    PaginatedHostResponse,
)
from backend.db.models.app_user import AppUser
from backend.db.models.event import Event
from backend.db.models.host import Host

router = APIRouter()


def _get_host_last_seen(
    db: Session, host_id: uuid.UUID
) -> tuple[Optional[datetime], str]:
    """Determine host's last seen timestamp and operational status."""
    stmt = select(func.max(Event.timestamp)).where(Event.host_id == host_id)
    last_event_ts = db.scalar(stmt)
    if last_event_ts is None:
        return None, "offline"

    # Ensure UTC timezone
    if last_event_ts.tzinfo is None:
        last_event_ts = last_event_ts.replace(tzinfo=timezone.utc)

    now = datetime.now(timezone.utc)
    if now - last_event_ts <= timedelta(minutes=10):
        return last_event_ts, "online"
    return last_event_ts, "offline"


@router.get("", response_model=PaginatedHostResponse)
def list_hosts(
    params: HostQueryParams = Depends(),
    db: Session = Depends(get_db),
    current_user: AppUser = Depends(get_current_user),
) -> PaginatedHostResponse:
    """List monitored hosts with filtering and pagination.

    Supported query parameters:
    - search: Case-insensitive substring match on hostname or ip_address.
    - limit: Page size (default 50, minimum 1, maximum 500).
    - offset: Page offset (default 0, minimum 0).
    """
    conditions = []
    if params.search:
        term = f"%{params.search}%"
        conditions.append(
            or_(
                Host.hostname.ilike(term),
                Host.ip_address.ilike(term),
            )
        )

    count_stmt = select(func.count(Host.id))
    if conditions:
        count_stmt = count_stmt.where(*conditions)
    total = db.scalar(count_stmt) or 0

    stmt = select(Host)
    if conditions:
        stmt = stmt.where(*conditions)
    stmt = (
        stmt.order_by(Host.hostname.asc(), Host.id.asc())
        .offset(params.offset)
        .limit(params.limit)
    )

    orm_hosts = db.execute(stmt).scalars().all()
    items: list[HostResponse] = []
    for h in orm_hosts:
        last_seen, host_status = _get_host_last_seen(db, h.id)
        items.append(
            HostResponse(
                id=h.id,
                hostname=h.hostname,
                os_info=h.os_info,
                ip_address=h.ip_address,
                created_at=h.created_at,
                updated_at=h.updated_at,
                status=host_status,
                last_seen_at=last_seen,
            )
        )

    return PaginatedHostResponse(
        total=total,
        items=items,
        limit=params.limit,
        offset=params.offset,
    )


@router.get("/{host_id}", response_model=HostResponse)
def get_host(
    host_id: uuid.UUID,
    db: Session = Depends(get_db),
    current_user: AppUser = Depends(get_current_user),
) -> HostResponse:
    """Retrieve details for a single monitored host."""
    host = db.get(Host, host_id)
    if not host:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Host with ID '{host_id}' not found",
        )

    last_seen, host_status = _get_host_last_seen(db, host.id)
    return HostResponse(
        id=host.id,
        hostname=host.hostname,
        os_info=host.os_info,
        ip_address=host.ip_address,
        created_at=host.created_at,
        updated_at=host.updated_at,
        status=host_status,
        last_seen_at=last_seen,
    )
