"""Cross-Process IPC Transport for OSIRIS Event Broadcasting.

Provides genuine inter-process communication between collector daemons and the
FastAPI/WebSocket backend across separate OS processes.

Supports:
1. PostgreSQL LISTEN/NOTIFY for low-latency wake-up when running on PostgreSQL.
2. Local Unix Domain Socket (UDS) with strict permission enforcement (mode 0660),
   SO_PEERCRED authentication, size bounding, and rate-limiting.
3. Durable database hydration: notifications carry compact IDs; the receiving backend
   queries the authoritative persisted records from the database before broadcasting.
4. Authoritative collector health verification rejecting untrusted heartbeat injection.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import select
import socket
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Awaitable, Callable

logger = logging.getLogger("osiris.services.ipc")

DEFAULT_PG_CHANNEL = "osiris_events"
DEFAULT_BACKEND_RUNTIME_DIR = "/run/osiris"
DEFAULT_COLLECTOR_RUNTIME_DIR = "/run/osiris-collector"
DEFAULT_IPC_SOCK_NAME = "osiris_ipc.sock"
MAX_IPC_MESSAGE_SIZE = 65536  # 64 KB maximum message size
ALLOWED_IPC_TYPES = frozenset({"event", "detection", "resource", "heartbeat"})


def get_private_dev_runtime_dir() -> Path:
    """Resolve a private, per-user, per-instance directory with mode 0700.

    Used exclusively for development or non-standard environments where the
    systemd-managed /run/osiris runtime directory is unavailable.
    """
    try:
        repo_root = Path(__file__).resolve().parents[3]
    except Exception:
        repo_root = Path.cwd()
    inst_hash = hashlib.sha256(str(repo_root).encode("utf-8")).hexdigest()[:12]
    uid = os.geteuid() if hasattr(os, "geteuid") else 1000
    dev_dir = Path(f"/tmp/osiris_{uid}_{inst_hash}")
    dev_dir.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(str(dev_dir), 0o700)
    except Exception:
        pass
    return dev_dir


def get_ipc_socket_path() -> Path:
    """Resolve active IPC Unix domain socket path.

    Precedence:
    1. Explicit OSIRIS_IPC_SOCK environment variable.
    2. Dedicated protected IPC runtime directory /run/osiris if socket exists or directory is writable.
    3. Private per-user per-instance development runtime directory (mode 0700).

    Insecure shared /tmp/osiris_ipc.sock fallback is strictly prohibited.
    """
    env_path = os.environ.get("OSIRIS_IPC_SOCK")
    if env_path:
        return Path(env_path)

    run_dir = Path(DEFAULT_BACKEND_RUNTIME_DIR)
    if run_dir.exists() and os.access(str(run_dir), os.W_OK | os.R_OK):
        return run_dir / DEFAULT_IPC_SOCK_NAME

    sock_in_run = run_dir / DEFAULT_IPC_SOCK_NAME
    if (
        sock_in_run.exists()
        and not sock_in_run.is_symlink()
        and os.access(str(sock_in_run), os.W_OK)
    ):
        return sock_in_run

    return get_private_dev_runtime_dir() / DEFAULT_IPC_SOCK_NAME


def get_peer_credentials(sock: Any) -> tuple[int, int, int] | None:
    """Retrieve (pid, uid, gid) from Linux Unix domain socket via SO_PEERCRED.

    Returns None if not supported by the platform (e.g. Darwin development).
    """
    so_peercred = getattr(socket, "SO_PEERCRED", None)
    if so_peercred is None and sys.platform.startswith("linux"):
        so_peercred = 17
    if so_peercred is None:
        return None

    try:
        import struct

        # struct ucred: pid_t pid (4B), uid_t uid (4B), gid_t gid (4B) = 12 bytes
        creds = sock.getsockopt(socket.SOL_SOCKET, so_peercred, struct.calcsize("3i"))
        pid, uid, gid = struct.unpack("3i", creds)
        return (pid, uid, gid)
    except Exception as exc:
        logger.debug("SO_PEERCRED extraction failed: %s", exc)
        return None


def is_peer_authorized(
    sock: Any,
    allowed_uids: set[int] | None = None,
    allowed_gids: set[int] | None = None,
) -> bool:
    """Validate connecting process identity using Linux SO_PEERCRED where supported.

    Authorized identities:
    - Root (UID 0): Root-owned unified collector supervisor daemon.
    - Current backend EUID (e.g., 'osiris' service user).
    - Current backend EGID (e.g., 'osiris' service group).
    """
    if sock is None:
        return False

    is_linux = sys.platform.startswith("linux")
    creds = get_peer_credentials(sock)
    if creds is None:
        if is_linux:
            logger.warning(
                "Unauthorized IPC socket connection rejected: "
                "failed to extract SO_PEERCRED on Linux (fail-closed)"
            )
            return False
        # Platform does not support SO_PEERCRED (e.g., macOS development)
        logger.debug(
            "SO_PEERCRED not supported on non-Linux platform (%s); allowing connection in development compatibility mode",
            sys.platform,
        )
        return True

    peer_pid, peer_uid, peer_gid = creds
    if allowed_uids is not None:
        trusted_uids = set(allowed_uids)
    else:
        trusted_uids = {0, os.geteuid()}
        try:
            import pwd

            osiris_uid = pwd.getpwnam("osiris").pw_uid
            trusted_uids.add(osiris_uid)
        except Exception:
            pass

    if allowed_gids is not None:
        trusted_gids = set(allowed_gids)
    else:
        trusted_gids = {os.getegid()}
        try:
            import grp

            osiris_gid = grp.getgrnam("osiris").gr_gid
            trusted_gids.add(osiris_gid)
        except Exception:
            pass

    if peer_uid in trusted_uids or peer_gid in trusted_gids:
        return True

    logger.warning(
        "Unauthorized IPC socket connection rejected: peer pid=%d, uid=%d, gid=%d "
        "(trusted uids: %s, trusted gids: %s)",
        peer_pid,
        peer_uid,
        peer_gid,
        trusted_uids,
        trusted_gids,
    )
    return False


def validate_ipc_payload(payload: Any) -> tuple[bool, str]:
    """Validate incoming IPC message schema and types.

    Enforces:
    - Payload is a JSON dictionary.
    - 'type' is one of: event, detection, resource, heartbeat.
    - For event/detection/resource: requires non-empty 'id' or 'ids' with valid UUIDs.
    - Heartbeats must carry dict data if provided.
    """
    if not isinstance(payload, dict):
        return False, "Payload must be a JSON dictionary"

    msg_type = payload.get("type")
    if not isinstance(msg_type, str) or msg_type not in ALLOWED_IPC_TYPES:
        return False, f"Invalid or missing IPC message type: {msg_type}"

    if msg_type in ("event", "detection", "resource"):
        record_id = payload.get("id")
        ids = payload.get("ids")
        candidate_ids = []
        if record_id is not None:
            candidate_ids.append(record_id)
        if isinstance(ids, list):
            candidate_ids.extend(ids)

        if not candidate_ids:
            return False, f"IPC message type '{msg_type}' requires 'id' or 'ids'"

        for item_id in candidate_ids:
            try:
                uuid.UUID(str(item_id))
            except (ValueError, TypeError):
                return False, f"Invalid UUID in IPC payload: {item_id}"

    elif msg_type == "heartbeat":
        data = payload.get("data")
        if data is not None and not isinstance(data, dict):
            return False, "Heartbeat payload data must be a dictionary"

    return True, ""


def verify_and_hydrate_heartbeat(
    payload_data: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Validate and hydrate heartbeat status from authoritative persisted records.

    Heartbeats must originate from the trusted collector service or an authoritative
    persisted status record. Reject untrusted or unverified heartbeat injection.

    Returns the authoritative status dictionary if verified, or None if rejected.
    """
    candidate_paths = [
        Path(DEFAULT_COLLECTOR_RUNTIME_DIR) / "osiris_collector_health.json",
    ]
    try:
        candidate_paths.append(
            get_private_dev_runtime_dir() / "osiris_collector_health.json"
        )
    except Exception:
        pass

    auth_file: Path | None = None
    for p in candidate_paths:
        if p.exists() and not p.is_symlink():
            auth_file = p
            break

    if auth_file is None:
        logger.warning(
            "Rejecting unverified heartbeat: "
            "no authoritative collector health file exists."
        )
        return None

    try:
        st = auth_file.stat()
        if st.st_mode & 0o002:
            logger.warning(
                "Rejecting heartbeat from world-writable health file: %s",
                auth_file,
            )
            return None

        if auth_file.parent == Path(DEFAULT_COLLECTOR_RUNTIME_DIR):
            if st.st_uid not in (0, os.geteuid()):
                logger.warning(
                    "Rejecting collector health file not owned by root or service user: %s",
                    auth_file,
                )
                return None

        raw_text = auth_file.read_text(encoding="utf-8")
        auth_status = json.loads(raw_text)
        if not isinstance(auth_status, dict):
            return None

        # Verify supervisor process is alive if supervisor_pid is specified
        sup_pid = auth_status.get("supervisor_pid")
        if isinstance(sup_pid, int) and sup_pid > 0:
            try:
                os.kill(sup_pid, 0)
            except OSError as err:
                import errno

                if err.errno == errno.ESRCH:
                    logger.warning(
                        "Collector supervisor PID %d from health file is not running; rejecting heartbeat",
                        sup_pid,
                    )
                    return None

        # If payload_data is provided, verify against authoritative record
        if isinstance(payload_data, dict) and payload_data:
            for key in ("supervisor_pid", "status", "healthy", "cycle_count"):
                if key in payload_data:
                    if key not in auth_status or str(payload_data[key]) != str(
                        auth_status[key]
                    ):
                        logger.warning(
                            "Spoofed heartbeat rejected: field %s=%r contradicts %r",
                            key,
                            payload_data[key],
                            auth_status.get(key),
                        )
                        return None

        return auth_status
    except Exception as exc:
        logger.warning("Failed to hydrate authoritative heartbeat: %s", exc)
        return None


class IPCRateLimiter:
    """Sliding-window / token-bucket rate limiter for IPC connections."""

    def __init__(self, max_rate: float = 200.0, burst: float = 500.0) -> None:
        self.max_rate = max_rate
        self.burst = burst
        self.tokens = burst
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> bool:
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            self.last_update = now
            self.tokens = min(self.burst, self.tokens + elapsed * self.max_rate)
            if self.tokens >= 1.0:
                self.tokens -= 1.0
                return True
            return False


class IPCServer:
    """Asynchronous Unix Domain Socket Server receiving IPC notifications."""

    def __init__(
        self,
        handler: Callable[[dict[str, Any]], Awaitable[None]],
        socket_path: Path | None = None,
        rate_limit_per_second: float = 200.0,
        burst_limit: float = 500.0,
    ) -> None:
        self.handler = handler
        self.socket_path = socket_path or get_ipc_socket_path()
        self._server: asyncio.Server | None = None
        self._rate_limiter = IPCRateLimiter(
            max_rate=rate_limit_per_second, burst=burst_limit
        )

    async def start(self) -> None:
        """Start listening on the Unix domain socket with restricted permissions."""
        parent_dir = self.socket_path.parent
        try:
            parent_dir.mkdir(parents=True, exist_ok=True)
            if str(parent_dir).startswith("/tmp/osiris_"):
                try:
                    os.chmod(str(parent_dir), 0o700)
                except Exception:
                    pass
        except Exception:
            pass

        # Clean up stale socket file if it exists
        if self.socket_path.is_symlink() or self.socket_path.exists():
            try:
                self.socket_path.unlink()
            except Exception as exc:
                logger.warning(
                    "Could not unlink stale IPC socket %s: %s",
                    self.socket_path,
                    exc,
                )

        try:
            old_umask = os.umask(0o117)
            try:
                self._server = await asyncio.start_unix_server(
                    self._handle_client,
                    path=str(self.socket_path),
                    limit=MAX_IPC_MESSAGE_SIZE,
                )
            finally:
                os.umask(old_umask)

            # Enforce 0660: rw-rw---- (backend and collector identities, no others)
            try:
                os.chmod(str(self.socket_path), 0o660)
            except Exception as exc:
                logger.debug("Failed to set 0660 mode on socket: %s", exc)

            logger.info(
                "OSIRIS IPC Unix socket server listening at %s (mode 0660)",
                self.socket_path,
            )
        except Exception as exc:
            logger.warning(
                "Failed to start IPC Unix socket server at %s: %s",
                self.socket_path,
                exc,
            )

    async def stop(self) -> None:
        """Close Unix socket server and unlink socket file."""
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        if self.socket_path.exists():
            try:
                self.socket_path.unlink()
            except Exception:
                pass
        logger.info("OSIRIS IPC Unix socket server stopped.")

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        """Handle incoming line-delimited JSON notification messages securely."""
        sock = writer.get_extra_info("socket")
        if sock is None or not is_peer_authorized(sock):
            logger.warning("Closing connection from unauthorized peer")
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            return

        try:
            while not reader.at_eof():
                try:
                    line = await reader.readline()
                except (ValueError, asyncio.LimitOverrunError) as size_err:
                    logger.warning("IPC message exceeded size limit: %s", size_err)
                    break

                if not line:
                    break
                if len(line) > MAX_IPC_MESSAGE_SIZE:
                    logger.warning(
                        "IPC message size %d exceeds limit %d; dropping",
                        len(line),
                        MAX_IPC_MESSAGE_SIZE,
                    )
                    break

                if not await self._rate_limiter.acquire():
                    logger.warning("IPC rate limit exceeded; throttling notification")
                    continue

                text = line.decode("utf-8").strip()
                if not text:
                    continue

                try:
                    payload = json.loads(text)
                except Exception as json_err:
                    logger.debug("Malformed JSON on IPC connection: %s", json_err)
                    continue

                is_valid, reason = validate_ipc_payload(payload)
                if not is_valid:
                    logger.warning("Invalid IPC message schema: %s", reason)
                    continue

                try:
                    await self.handler(payload)
                except Exception as handler_err:
                    logger.debug("IPC handler error: %s", handler_err)
        except Exception as exc:
            logger.debug("IPC client connection error: %s", exc)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass


def send_ipc_notification(
    payload: dict[str, Any],
    session: Any = None,
) -> bool:
    """Send a compact wake-up notification to the backend process.

    Dispatches via PostgreSQL NOTIFY if running on PostgreSQL,
    and additionally over the local Unix domain socket bridge.
    """
    delivered = False

    # 1. PostgreSQL NOTIFY
    if session is not None:
        try:
            bind = session.get_bind() if hasattr(session, "get_bind") else None
            dialect_name = bind.dialect.name if bind is not None else ""
            if dialect_name.startswith("postgres"):
                from sqlalchemy import text

                session.execute(
                    text("SELECT pg_notify(:channel, :payload)"),
                    {
                        "channel": DEFAULT_PG_CHANNEL,
                        "payload": json.dumps(payload),
                    },
                )
                delivered = True
        except Exception as pg_exc:
            logger.debug("PostgreSQL NOTIFY via session skipped: %s", pg_exc)
    else:
        try:
            from backend.config import settings

            if settings.database_url and settings.database_url.startswith("postgresql"):
                from sqlalchemy import text

                from backend.db.session import engine

                with engine.connect() as conn:
                    conn.execute(
                        text("SELECT pg_notify(:channel, :payload)"),
                        {
                            "channel": DEFAULT_PG_CHANNEL,
                            "payload": json.dumps(payload),
                        },
                    )
                    conn.commit()
                    delivered = True
        except Exception as pg_exc:
            logger.debug("PostgreSQL NOTIFY via engine skipped: %s", pg_exc)

    # 2. Local Unix domain socket IPC bridge
    sock_path = get_ipc_socket_path()
    if sock_path.exists() and not sock_path.is_symlink():
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                s.connect(str(sock_path))
                s.sendall(json.dumps(payload).encode("utf-8") + b"\n")
                delivered = True
        except Exception as sock_exc:
            logger.debug("IPC socket delivery to %s failed: %s", sock_path, sock_exc)

    return delivered


class PostgresNotificationListener:
    """Dedicated background listener thread for PostgreSQL LISTEN/NOTIFY."""

    def __init__(
        self,
        db_url: str,
        handler: Callable[[dict[str, Any]], Awaitable[None]],
        loop: asyncio.AbstractEventLoop,
        channel: str = DEFAULT_PG_CHANNEL,
    ) -> None:
        self.db_url = db_url
        self.handler = handler
        self.loop = loop
        self.channel = channel
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        """Start background polling thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_listener,
            daemon=True,
            name="osiris-pg-listener",
        )
        self._thread.start()
        logger.info(
            "PostgreSQL notification listener thread started on channel '%s'",
            self.channel,
        )

    def stop(self) -> None:
        """Stop background listener."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=2.0)
            self._thread = None
        logger.info("PostgreSQL notification listener thread stopped.")

    def _run_listener(self) -> None:
        """Background thread executing psycopg2 LISTEN loop."""
        import psycopg2
        import psycopg2.extensions

        normalized_url = self.db_url.replace(
            "postgresql+psycopg2://", "postgresql://"
        ).replace("postgresql+asyncpg://", "postgresql://")

        while not self._stop_event.is_set():
            conn = None
            try:
                conn = psycopg2.connect(normalized_url)
                conn.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
                cursor = conn.cursor()
                cursor.execute(f"LISTEN {self.channel};")
                logger.debug("PostgreSQL LISTEN %s established", self.channel)

                while not self._stop_event.is_set():
                    if select.select([conn], [], [], 1.0) == ([], [], []):
                        continue
                    conn.poll()
                    while conn.notifies:
                        notify = conn.notifies.pop(0)
                        try:
                            payload = json.loads(notify.payload)
                            if isinstance(payload, dict) and not self.loop.is_closed():
                                asyncio.run_coroutine_threadsafe(
                                    self.handler(payload), self.loop
                                )
                        except Exception as exc:
                            logger.warning("Error handling pg_notify payload: %s", exc)
            except Exception as exc:
                if not self._stop_event.is_set():
                    logger.debug(
                        "PostgreSQL LISTEN connection error (reconnecting): %s",
                        exc,
                    )
                    time.sleep(2.0)
            finally:
                if conn is not None:
                    try:
                        conn.close()
                    except Exception:
                        pass
