"""Resource telemetry synchronization service for OSIRIS.

Bridges live collector `resource.snapshot` observations to the
`resource_snapshots` table with strict idempotency.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.db.base import new_uuid
from backend.db.models.resource_snapshot import ResourceSnapshot
from backend.services.events.resolver import _ensure_uuid
from backend.services.events.schemas import RawObservation

logger = logging.getLogger("osiris.services.resource_telemetry")


def _ensure_utc(dt: datetime | None) -> datetime:
    """Ensure a datetime is timezone-aware UTC."""
    if dt is None:
        return datetime.now(timezone.utc)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class ResourceTelemetryService:
    """Synchronizes resource.snapshot observations into the ResourceSnapshot table."""

    def apply_observations(
        self,
        session: Session,
        observations: list[RawObservation],
        host_id: uuid.UUID | str,
        now: datetime | None = None,
    ) -> list[ResourceSnapshot]:
        """Apply resource observations to the database with idempotency guarantee.

        Parameters
        ----------
        session:
            Active SQLAlchemy Session.
        observations:
            List of raw observations collected in the current cycle.
        host_id:
            UUID of the monitored host.
        now:
            Current timestamp for created_at.

        Returns
        -------
        list[ResourceSnapshot]
            List of created or updated ResourceSnapshot records.
        """
        host_uuid = _ensure_uuid(host_id)
        current_ts = _ensure_utc(now)

        res_obs = [
            o
            for o in observations
            if o.event_type == "resource.snapshot"
            or (o.source == "resource" and o.action == "snapshot")
        ]
        if not res_obs:
            return []

        results: list[ResourceSnapshot] = []

        for obs in res_obs:
            payload: dict[str, Any] = obs.payload or {}
            ts = _ensure_utc(obs.observed_at)

            # Extract metrics directly from payload without fabricating values
            cpu_percent = payload.get("cpu_percent")
            if cpu_percent is not None:
                try:
                    cpu_percent = float(cpu_percent)
                    if cpu_percent < 0:
                        cpu_percent = 0.0
                except (ValueError, TypeError):
                    cpu_percent = None

            mem_total = payload.get("memory_total")
            if mem_total is not None:
                try:
                    mem_total = int(mem_total)
                except (ValueError, TypeError):
                    mem_total = None

            mem_used = payload.get("memory_used")
            if mem_used is not None:
                try:
                    mem_used = int(mem_used)
                except (ValueError, TypeError):
                    mem_used = None

            mem_percent = payload.get("memory_percent")
            if mem_percent is not None:
                try:
                    mem_percent = float(mem_percent)
                    if mem_percent < 0:
                        mem_percent = 0.0
                except (ValueError, TypeError):
                    mem_percent = None

            disk_read = payload.get("disk_read_bytes")
            if disk_read is not None:
                try:
                    disk_read = int(disk_read)
                except (ValueError, TypeError):
                    disk_read = None

            disk_write = payload.get("disk_write_bytes")
            if disk_write is not None:
                try:
                    disk_write = int(disk_write)
                except (ValueError, TypeError):
                    disk_write = None

            disk_usage_pct = payload.get("disk_usage_percent")
            if disk_usage_pct is not None:
                try:
                    disk_usage_pct = float(disk_usage_pct)
                    if disk_usage_pct < 0:
                        disk_usage_pct = 0.0
                except (ValueError, TypeError):
                    disk_usage_pct = None

            # Check if record already exists for (host_id, timestamp)
            existing = session.execute(
                select(ResourceSnapshot).where(
                    ResourceSnapshot.host_id == host_uuid,
                    ResourceSnapshot.timestamp == ts,
                )
            ).scalar_one_or_none()

            if existing is not None:
                # Update existing if new values are available
                if cpu_percent is not None and existing.cpu_percent is None:
                    existing.cpu_percent = cpu_percent
                if mem_total is not None and existing.memory_total is None:
                    existing.memory_total = mem_total
                if mem_used is not None and existing.memory_used is None:
                    existing.memory_used = mem_used
                if mem_percent is not None and existing.memory_percent is None:
                    existing.memory_percent = mem_percent
                if disk_read is not None and existing.disk_read_bytes is None:
                    existing.disk_read_bytes = disk_read
                if disk_write is not None and existing.disk_write_bytes is None:
                    existing.disk_write_bytes = disk_write
                if disk_usage_pct is not None and existing.disk_usage_percent is None:
                    existing.disk_usage_percent = disk_usage_pct
                results.append(existing)
            else:
                snapshot = ResourceSnapshot(
                    id=new_uuid(),
                    host_id=host_uuid,
                    timestamp=ts,
                    cpu_percent=cpu_percent,
                    memory_total=mem_total,
                    memory_used=mem_used,
                    memory_percent=mem_percent,
                    disk_read_bytes=disk_read,
                    disk_write_bytes=disk_write,
                    disk_usage_percent=disk_usage_pct,
                    created_at=current_ts,
                )
                session.add(snapshot)
                results.append(snapshot)

        session.flush()

        try:
            from backend.api.websocket import ws_manager

            for s in results:
                ws_manager.broadcast_sync(
                    "resource",
                    str(host_uuid),
                    {
                        "id": str(s.id),
                        "timestamp": s.timestamp.isoformat() if s.timestamp else None,
                        "cpu_percent": s.cpu_percent,
                        "memory_percent": s.memory_percent,
                        "memory_used": s.memory_used,
                        "memory_total": s.memory_total,
                        "disk_read_bytes": s.disk_read_bytes,
                        "disk_write_bytes": s.disk_write_bytes,
                        "disk_usage_percent": s.disk_usage_percent,
                    },
                )
        except Exception:
            pass

        return results
