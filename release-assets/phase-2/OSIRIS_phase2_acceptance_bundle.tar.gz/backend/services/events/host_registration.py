"""Host discovery and registration service for OSIRIS.

Provides automatic, idempotent local-host discovery and registration for the
monitored system:
- Resolves the canonical host UUID from configured OSIRIS_HOST_ID using
  `resolve_host_uuid()`.
- Verifies that the corresponding Host record exists prior to persisting
  telemetry, Linux users, processes, resources, files, or events.
- Discovers the system hostname from OSIRIS_HOSTNAME or the operating system.
- Discovers operating system information from `/etc/os-release` or platform.
- Strictly avoids fabricating IP addresses (leaves ip_address as None).
- Preserves existing valid metadata and avoids overwriting administrator-
  maintained fields unnecessarily.
- Concurrency-safe: handles concurrent collector startup without duplicate key
  integrity violations using savepoint rollback recovery.
- Session-architecture compatible: operates within caller-provided or
  orchestrator-owned SQLAlchemy sessions.
"""

from __future__ import annotations

import logging
import os
import platform
import socket
import uuid
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.config import settings
from backend.db.models.host import Host
from backend.services.events.resolver import resolve_host_uuid

logger = logging.getLogger("osiris.services.events.host_registration")


def _ensure_utc(dt: datetime | None) -> datetime:
    """Ensure a datetime is timezone-aware UTC."""
    if dt is None:
        return datetime.now(timezone.utc)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def get_system_hostname(configured: str | None = None) -> str:
    """Resolve the hostname for the local host.

    Order of precedence:
    1. Explicitly passed argument (if non-empty).
    2. Configured OSIRIS_HOSTNAME from application settings or environment.
    3. System hostname from `socket.gethostname()`.
    4. Safe fallback: 'localhost'.

    Returns a normalized, whitespace-stripped string truncated to 255 chars.
    """
    if configured is not None and str(configured).strip():
        return str(configured).strip()[:255]

    # Check settings / environment
    setting_val = getattr(settings, "hostname", None)
    if setting_val is not None and str(setting_val).strip():
        return str(setting_val).strip()[:255]

    env_val = os.environ.get("OSIRIS_HOSTNAME")
    if env_val is not None and env_val.strip():
        return env_val.strip()[:255]

    try:
        sys_h = socket.gethostname()
        if sys_h and sys_h.strip():
            return sys_h.strip()[:255]
    except Exception as exc:
        logger.debug("socket.gethostname() failed: %s", exc)

    return "localhost"


def get_system_os_info(configured: str | None = None) -> str | None:
    """Resolve operating system information for the local host.

    Order of precedence:
    1. Explicitly passed argument (if non-empty).
    2. Distribution identification from `platform.freedesktop_os_release()`
       (e.g., 'PRETTY_NAME' or 'NAME' on Linux / Ubuntu).
    3. Distribution identification parsed from `/etc/os-release` or
       `/usr/lib/os-release`.
    4. Fallback platform identifier: f"{platform.system()} {platform.release()}".

    Returns a normalized string truncated to 512 chars, or None if undetermined.
    """
    if configured is not None and str(configured).strip():
        return str(configured).strip()[:512]

    # 1. Python 3.10+ freedesktop os-release
    if hasattr(platform, "freedesktop_os_release"):
        try:
            os_data = platform.freedesktop_os_release()
            pretty = os_data.get("PRETTY_NAME") or os_data.get("NAME")
            if pretty and pretty.strip():
                return pretty.strip()[:512]
        except Exception:
            pass

    # 2. Direct inspection of /etc/os-release and /usr/lib/os-release
    for path_str in ("/etc/os-release", "/usr/lib/os-release"):
        try:
            p = Path(path_str)
            if p.is_file():
                os_fields: dict[str, str] = {}
                for line in p.read_text(
                    encoding="utf-8", errors="replace"
                ).splitlines():
                    line = line.strip()
                    if "=" in line and not line.startswith("#"):
                        k, v = line.split("=", 1)
                        os_fields[k.strip()] = v.strip().strip('"').strip("'")
                val = os_fields.get("PRETTY_NAME") or os_fields.get("NAME")
                if val and val.strip():
                    return val.strip()[:512]
        except Exception:
            pass

    # 3. Fallback to platform.system() and release
    try:
        sys_name = platform.system()
        sys_rel = platform.release()
        if sys_name and sys_rel:
            return f"{sys_name} {sys_rel}"[:512]
        plat = platform.platform()
        if plat:
            return plat[:512]
    except Exception:
        pass

    return None


class HostRegistrationService:
    """Service responsible for idempotent, concurrency-safe Host registration."""

    def __init__(
        self,
        *,
        hostname: str | None = None,
        os_info: str | None = None,
    ) -> None:
        self._configured_hostname = hostname
        self._configured_os_info = os_info

    def resolve_canonical_uuid(self, host_id: uuid.UUID | str) -> uuid.UUID:
        """Derive the exact canonical UUID for a host identifier."""
        return resolve_host_uuid(host_id)

    def verify_host_exists(
        self,
        session: Session,
        host_id: uuid.UUID | str,
    ) -> bool:
        """Check whether the corresponding Host record exists in the database."""
        canonical_uuid = self.resolve_canonical_uuid(host_id)
        stmt = select(Host.id).where(Host.id == canonical_uuid)
        return session.execute(stmt).scalar_one_or_none() is not None

    def register_or_get_host(
        self,
        session: Session,
        host_id: uuid.UUID | str,
        *,
        hostname: str | None = None,
        os_info: str | None = None,
        now: datetime | None = None,
    ) -> Host:
        """Idempotently register the local host or return the existing Host record.

        Parameters
        ----------
        session:
            Active SQLAlchemy Session within which to query/persist the record.
        host_id:
            Host identifier string or UUID. Canonical UUID is derived using
            `resolve_host_uuid()`.
        hostname:
            Optional hostname override. Defaults to settings or system hostname.
        os_info:
            Optional OS description override. Defaults to local OS release info.
        now:
            Optional timestamp for record creation. Defaults to UTC now.

        Returns
        -------
        Host
            The persisted or retrieved Host ORM instance.

        Raises
        ------
        Exception
            If database persistence encounters an unrecoverable failure.
        """
        canonical_uuid = self.resolve_canonical_uuid(host_id)
        current_ts = _ensure_utc(now)

        # 1. Check if Host already exists
        stmt = select(Host).where(Host.id == canonical_uuid)
        existing = session.execute(stmt).scalar_one_or_none()
        if existing is not None:
            # Preserve existing valid metadata: avoid overwriting admin fields
            updated = False
            if not existing.hostname or not existing.hostname.strip():
                existing.hostname = get_system_hostname(
                    hostname or self._configured_hostname
                )
                updated = True
            if not existing.os_info or not existing.os_info.strip():
                sys_os = get_system_os_info(
                    os_info or self._configured_os_info
                )
                if sys_os:
                    existing.os_info = sys_os
                    updated = True
            if updated:
                session.flush()
            return existing

        # 2. Determine host metadata
        eff_hostname = get_system_hostname(hostname or self._configured_hostname)
        eff_os_info = get_system_os_info(os_info or self._configured_os_info)

        # 3. Create Host entity without fabricating IP addresses (ip_address=None)
        new_host = Host(
            id=canonical_uuid,
            hostname=eff_hostname,
            os_info=eff_os_info,
            ip_address=None,
            created_at=current_ts,
        )

        # 4. Concurrency safety: insert inside a savepoint to catch races cleanly
        try:
            savepoint = session.begin_nested()
            try:
                session.add(new_host)
                session.flush()
                savepoint.commit()
                logger.info(
                    "Registered host record: id=%s hostname='%s' os='%s'",
                    canonical_uuid,
                    eff_hostname,
                    eff_os_info,
                )
                return new_host
            except Exception:
                savepoint.rollback()
                raise
        except IntegrityError as exc:
            # Another concurrent startup or process committed the host row
            logger.info(
                "Host %s already inserted by concurrent process; fetching: %s",
                canonical_uuid,
                exc,
            )
            try:
                session.expunge(new_host)
            except Exception:
                pass
            existing = session.execute(stmt).scalar_one_or_none()
            if existing is not None:
                return existing
            raise
