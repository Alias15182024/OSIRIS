"""Filesystem inventory synchronization service for OSIRIS.

Maintains the authoritative `files` table based on real filesystem observations
produced by FilesystemCollector (inotify).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.db.base import new_uuid
from backend.db.models.file import File
from backend.services.events.resolver import _ensure_uuid
from backend.services.events.schemas import RawObservation

logger = logging.getLogger("osiris.services.file_lifecycle")


def _ensure_utc(dt: datetime | None) -> datetime:
    """Ensure a datetime is timezone-aware UTC."""
    if dt is None:
        return datetime.now(timezone.utc)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _canonical_file_type(raw_type: str | None) -> str:
    """Canonicalize file type string to 'file', 'directory', or 'symlink'."""
    if not raw_type:
        return "file"
    raw_lower = raw_type.lower()
    if raw_lower in ("dir", "directory"):
        return "directory"
    if raw_lower in ("link", "symlink"):
        return "symlink"
    if raw_lower in ("file", "regular", "regular_file"):
        return "file"
    return raw_type


class FileLifecycleService:
    """Synchronizes filesystem observations into the `files` inventory table."""

    def apply_observations(
        self,
        session: Session,
        observations: list[RawObservation],
        host_id: uuid.UUID | str,
        now: datetime | None = None,
    ) -> list[File]:
        """Apply filesystem observations to the database with idempotency guarantee.

        Parameters
        ----------
        session:
            Active SQLAlchemy Session.
        observations:
            List of raw observations collected in the current cycle.
        host_id:
            UUID of the monitored host.
        now:
            Current timestamp.

        Returns
        -------
        list[File]
            List of created or updated File instances.
        """
        host_uuid = _ensure_uuid(host_id)
        current_ts = _ensure_utc(now)

        fs_obs = [
            o
            for o in observations
            if o.source == "fs"
            or (o.event_type and o.event_type.startswith("filesystem."))
        ]
        if not fs_obs:
            return []

        results: list[File] = []

        for obs in fs_obs:
            path = obs.object_path
            if not path:
                continue

            ts = _ensure_utc(obs.observed_at)
            payload: dict[str, Any] = obs.payload or {}
            event_type = obs.event_type or ""
            action = obs.action or ""

            raw_ft = payload.get("file_type") or obs.object_type or "file"
            file_type = _canonical_file_type(raw_ft)
            inode = payload.get("inode")
            if inode is not None:
                try:
                    inode = int(inode)
                except (ValueError, TypeError):
                    inode = None

            # Handle deletion
            if event_type == "filesystem.delete" or action == "delete":
                existing = session.execute(
                    select(File).where(File.host_id == host_uuid, File.path == path)
                ).scalar_one_or_none()
                if existing is not None:
                    session.delete(existing)
                continue

            # Handle move / rename
            if event_type == "filesystem.move" or action == "move":
                from_path = payload.get("from_path") or path
                to_path = payload.get("to_path")
                if to_path:
                    existing = session.execute(
                        select(File).where(
                            File.host_id == host_uuid, File.path == from_path
                        )
                    ).scalar_one_or_none()
                    if existing is not None:
                        existing.path = to_path
                        existing.last_seen_at = ts
                        results.append(existing)
                    else:
                        new_file = File(
                            id=new_uuid(),
                            host_id=host_uuid,
                            path=to_path,
                            inode=inode,
                            file_type=file_type,
                            first_seen_at=ts,
                            last_seen_at=ts,
                            created_at=current_ts,
                        )
                        session.add(new_file)
                        results.append(new_file)
                continue

            # Handle create and modify
            existing = session.execute(
                select(File).where(File.host_id == host_uuid, File.path == path)
            ).scalar_one_or_none()

            if existing is not None:
                existing.last_seen_at = ts
                if inode is not None and existing.inode is None:
                    existing.inode = inode
                if file_type and existing.file_type is None:
                    existing.file_type = file_type
                results.append(existing)
            else:
                new_file = File(
                    id=new_uuid(),
                    host_id=host_uuid,
                    path=path,
                    inode=inode,
                    file_type=file_type,
                    first_seen_at=ts,
                    last_seen_at=ts,
                    created_at=current_ts,
                )
                session.add(new_file)
                results.append(new_file)

        session.flush()
        return results
