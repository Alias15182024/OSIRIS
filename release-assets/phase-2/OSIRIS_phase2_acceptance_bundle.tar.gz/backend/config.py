"""OSIRIS application configuration.

Loads settings from environment variables.
Never commit actual secrets to version control.
"""

from __future__ import annotations

from typing import Any

from pydantic_settings import BaseSettings


class ConfigurationError(ValueError):
    """Raised when application configuration is invalid or insecure."""


KNOWN_INSECURE_SECRETS: frozenset[str] = frozenset(
    {
        "change-me-in-production",
        "change_me_in_production",
        "change-me",
        "change_me",
        "changeme",
        "changethis",
        "dev-only-not-for-production",
        "dev_only_not_for_production",
        "dev-only",
        "dev_only",
        "development-only",
        "secret",
        "secret_key",
        "secretkey",
        "password",
        "password123",
        "admin",
        "default",
        "dev",
        "development",
        "test",
        "testing",
        "osiris",
        "osiris-dev",
        "osiris-secret",
        "123456",
        "12345678",
        "root",
        "guest",
    }
)


DEFAULT_DEV_CORS_ORIGINS: list[str] = [
    "http://localhost",
    "http://localhost:8000",
    "http://127.0.0.1",
    "http://127.0.0.1:8000",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

PROTECTED_DATABASE_NAMES: frozenset[str] = frozenset(
    {
        "osiris",
        "osiris_phase2_review",
        "osiris_phase2_demo",
        "osiris_dev",
        "osiris_desktop_dev",
        "osiris_l1_validation_d4daacd",
        "postgres",
        "template1",
    }
)


def sanitize_url(url: str | None) -> str:
    """Mask password in database URL for safe logging and error reporting."""
    if not url:
        return ""
    try:
        from sqlalchemy.engine import make_url

        return make_url(url).render_as_string(hide_password=True)
    except Exception:
        import re

        return re.sub(r"(://[^:]+:)([^@]+)(@)", r"\1***\3", url)


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    database_url: str | None = None
    test_database_url: str | None = None
    secret_key: str | None = "CHANGE-ME-IN-PRODUCTION"
    debug: bool = False
    host_id: str = "osiris-dev-host"
    hostname: str | None = None
    cors_allowed_origins: list[str] | str = list(DEFAULT_DEV_CORS_ORIGINS)

    model_config = {"env_prefix": "OSIRIS_", "env_file": ".env"}

    def __init__(
        self,
        *args: Any,
        validate_on_init: bool = False,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        if validate_on_init:
            self.validate_secret_key()
            self.validate_cors_configuration()

    def get_cors_origins(self) -> list[str]:
        """Return parsed list of explicit allowed CORS origins."""
        raw = self.cors_allowed_origins
        if isinstance(raw, str):
            origins = [o.strip() for o in raw.split(",") if o.strip()]
        elif isinstance(raw, (list, tuple, set)):
            origins = [str(o).strip() for o in raw if str(o).strip()]
        else:
            origins = list(DEFAULT_DEV_CORS_ORIGINS)
        return origins

    def validate_cors_configuration(self) -> None:
        """Validate CORS configuration safety for current execution mode.

        In production mode (debug=False), rejects wildcard origins ('*')
        to prevent credentialed cross-origin hijacking.
        """
        origins = self.get_cors_origins()
        if not self.debug:
            if "*" in origins:
                raise ConfigurationError(
                    "Wildcard CORS origin '*' is not permitted in production mode "
                    "(debug=False) with credentialed requests. Configure explicit "
                    "allowed origins via OSIRIS_CORS_ALLOWED_ORIGINS."
                )

    def validate_secret_key(self) -> None:
        """Validate that secret_key is safe for the current execution mode.

        In production mode (debug=False), rejects missing, empty, or known
        insecure placeholder secrets. In development mode (debug=True),
        permits development placeholders to preserve local workflow.

        Raises
        ------
        ConfigurationError
            If secret_key is missing, empty, or a known insecure placeholder in
            production mode, or if empty in development mode.
        """
        raw_key = self.secret_key
        if not isinstance(raw_key, str) or not raw_key.strip():
            raise ConfigurationError(
                "OSIRIS secret_key is not configured. A non-empty signing secret "
                "must be provided via OSIRIS_SECRET_KEY."
            )

        if not self.debug:
            normalized = raw_key.strip().lower()
            if normalized in KNOWN_INSECURE_SECRETS:
                raise ConfigurationError(
                    "Insecure or placeholder secret_key is not permitted in "
                    "production mode (debug=False). Please configure a secure "
                    "OSIRIS_SECRET_KEY."
                )

    def validate_database_url(self, require_explicit: bool = False) -> None:
        """Validate database_url configuration safety for current execution mode.

        In production mode (debug=False) or when require_explicit=True:
        - Rejects unconfigured or empty database URLs.
        - Rejects missing database names.
        - Rejects default credentials ('osiris:osiris') or known insecure passwords.
        - Rejects protected database names: osiris, osiris_phase2_review,
          osiris_phase2_demo, and existing validation database names.
        - Never silently falls back to the default application database in deployment.
        - Keeps secrets out of error messages.

        Raises
        ------
        ConfigurationError
            If database_url is invalid, unconfigured, or targets a protected database.
        """
        raw_url = self.database_url
        if not isinstance(raw_url, str) or not raw_url.strip():
            if not self.debug or require_explicit:
                raise ConfigurationError(
                    "OSIRIS database_url is not configured. An explicit database "
                    "connection URL must be provided via OSIRIS_DATABASE_URL."
                )
            return

        raw_url = raw_url.strip()

        # Parse URL
        try:
            from sqlalchemy.engine import make_url

            parsed = make_url(raw_url)
            driver = parsed.drivername.lower()
            db_name = (parsed.database or "").strip().lower()
            username = parsed.username or ""
            password = parsed.password or ""
        except Exception:
            from urllib.parse import urlparse

            u = urlparse(raw_url)
            driver = u.scheme.lower()
            db_name = u.path.lstrip("/").strip().lower()
            username = u.username or ""
            password = u.password or ""

        # Validate deployment constraints in production or when explicit
        if not self.debug or require_explicit:
            if not db_name:
                safe_display = sanitize_url(raw_url)
                raise ConfigurationError(
                    "OSIRIS_DATABASE_URL must specify a target database name "
                    f"(got '{safe_display}')."
                )

            if (
                db_name in PROTECTED_DATABASE_NAMES
                or "validation" in db_name
                or "phase2_review" in db_name
                or "phase2_demo" in db_name
            ):
                safe_display = sanitize_url(raw_url)
                raise ConfigurationError(
                    f"Target database '{db_name}' is a protected database name and "
                    f"cannot be used in deployment (connection: {safe_display})."
                )

            if not driver.startswith("postgresql"):
                raise ConfigurationError(
                    "Production database URL must use a PostgreSQL scheme "
                    f"(got '{driver}')."
                )
            if not username or not password:
                raise ConfigurationError(
                    "Explicit database credentials (non-empty username and password) "
                    "must be provided in OSIRIS_DATABASE_URL."
                )

            norm_user = username.strip().lower()
            norm_pass = password.strip().lower()
            if norm_user == "osiris" and norm_pass == "osiris":
                raise ConfigurationError(
                    "Default database credentials ('osiris:osiris') are not permitted "
                    "in deployment. Please configure dedicated, secure credentials."
                )

            if norm_pass in KNOWN_INSECURE_SECRETS:
                raise ConfigurationError(
                    "Insecure or placeholder database password is not "
                    "permitted in deployment."
                )

            trivial_users = ("admin", "root", "test", "osiris", "guest")
            if norm_user == norm_pass and norm_user in trivial_users:
                raise ConfigurationError(
                    "Default or trivial database credentials are not "
                    "permitted in deployment."
                )


def validate_secret_key(settings_obj: Settings | None = None) -> None:
    """Validate secret_key on the given or global settings instance."""
    cfg = settings_obj if settings_obj is not None else settings
    cfg.validate_secret_key()


def validate_cors_configuration(settings_obj: Settings | None = None) -> None:
    """Validate CORS configuration on the given or global settings instance."""
    cfg = settings_obj if settings_obj is not None else settings
    cfg.validate_cors_configuration()


def validate_database_url(
    settings_obj: Settings | None = None, require_explicit: bool = False
) -> None:
    """Validate database_url on the given or global settings instance."""
    cfg = settings_obj if settings_obj is not None else settings
    cfg.validate_database_url(require_explicit=require_explicit)


settings = Settings()
