"""SQLAlchemy engine and session management for OSIRIS."""

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from backend.config import settings

_db_url = settings.database_url or "sqlite:///:memory:"
engine = create_engine(
    _db_url,
    pool_pre_ping=True if settings.database_url else False,
    echo=settings.debug,
)

SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def get_session() -> Session:
    """Create a new database session.

    Usage:
        session = get_session()
        try:
            ...
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    """
    return SessionLocal()
