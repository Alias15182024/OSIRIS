"""Unit tests for FileLifecycleService (Filesystem Inventory Synchronization)."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from backend.db.base import Base
from backend.db.models.file import File
from backend.db.models.host import Host
from backend.services.events.file_lifecycle import FileLifecycleService
from backend.services.events.schemas import RawObservation


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@pytest.fixture
def db_session() -> Session:
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def sample_host(db_session: Session) -> Host:
    host = Host(
        id=uuid.uuid4(),
        hostname="test-host",
        created_at=utcnow(),
    )
    db_session.add(host)
    db_session.commit()
    return host


class TestFileLifecycleService:
    """Test suite for FileLifecycleService."""

    def test_file_create_creates_inventory_row(
        self, db_session: Session, sample_host: Host
    ) -> None:
        service = FileLifecycleService()
        obs = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/etc/test.conf",
            payload={"inode": 12345, "file_type": "regular"},
        )
        res = service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        assert len(res) == 1
        assert res[0].path == "/etc/test.conf"
        assert res[0].inode == 12345
        assert res[0].file_type == "file"

        # Verify in DB
        rows = (
            db_session.execute(select(File).where(File.host_id == sample_host.id))
            .scalars()
            .all()
        )
        assert len(rows) == 1
        assert rows[0].path == "/etc/test.conf"

    def test_file_duplicate_create_is_idempotent(
        self, db_session: Session, sample_host: Host
    ) -> None:
        service = FileLifecycleService()
        obs = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/etc/app.conf",
            payload={"inode": 5555},
        )
        service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        # Repeat same observation
        service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        rows = (
            db_session.execute(select(File).where(File.host_id == sample_host.id))
            .scalars()
            .all()
        )
        assert len(rows) == 1
        assert rows[0].path == "/etc/app.conf"

    def test_file_modify_updates_last_seen(
        self, db_session: Session, sample_host: Host
    ) -> None:
        service = FileLifecycleService()
        t1 = datetime(2026, 11, 1, 10, 0, tzinfo=timezone.utc)
        t2 = datetime(2026, 11, 1, 10, 5, tzinfo=timezone.utc)

        obs1 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=t1,
            object_type="file",
            object_path="/var/log/audit.log",
        )
        service.apply_observations(db_session, [obs1], sample_host.id)
        db_session.commit()

        obs2 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.modify",
            action="modify",
            severity="info",
            observed_at=t2,
            object_type="file",
            object_path="/var/log/audit.log",
        )
        service.apply_observations(db_session, [obs2], sample_host.id)
        db_session.commit()

        f = db_session.execute(
            select(File).where(File.host_id == sample_host.id)
        ).scalar_one()
        assert f.path == "/var/log/audit.log"
        f_first = (
            f.first_seen_at
            if f.first_seen_at.tzinfo
            else f.first_seen_at.replace(tzinfo=timezone.utc)
        )
        f_last = (
            f.last_seen_at
            if f.last_seen_at.tzinfo
            else f.last_seen_at.replace(tzinfo=timezone.utc)
        )
        assert f_first == t1
        assert f_last == t2

    def test_file_move_updates_path(
        self, db_session: Session, sample_host: Host
    ) -> None:
        service = FileLifecycleService()
        obs1 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/tmp/draft.txt",
        )
        service.apply_observations(db_session, [obs1], sample_host.id)
        db_session.commit()

        obs2 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.move",
            action="move",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/tmp/final.txt",
            payload={"from_path": "/tmp/draft.txt", "to_path": "/tmp/final.txt"},
        )
        service.apply_observations(db_session, [obs2], sample_host.id)
        db_session.commit()

        files = (
            db_session.execute(select(File).where(File.host_id == sample_host.id))
            .scalars()
            .all()
        )
        assert len(files) == 1
        assert files[0].path == "/tmp/final.txt"

    def test_file_delete_removes_from_inventory(
        self, db_session: Session, sample_host: Host
    ) -> None:
        service = FileLifecycleService()
        obs1 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/tmp/trash.txt",
        )
        service.apply_observations(db_session, [obs1], sample_host.id)
        db_session.commit()

        obs2 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.delete",
            action="delete",
            severity="info",
            observed_at=utcnow(),
            object_type="file",
            object_path="/tmp/trash.txt",
        )
        service.apply_observations(db_session, [obs2], sample_host.id)
        db_session.commit()

        files = (
            db_session.execute(select(File).where(File.host_id == sample_host.id))
            .scalars()
            .all()
        )
        assert len(files) == 0

    def test_host_scoping_isolation(
        self, db_session: Session, sample_host: Host
    ) -> None:
        other_host = Host(id=uuid.uuid4(), hostname="other-host", created_at=utcnow())
        db_session.add(other_host)
        db_session.commit()

        service = FileLifecycleService()
        obs1 = RawObservation(
            source="fs",
            host_id=str(sample_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_path="/etc/shared.conf",
        )
        obs2 = RawObservation(
            source="fs",
            host_id=str(other_host.id),
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=utcnow(),
            object_path="/etc/shared.conf",
        )
        service.apply_observations(db_session, [obs1], sample_host.id)
        service.apply_observations(db_session, [obs2], other_host.id)
        db_session.commit()

        h1_files = (
            db_session.execute(select(File).where(File.host_id == sample_host.id))
            .scalars()
            .all()
        )
        h2_files = (
            db_session.execute(select(File).where(File.host_id == other_host.id))
            .scalars()
            .all()
        )

        assert len(h1_files) == 1
        assert len(h2_files) == 1
        assert h1_files[0].id != h2_files[0].id
