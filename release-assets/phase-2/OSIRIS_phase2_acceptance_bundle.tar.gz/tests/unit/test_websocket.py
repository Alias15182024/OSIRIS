"""Unit tests for WebSocket ticket authentication, authorization, and message queue."""

from __future__ import annotations

import time
import uuid

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool
from starlette.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from backend.api.deps import get_db
from backend.api.security import create_access_token
from backend.api.websocket import (
    ConnectionMessageQueue,
    is_host_authorized,
    issue_ws_ticket,
    validate_and_consume_ws_ticket,
)
from backend.db.base import Base
from backend.db.models.app_user import AppUser
from backend.main import app


@pytest.fixture
def db_session() -> Session:
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def client(db_session: Session, monkeypatch: pytest.MonkeyPatch) -> TestClient:
    app.dependency_overrides[get_db] = lambda: db_session
    from backend.api.websocket import ws_manager

    factory = sessionmaker(bind=db_session.get_bind(), expire_on_commit=False)
    monkeypatch.setattr(ws_manager, "_session_factory", factory)
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def auth_headers(db_session: Session) -> dict[str, str]:
    user = AppUser(
        id=uuid.uuid4(),
        username="ws_user",
        password_hash="pbkdf2_sha256$...",
        role="analyst",
        is_active=True,
        created_at=datetime_now(),
    )
    db_session.add(user)
    db_session.commit()
    token = create_access_token(user_id=user.id, username=user.username, role=user.role)
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def admin_headers(db_session: Session) -> dict[str, str]:
    admin = AppUser(
        id=uuid.uuid4(),
        username="ws_admin",
        password_hash="pbkdf2_sha256$...",
        role="admin",
        is_active=True,
        created_at=datetime_now(),
    )
    db_session.add(admin)
    db_session.commit()
    token = create_access_token(
        user_id=admin.id, username=admin.username, role=admin.role
    )
    return {"Authorization": f"Bearer {token}"}


def datetime_now():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc)


class TestWebSocketAuth:
    """Test suite for WebSocket ticket issuance and handshake authentication."""

    def test_issue_and_consume_ticket(self) -> None:
        user_id = uuid.uuid4()
        ticket = issue_ws_ticket(user_id, "analyst1", "analyst")
        assert ticket is not None
        assert len(ticket) > 10

        # First consumption succeeds
        info = validate_and_consume_ws_ticket(ticket)
        assert info is not None
        assert info["username"] == "analyst1"
        assert info["user_id"] == str(user_id)

        # Second consumption fails (single-use!)
        info_again = validate_and_consume_ws_ticket(ticket)
        assert info_again is None

    def test_expired_ticket_fails(self) -> None:
        user_id = uuid.uuid4()
        ticket = issue_ws_ticket(user_id, "analyst2", "analyst")
        # Force expiration
        from backend.api.websocket import _ws_tickets

        _ws_tickets[ticket]["expires_at"] = time.time() - 10

        info = validate_and_consume_ws_ticket(ticket)
        assert info is None

    def test_post_ws_ticket_endpoint(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "ticket" in data
        assert data["expires_in"] == 30

        # Verify the ticket works
        consumed = validate_and_consume_ws_ticket(data["ticket"])
        assert consumed is not None
        assert consumed["username"] == "ws_user"

    def test_websocket_connect_rejects_without_handshake(
        self, client: TestClient
    ) -> None:
        """Connecting and sending non-authenticate action must be rejected."""
        with pytest.raises(WebSocketDisconnect) as exc_info:
            with client.websocket_connect("/ws") as ws:
                ws.send_json({"action": "ping"})
                ws.receive_json()
        assert exc_info.value.code == 1008

    def test_websocket_connect_with_invalid_ticket_fails(
        self, client: TestClient
    ) -> None:
        """Connecting and presenting invalid ticket fails handshake."""
        with pytest.raises(WebSocketDisconnect) as exc_info:
            with client.websocket_connect("/ws") as ws:
                ws.send_json(
                    {
                        "action": "authenticate",
                        "ticket": "invalid_bogus_ticket",
                    }
                )
                ws.receive_json()
        assert exc_info.value.code == 1008

    def test_websocket_connect_with_valid_handshake(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        """Handshake authentication succeeds, permits ping/pong."""
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]

        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": ticket})
            auth_ack = ws.receive_json()
            assert auth_ack["type"] == "authenticated"
            assert auth_ack["username"] == "ws_user"

            ws.send_json({"action": "ping"})
            reply = ws.receive_json()
            assert reply["type"] == "pong"

    def test_websocket_ticket_cannot_be_reused(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        """Single-use ticket cannot be used for a second connection."""
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]

        # First connection consumes ticket
        with client.websocket_connect("/ws") as ws1:
            ws1.send_json({"action": "authenticate", "ticket": ticket})
            ack = ws1.receive_json()
            assert ack["type"] == "authenticated"

        # Second connection with same ticket must fail
        with pytest.raises(WebSocketDisconnect) as exc_info:
            with client.websocket_connect("/ws") as ws2:
                ws2.send_json({"action": "authenticate", "ticket": ticket})
                ws2.receive_json()
        assert exc_info.value.code == 1008


class TestWebSocketSubscriptions:
    """Test suite for host authorization and event subscriptions."""

    def test_host_authorization_matrix(self) -> None:
        valid_uuid = str(uuid.uuid4())

        # Wildcard requires admin
        assert not is_host_authorized({"role": "analyst"}, "*")
        assert not is_host_authorized({"role": "viewer"}, "*")
        assert is_host_authorized({"role": "admin"}, "*")

        # Specific UUID authorized for analysts and admins
        assert is_host_authorized({"role": "analyst"}, valid_uuid)
        assert is_host_authorized({"role": "admin"}, valid_uuid)

        # Allowed hosts whitelist enforcement
        user_with_whitelist = {
            "role": "analyst",
            "allowed_hosts": ["host-prod-1", "host-prod-2"],
        }
        assert is_host_authorized(user_with_whitelist, "host-prod-1")
        assert not is_host_authorized(user_with_whitelist, "host-prod-3")

    def test_wildcard_subscription_rbac(
        self,
        client: TestClient,
        auth_headers: dict[str, str],
        admin_headers: dict[str, str],
    ) -> None:
        # 1. Analyst attempting wildcard subscription receives error
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        analyst_ticket = resp.json()["ticket"]
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": analyst_ticket})
            ws.receive_json()  # authenticated

            ws.send_json({"action": "subscribe", "host_id": "*"})
            err = ws.receive_json()
            assert err["type"] == "error"
            assert err["error"] == "unauthorized_host"

        # 2. Admin attempting wildcard subscription succeeds
        resp_admin = client.post("/api/auth/ws-ticket", headers=admin_headers)
        admin_ticket = resp_admin.json()["ticket"]
        with client.websocket_connect("/ws") as ws_admin:
            ws_admin.send_json({"action": "authenticate", "ticket": admin_ticket})
            ws_admin.receive_json()  # authenticated

            ws_admin.send_json({"action": "subscribe", "host_id": "*"})
            sub_ack = ws_admin.receive_json()
            assert sub_ack["type"] == "subscribed"
            assert sub_ack["host_id"] == "*"

    def test_replay_unauthorized_host_rejected(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": ticket})
            ws.receive_json()

            # Attempt replay on wildcard as non-admin
            ws.send_json({"action": "replay", "host_id": "*"})
            err = ws.receive_json()
            assert err["type"] == "error"
            assert err["error"] == "unauthorized_host"

    def test_invalid_host_format_rejected(self) -> None:
        """Non-UUID arbitrary string host is rejected."""
        assert not is_host_authorized({"role": "analyst"}, "invalid-fake-host")
        assert not is_host_authorized({"role": "viewer"}, "garbage_host_name")

    @pytest.mark.anyio
    async def test_unsubscribed_client_does_not_receive_events(self) -> None:
        """Client must NOT receive host events before explicitly subscribing."""
        from backend.api.websocket import WebSocketManager

        mgr = WebSocketManager()

        class DummyWS:
            async def send_json(self, msg: dict) -> None:
                pass

        ws = DummyWS()
        await mgr.connect(ws, {"username": "viewer", "role": "viewer"})

        # Broadcast for specific host without subscription
        target_uuid = str(uuid.uuid4())
        await mgr.broadcast_message("event", target_uuid, {"id": "ev-1"})

        queue = mgr._connections[ws]["queue"]
        assert queue.qsize() == 0

        # Now subscribe to target host
        sub_ok = mgr.subscribe(ws, target_uuid)
        assert sub_ok is True

        await mgr.broadcast_message("event", target_uuid, {"id": "ev-2"})
        assert queue.qsize() == 1
        msg = await queue.get()
        assert msg["data"]["id"] == "ev-2"

        # Broadcast for a DIFFERENT host: client must NOT receive it
        other_uuid = str(uuid.uuid4())
        await mgr.broadcast_message("event", other_uuid, {"id": "ev-3"})
        assert queue.qsize() == 0

    def test_subscribe_missing_host_returns_error(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": ticket})
            ws.receive_json()

            ws.send_json({"action": "subscribe", "host_id": ""})
            err = ws.receive_json()
            assert err["type"] == "error"
            assert err["error"] == "invalid_request"

    def test_unknown_action_returns_error(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": ticket})
            ws.receive_json()

            ws.send_json({"action": "unknown_custom_action"})
            err = ws.receive_json()
            assert err["type"] == "error"
            assert err["error"] == "unknown_action"

    def test_replay_with_last_event_id_cursor(
        self,
        client: TestClient,
        auth_headers: dict[str, str],
        db_session: Session,
    ) -> None:
        """Replay using last_event_id returns only events occurring after cursor."""
        from datetime import datetime, timezone

        from backend.db.models.event import Event
        from backend.db.models.host import Host

        h_id = uuid.uuid4()
        db_session.add(
            Host(
                id=h_id,
                hostname="replay-host",
                created_at=datetime.now(timezone.utc),
            )
        )

        ev1 = Event(
            id=uuid.uuid4(),
            host_id=h_id,
            timestamp=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            ingested_at=datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc),
            source="proc",
            event_type="proc:start",
            action="execute",
            severity="info",
        )
        ev2 = Event(
            id=uuid.uuid4(),
            host_id=h_id,
            timestamp=datetime(2026, 1, 1, 12, 1, 0, tzinfo=timezone.utc),
            ingested_at=datetime(2026, 1, 1, 12, 1, 0, tzinfo=timezone.utc),
            source="proc",
            event_type="proc:start",
            action="execute",
            severity="info",
        )
        ev3 = Event(
            id=uuid.uuid4(),
            host_id=h_id,
            timestamp=datetime(2026, 1, 1, 12, 2, 0, tzinfo=timezone.utc),
            ingested_at=datetime(2026, 1, 1, 12, 2, 0, tzinfo=timezone.utc),
            source="proc",
            event_type="proc:start",
            action="execute",
            severity="info",
        )
        db_session.add_all([ev1, ev2, ev3])
        db_session.commit()

        resp = client.post("/api/auth/ws-ticket", headers=auth_headers)
        ticket = resp.json()["ticket"]
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"action": "authenticate", "ticket": ticket})
            ws.receive_json()

            # Request replay after ev2
            ws.send_json(
                {
                    "action": "replay",
                    "host_id": str(h_id),
                    "last_event_id": str(ev2.id),
                }
            )
            start_msg = ws.receive_json()
            assert start_msg["type"] == "replay_start"
            assert start_msg["count"] == 1

            replayed_ev = ws.receive_json()
            assert replayed_ev["type"] == "event"
            assert replayed_ev["data"]["id"] == str(ev3.id)

            end_msg = ws.receive_json()
            assert end_msg["type"] == "replay_end"


class TestConnectionMessageQueue:
    """Test suite for priority-aware bounded message queue."""

    @pytest.mark.anyio
    async def test_queue_coalesces_resources(self) -> None:
        queue = ConnectionMessageQueue(maxsize=3)

        # Enqueue 3 non-critical resources
        res1 = {"type": "resource", "data": {"cpu": 10}}
        res2 = {"type": "resource", "data": {"cpu": 20}}
        res3 = {"type": "resource", "data": {"cpu": 30}}
        await queue.put(res1)
        await queue.put(res2)
        await queue.put(res3)

        # 4th resource exceeds maxsize; should coalesce with latest resource
        res4 = {"type": "resource", "data": {"cpu": 99}}
        success = await queue.put(res4)
        assert success is True
        assert queue.coalesced_count == 1
        assert len(queue._queue) == 3

        # Verify res4 replaced the previous resource
        items = list(queue._queue)
        assert items[-1]["data"]["cpu"] == 99

    @pytest.mark.anyio
    async def test_critical_detections_never_dropped(self) -> None:
        queue = ConnectionMessageQueue(maxsize=3)

        # Fill with non-critical resources
        for i in range(3):
            await queue.put({"type": "resource", "data": {"seq": i}})

        # Now send critical detection
        crit = {
            "type": "detection",
            "data": {"id": "det-1", "severity": "critical", "title": "Root Escalation"},
        }
        success = await queue.put(crit)
        assert success is True
        # A non-critical item was evicted
        assert queue.dropped_count == 1
        assert len(queue._queue) == 3
        assert any(item["type"] == "detection" for item in queue._queue)

    @pytest.mark.anyio
    async def test_critical_event_expansion_under_saturation(self) -> None:
        queue = ConnectionMessageQueue(maxsize=2, critical_limit=5)

        # Enqueue 2 critical detections
        await queue.put({"type": "detection", "data": {"id": 1}})
        await queue.put({"type": "detection", "data": {"id": 2}})
        assert len(queue._queue) == 2

        # 3rd critical detection expands queue beyond maxsize up to critical_limit
        await queue.put({"type": "detection", "data": {"id": 3}})
        assert len(queue._queue) == 3

        # High severity event is also treated as critical
        await queue.put({"type": "event", "data": {"id": 4, "severity": "high"}})
        assert len(queue._queue) == 4

        # Non-critical item arrives when queue is filled with criticals -> dropped
        rejected = await queue.put({"type": "resource", "data": {"id": 5}})
        assert rejected is False
        assert queue.dropped_count == 1

    @pytest.mark.anyio
    async def test_websocket_manager_get_stats(self) -> None:
        from backend.api.websocket import WebSocketManager

        mgr = WebSocketManager()

        class DummyWS:
            async def send_json(self, msg: dict) -> None:
                pass

        ws = DummyWS()
        await mgr.connect(ws, {"username": "admin", "role": "admin"})
        stats = mgr.get_stats()
        assert stats["active_connections"] == 1
        assert stats["current_queued_messages"] == 0
        assert stats["total_dropped_messages"] == 0
        assert stats["total_coalesced_messages"] == 0
        assert stats["total_overflow_events"] == 0
