"""Unit tests for OSIRIS Host API routes (/api/hosts)."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool
from starlette.testclient import TestClient

from backend.api.deps import get_db
from backend.api.security import create_access_token
from backend.db.base import Base
from backend.db.models.app_user import AppUser
from backend.db.models.event import Event
from backend.db.models.host import Host
from backend.main import app


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@pytest.fixture
def host_db_session() -> Session:
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def client(host_db_session: Session) -> TestClient:
    app.dependency_overrides[get_db] = lambda: host_db_session
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def auth_user(host_db_session: Session) -> AppUser:
    user = AppUser(
        id=uuid.uuid4(),
        username="host_analyst",
        password_hash="pbkdf2_sha256$...",
        role="analyst",
        is_active=True,
        created_at=utcnow(),
    )
    host_db_session.add(user)
    host_db_session.commit()
    return user


@pytest.fixture
def auth_headers(auth_user: AppUser) -> dict[str, str]:
    token = create_access_token(
        user_id=auth_user.id,
        username=auth_user.username,
        role=auth_user.role,
    )
    return {"Authorization": f"Bearer {token}"}


class TestHostApi:
    """Test suite for /api/hosts endpoint."""

    def test_list_hosts_unauthenticated(self, client: TestClient) -> None:
        resp = client.get("/api/hosts")
        assert resp.status_code == 401

    def test_list_hosts_empty(
        self, client: TestClient, auth_headers: dict[str, str]
    ) -> None:
        resp = client.get("/api/hosts", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["items"] == []

    def test_list_hosts_success(
        self, client: TestClient, host_db_session: Session, auth_headers: dict[str, str]
    ) -> None:
        h1 = Host(
            id=uuid.uuid4(),
            hostname="ubuntu-osiris-live",
            ip_address="192.168.1.100",
            os_info="Ubuntu 22.04 LTS",
            created_at=utcnow(),
        )
        h2 = Host(
            id=uuid.uuid4(),
            hostname="srv-prod-web01",
            ip_address="10.0.4.15",
            os_info="Ubuntu 20.04 LTS",
            created_at=utcnow(),
        )
        host_db_session.add_all([h1, h2])
        host_db_session.commit()

        # Add recent event for h1
        ev = Event(
            id=uuid.uuid4(),
            host_id=h1.id,
            timestamp=utcnow(),
            source="resource",
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            payload={"cpu_percent": 15.0},
            created_at=utcnow(),
        )
        host_db_session.add(ev)
        host_db_session.commit()

        resp = client.get("/api/hosts", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        host_names = [item["hostname"] for item in data["items"]]
        assert "ubuntu-osiris-live" in host_names
        assert "srv-prod-web01" in host_names

        # Check status
        h1_data = next(
            item for item in data["items"] if item["hostname"] == "ubuntu-osiris-live"
        )
        assert h1_data["status"] == "online"
        assert h1_data["last_seen_at"] is not None

        h2_data = next(
            item for item in data["items"] if item["hostname"] == "srv-prod-web01"
        )
        assert h2_data["status"] == "offline"

    def test_search_hosts(
        self, client: TestClient, host_db_session: Session, auth_headers: dict[str, str]
    ) -> None:
        h1 = Host(
            id=uuid.uuid4(),
            hostname="ubuntu-osiris-live",
            ip_address="192.168.1.100",
            created_at=utcnow(),
        )
        h2 = Host(
            id=uuid.uuid4(),
            hostname="srv-prod-web01",
            ip_address="10.0.4.15",
            created_at=utcnow(),
        )
        host_db_session.add_all([h1, h2])
        host_db_session.commit()

        resp = client.get("/api/hosts?search=DarkLoom", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["total"] == 0

        resp = client.get("/api/hosts?search=srv-prod", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["items"][0]["hostname"] == "srv-prod-web01"

    def test_get_host_by_id(
        self, client: TestClient, host_db_session: Session, auth_headers: dict[str, str]
    ) -> None:
        host_id = uuid.uuid4()
        h = Host(
            id=host_id,
            hostname="target-host",
            ip_address="10.10.10.10",
            created_at=utcnow(),
        )
        host_db_session.add(h)
        host_db_session.commit()

        resp = client.get(f"/api/hosts/{host_id}", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["hostname"] == "target-host"

        non_existent = uuid.uuid4()
        resp_404 = client.get(f"/api/hosts/{non_existent}", headers=auth_headers)
        assert resp_404.status_code == 404
