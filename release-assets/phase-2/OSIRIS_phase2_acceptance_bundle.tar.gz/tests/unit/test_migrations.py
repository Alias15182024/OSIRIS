from __future__ import annotations

"""Isolated migration tests for Alembic schema and data migrations.

Tests verify migration 0002_normalize_file_types:
  - Upgrades from 0001_phase1_schema to 0002_normalize_file_types.
  - Normalizes legacy 'regular' and 'regular_file' values to 'file'.
  - Preserves 'directory', 'symlink', and any other custom/NULL/empty values.
  - Verifies downgrade behavior (safe no-op that avoids data corruption).
  - Verifies migration works cleanly on empty tables.
  - Verifies new records created as 'file' after migration are preserved upon downgrade.
  - Runs strictly against isolated/disposable databases (never against osiris_dev).
"""

import os
import subprocess
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Generator

import pytest
import sqlalchemy as sa
from alembic import command
from alembic.config import Config
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.compiler import compiles

from backend.config import settings

# Register SQLite compiler for JSONB so 0001_phase1_schema runs on SQLite
@compiles(JSONB, "sqlite")
def _compile_jsonb_sqlite(type_, compiler, **kw):  # type: ignore[no-untyped-def]
    return "JSON"


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


_hosts_table = sa.table(
    "hosts",
    sa.column("id", sa.Uuid),
    sa.column("hostname", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_events_table = sa.table(
    "events",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("process_id", sa.Uuid),
    sa.column("timestamp", sa.DateTime(timezone=True)),
    sa.column("ingested_at", sa.DateTime(timezone=True)),
    sa.column("source", sa.String),
    sa.column("event_type", sa.String),
    sa.column("action", sa.String),
    sa.column("severity", sa.String),
    sa.column("uid", sa.Integer),
    sa.column("username", sa.String),
    sa.column("pid", sa.Integer),
    sa.column("ppid", sa.Integer),
    sa.column("command", sa.String),
    sa.column("object_type", sa.String),
    sa.column("object_path", sa.String),
    sa.column("success", sa.Boolean),
    sa.column("result", sa.String),
    sa.column("payload", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_files_table = sa.table(
    "files",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("path", sa.String),
    sa.column("file_type", sa.String),
    sa.column("first_seen_at", sa.DateTime(timezone=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_linux_users_table = sa.table(
    "linux_users",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("uid", sa.Integer),
    sa.column("username", sa.String),
    sa.column("first_seen_at", sa.DateTime(timezone=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_snapshots_table = sa.table(
    "snapshots",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("timestamp", sa.DateTime(timezone=True)),
    sa.column("snapshot_type", sa.String),
    sa.column("data", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_sessions_table = sa.table(
    "sessions",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("linux_user_id", sa.Uuid),
    sa.column("session_type", sa.String),
    sa.column("terminal", sa.String),
    sa.column("remote_host", sa.String),
    sa.column("started_at", sa.DateTime(timezone=True)),
    sa.column("ended_at", sa.DateTime(timezone=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_detection_rules_table = sa.table(
    "detection_rules",
    sa.column("id", sa.Uuid),
    sa.column("rule_id", sa.String),
    sa.column("name", sa.String),
    sa.column("description", sa.String),
    sa.column("category", sa.String),
    sa.column("severity", sa.String),
    sa.column("enabled", sa.Boolean),
    sa.column("version", sa.Integer),
    sa.column("rule_type", sa.String),
    sa.column("conditions", sa.JSON),
    sa.column("sequence_conditions", sa.JSON),
    sa.column("time_window_seconds", sa.Integer),
    sa.column("rule_metadata", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("updated_at", sa.DateTime(timezone=True)),
)

_detections_table = sa.table(
    "detections",
    sa.column("id", sa.Uuid),
    sa.column("rule_id", sa.Uuid),
    sa.column("rule_version", sa.Integer),
    sa.column("host_id", sa.Uuid),
    sa.column("event_id", sa.Uuid),
    sa.column("process_id", sa.Uuid),
    sa.column("session_id", sa.Uuid),
    sa.column("timestamp", sa.DateTime(timezone=True)),
    sa.column("severity", sa.String),
    sa.column("title", sa.String),
    sa.column("description", sa.String),
    sa.column("category", sa.String),
    sa.column("status", sa.String),
    sa.column("notification_status", sa.String),
    sa.column("matched_conditions", sa.JSON),
    sa.column("evidence", sa.JSON),
    sa.column("dedup_hash", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("acknowledged_at", sa.DateTime(timezone=True)),
    sa.column("acknowledged_by_id", sa.Uuid),
)

_detections_table_0005 = sa.table(
    "detections",
    sa.column("id", sa.Uuid),
    sa.column("rule_id", sa.Uuid),
    sa.column("rule_version", sa.Integer),
    sa.column("host_id", sa.Uuid),
    sa.column("event_id", sa.Uuid),
    sa.column("process_id", sa.Uuid),
    sa.column("session_id", sa.Uuid),
    sa.column("fim_deviation_id", sa.Uuid),
    sa.column("timestamp", sa.DateTime(timezone=True)),
    sa.column("severity", sa.String),
    sa.column("title", sa.String),
    sa.column("description", sa.String),
    sa.column("category", sa.String),
    sa.column("status", sa.String),
    sa.column("notification_status", sa.String),
    sa.column("matched_conditions", sa.JSON),
    sa.column("evidence", sa.JSON),
    sa.column("dedup_hash", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("acknowledged_at", sa.DateTime(timezone=True)),
    sa.column("acknowledged_by_id", sa.Uuid),
)

_fim_baselines_table = sa.table(
    "fim_baselines",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("version", sa.Integer),
    sa.column("status", sa.String),
    sa.column("path_scope", sa.JSON),
    sa.column("include_patterns", sa.JSON),
    sa.column("exclude_patterns", sa.JSON),
    sa.column("total_files", sa.Integer),
    sa.column("total_bytes", sa.BigInteger),
    sa.column("scan_duration_ms", sa.BigInteger),
    sa.column("error_message", sa.Text),
    sa.column("baseline_metadata", sa.JSON),
    sa.column("baseline_at", sa.DateTime(timezone=True)),
    sa.column("completed_at", sa.DateTime(timezone=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_fim_baseline_files_table = sa.table(
    "fim_baseline_files",
    sa.column("id", sa.Uuid),
    sa.column("baseline_id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("file_path", sa.String),
    sa.column("file_name", sa.String),
    sa.column("file_type", sa.String),
    sa.column("hash_sha256", sa.String),
    sa.column("hash_sha1", sa.String),
    sa.column("hash_md5", sa.String),
    sa.column("file_size", sa.BigInteger),
    sa.column("permissions", sa.String),
    sa.column("mode", sa.Integer),
    sa.column("owner_uid", sa.Integer),
    sa.column("owner_gid", sa.Integer),
    sa.column("owner_user", sa.String),
    sa.column("owner_group", sa.String),
    sa.column("mtime", sa.DateTime(timezone=True)),
    sa.column("ctime", sa.DateTime(timezone=True)),
    sa.column("inode", sa.BigInteger),
    sa.column("device_id", sa.BigInteger),
    sa.column("symlink_target", sa.String),
    sa.column("is_suid", sa.Boolean),
    sa.column("is_sgid", sa.Boolean),
    sa.column("is_executable", sa.Boolean),
    sa.column("fingerprint_metadata", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_fim_deviations_table = sa.table(
    "fim_deviations",
    sa.column("id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("baseline_id", sa.Uuid),
    sa.column("baseline_file_id", sa.Uuid),
    sa.column("detection_id", sa.Uuid),
    sa.column("file_path", sa.String),
    sa.column("file_type", sa.String),
    sa.column("deviation_type", sa.String),
    sa.column("severity", sa.String),
    sa.column("is_content_modified", sa.Boolean),
    sa.column("is_metadata_modified", sa.Boolean),
    sa.column("expected_values", sa.JSON),
    sa.column("observed_values", sa.JSON),
    sa.column("summary", sa.String),
    sa.column("explanation", sa.Text),
    sa.column("detected_at", sa.DateTime(timezone=True)),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_incidents_table = sa.table(
    "incidents",
    sa.column("id", sa.Uuid),
    sa.column("title", sa.String),
    sa.column("description", sa.String),
    sa.column("severity", sa.String),
    sa.column("status", sa.String),
    sa.column("category", sa.String),
    sa.column("host_id", sa.Uuid),
    sa.column("created_by_id", sa.Uuid),
    sa.column("assigned_to_id", sa.Uuid),
    sa.column("first_observed_at", sa.DateTime(timezone=True)),
    sa.column("last_observed_at", sa.DateTime(timezone=True)),
    sa.column("contained_at", sa.DateTime(timezone=True)),
    sa.column("containment_summary", sa.String),
    sa.column("resolved_at", sa.DateTime(timezone=True)),
    sa.column("resolution_summary", sa.String),
    sa.column("closed_at", sa.DateTime(timezone=True)),
    sa.column("closure_summary", sa.String),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("updated_at", sa.DateTime(timezone=True)),
)

_incident_events_table = sa.table(
    "incident_events",
    sa.column("id", sa.Uuid),
    sa.column("incident_id", sa.Uuid),
    sa.column("event_id", sa.Uuid),
    sa.column("relationship", sa.String),
    sa.column("association_timestamp", sa.DateTime(timezone=True)),
    sa.column("investigation_notes", sa.String),
)

_incident_evidence_table = sa.table(
    "incident_evidence",
    sa.column("id", sa.Uuid),
    sa.column("incident_id", sa.Uuid),
    sa.column("evidence_type", sa.String),
    sa.column("source_id", sa.String),
    sa.column("title", sa.String),
    sa.column("description", sa.String),
    sa.column("provenance", sa.JSON),
    sa.column("detection_id", sa.Uuid),
    sa.column("event_id", sa.Uuid),
    sa.column("fim_deviation_id", sa.Uuid),
    sa.column("session_id", sa.Uuid),
    sa.column("snapshot_id", sa.Uuid),
    sa.column("process_id", sa.Uuid),
    sa.column("file_id", sa.Uuid),
    sa.column("created_by_id", sa.Uuid),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_incident_history_table = sa.table(
    "incident_history",
    sa.column("id", sa.Uuid),
    sa.column("incident_id", sa.Uuid),
    sa.column("change_type", sa.String),
    sa.column("from_status", sa.String),
    sa.column("to_status", sa.String),
    sa.column("from_severity", sa.String),
    sa.column("to_severity", sa.String),
    sa.column("user_id", sa.Uuid),
    sa.column("notes", sa.String),
    sa.column("history_metadata", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_workspaces_table = sa.table(
    "workspaces",
    sa.column("id", sa.Uuid),
    sa.column("name", sa.String),
    sa.column("description", sa.String),
    sa.column("owner_id", sa.Uuid),
    sa.column("host_id", sa.Uuid),
    sa.column("incident_id", sa.Uuid),
    sa.column("status", sa.String),
    sa.column("configuration", sa.JSON),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("updated_at", sa.DateTime(timezone=True)),
)

_evidence_tags_table = sa.table(
    "evidence_tags",
    sa.column("id", sa.Uuid),
    sa.column("name", sa.String),
    sa.column("description", sa.String),
    sa.column("color", sa.String),
    sa.column("category", sa.String),
    sa.column("created_by_id", sa.Uuid),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_evidence_tag_associations_table = sa.table(
    "evidence_tag_associations",
    sa.column("id", sa.Uuid),
    sa.column("tag_id", sa.Uuid),
    sa.column("evidence_type", sa.String),
    sa.column("evidence_id", sa.String),
    sa.column("host_id", sa.Uuid),
    sa.column("created_by_id", sa.Uuid),
    sa.column("created_at", sa.DateTime(timezone=True)),
)

_evidence_annotations_table = sa.table(
    "evidence_annotations",
    sa.column("id", sa.Uuid),
    sa.column("evidence_type", sa.String),
    sa.column("evidence_id", sa.String),
    sa.column("host_id", sa.Uuid),
    sa.column("workspace_id", sa.Uuid),
    sa.column("author_id", sa.Uuid),
    sa.column("annotation_text", sa.Text),
    sa.column("created_at", sa.DateTime(timezone=True)),
    sa.column("updated_at", sa.DateTime(timezone=True)),
)


def _populate_test_files(engine: sa.Engine, host_id: uuid.UUID) -> dict[str, uuid.UUID]:
    """Insert test records with legacy, canonical, and edge-case file_types."""
    records = {
        "reg": (uuid.uuid4(), "/test/legacy_regular", "regular"),
        "reg_alt": (uuid.uuid4(), "/test/legacy_regular_file", "regular_file"),
        "canon_file": (uuid.uuid4(), "/test/canonical_file", "file"),
        "canon_dir": (uuid.uuid4(), "/test/canonical_dir", "directory"),
        "canon_sym": (uuid.uuid4(), "/test/canonical_symlink", "symlink"),
        "null_type": (uuid.uuid4(), "/test/null_type", None),
        "empty_type": (uuid.uuid4(), "/test/empty_type", ""),
        "custom_type": (uuid.uuid4(), "/test/custom_fifo", "fifo"),
        "mixed_case_reg": (uuid.uuid4(), "/test/mixed_case_reg", "Regular"),
        "upper_reg": (uuid.uuid4(), "/test/upper_reg", "REGULAR"),
        "similar_type": (uuid.uuid4(), "/test/similar_type", "regular_file_v2"),
    }

    now = _utcnow()
    with engine.begin() as conn:
        conn.execute(
            _hosts_table.insert().values(
                id=host_id,
                hostname="test-mig-host",
                created_at=now,
            )
        )

        for key, (file_id, path, file_type) in records.items():
            conn.execute(
                _files_table.insert().values(
                    id=file_id,
                    host_id=host_id,
                    path=path,
                    file_type=file_type,
                    first_seen_at=now,
                    created_at=now,
                )
            )

    return {k: v[0] for k, v in records.items()}


def _get_file_types(engine: sa.Engine, file_ids: dict[str, uuid.UUID]) -> dict[str, str | None]:
    """Retrieve current file_type values for test records."""
    result = {}
    with engine.connect() as conn:
        for key, file_id in file_ids.items():
            stmt = sa.select(_files_table.c.file_type).where(_files_table.c.id == file_id)
            val = conn.execute(stmt).scalar()
            result[key] = val
    return result


def _get_current_revision(engine: sa.Engine) -> str | None:
    """Read the current Alembic version from alembic_version table."""
    with engine.connect() as conn:
        return conn.execute(
            sa.text("SELECT version_num FROM alembic_version")
        ).scalar()


class TestNormalizeFileTypesMigrationSQLite:
    """Test 0002_normalize_file_types against an isolated SQLite database."""

    def test_upgrade_and_downgrade_normalization(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_path = tmp_path / "disposable_test.db"
        db_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        # 1. Upgrade to initial schema (0001_phase1_schema)
        command.upgrade(alembic_cfg, "0001_phase1_schema")

        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0001_phase1_schema"

        # 2. Seed test data containing legacy, canonical, and other values
        host_id = uuid.uuid4()
        file_ids = _populate_test_files(engine, host_id)

        initial_types = _get_file_types(engine, file_ids)
        assert initial_types["reg"] == "regular"
        assert initial_types["reg_alt"] == "regular_file"
        assert initial_types["canon_file"] == "file"
        assert initial_types["canon_dir"] == "directory"
        assert initial_types["canon_sym"] == "symlink"
        assert initial_types["null_type"] is None
        assert initial_types["empty_type"] == ""
        assert initial_types["custom_type"] == "fifo"
        assert initial_types["mixed_case_reg"] == "Regular"
        assert initial_types["upper_reg"] == "REGULAR"
        assert initial_types["similar_type"] == "regular_file_v2"

        # 3. Upgrade to 0002_normalize_file_types
        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        # 4. Verify normalized file_type values
        updated_types = _get_file_types(engine, file_ids)
        assert updated_types["reg"] == "file", "regular should be converted to file"
        assert updated_types["reg_alt"] == "file", "regular_file should be converted to file"
        assert updated_types["canon_file"] == "file", "canonical file should remain file"
        assert updated_types["canon_dir"] == "directory", "directory must be preserved"
        assert updated_types["canon_sym"] == "symlink", "symlink must be preserved"
        assert updated_types["null_type"] is None, "NULL file_type must be preserved"
        assert updated_types["empty_type"] == "", "Empty string must be preserved"
        assert updated_types["custom_type"] == "fifo", "custom types must be preserved"
        assert updated_types["mixed_case_reg"] == "Regular", "exact match only"
        assert updated_types["upper_reg"] == "REGULAR", "exact match only"
        assert updated_types["similar_type"] == "regular_file_v2", "exact match only"

        # 5. Insert a newly created canonical 'file' record while on 0002
        new_file_id = uuid.uuid4()
        now = _utcnow()
        with engine.begin() as conn:
            conn.execute(
                _files_table.insert().values(
                    id=new_file_id,
                    host_id=host_id,
                    path="/test/newly_created_canonical_file",
                    file_type="file",
                    first_seen_at=now,
                    created_at=now,
                )
            )

        # 6. Downgrade back to 0001_phase1_schema
        command.downgrade(alembic_cfg, "0001_phase1_schema")
        assert _get_current_revision(engine) == "0001_phase1_schema"

        # 7. Verify downgrade behavior: safe no-op that does NOT indiscriminately
        # convert canonical 'file' records back to legacy values.
        downgraded_types = _get_file_types(engine, file_ids)
        assert downgraded_types["reg"] == "file", "downgrade must not revert file back to regular"
        assert downgraded_types["reg_alt"] == "file", "downgrade must not revert file back to regular_file"
        assert downgraded_types["canon_file"] == "file", "canonical file remains file"
        assert downgraded_types["canon_dir"] == "directory"
        assert downgraded_types["canon_sym"] == "symlink"
        assert downgraded_types["null_type"] is None
        assert downgraded_types["empty_type"] == ""
        assert downgraded_types["custom_type"] == "fifo"

        # Newly inserted canonical file must also remain untouched
        new_file_type = _get_file_types(engine, {"new": new_file_id})["new"]
        assert new_file_type == "file", "newly created canonical file must not be corrupted on downgrade"

        # 8. Test re-upgrade to 0002_normalize_file_types is idempotent
        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"
        reupgraded_types = _get_file_types(engine, file_ids)
        assert reupgraded_types == updated_types

        engine.dispose()

    def test_empty_files_table_migration(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify migration upgrade and downgrade succeed on an empty files table."""
        db_path = tmp_path / "empty_test.db"
        db_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        command.upgrade(alembic_cfg, "0001_phase1_schema")
        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0001_phase1_schema"

        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        command.downgrade(alembic_cfg, "0001_phase1_schema")
        assert _get_current_revision(engine) == "0001_phase1_schema"

        engine.dispose()


PROTECTED_DATABASES: frozenset[str] = frozenset(
    {
        "osiris",
        "osiris_dev",
        "osiris_desktop_dev",
        "osiris_l1_validation_d4daacd",
    }
)


def _is_safe_disposable_db_name(name: str) -> bool:
    """Validate that name is a disposable test DB and not a protected database."""
    if not isinstance(name, str):
        return False
    if name in PROTECTED_DATABASES:
        return False
    return name.startswith("osiris_disp_mig_")


def _get_safe_maintenance_url(
    base_url: sa.engine.URL, fallback_db: str = "postgres"
) -> sa.engine.URL:
    """Return a maintenance connection URL that never points to a protected database."""
    target_db = base_url.database
    if (
        target_db
        and target_db not in PROTECTED_DATABASES
        and target_db in ("postgres", "template1")
    ):
        return base_url
    return base_url.set(database=fallback_db)


def _sanitize_error_msg(msg: str) -> str:
    """Mask any embedded passwords in database connection error messages."""
    import re

    return re.sub(r":([^:@/\s]+)@", ":***@", str(msg))


@pytest.fixture
def disposable_pg_url() -> Generator[str, None, None]:
    """Create a temporary disposable PostgreSQL database, yield its URL, and drop it.

    Safety invariants:
    - Requires OSIRIS_TEST_DATABASE_URL; never falls back to OSIRIS_DATABASE_URL.
    - Uses only the dedicated test-only connection for database creation and teardown.
    - Never modifies or connects to protected databases:
      (osiris, osiris_l1_validation_d4daacd).
    - Yields a uniquely named disposable database (osiris_disp_mig_<uuid>) and drops it.
    - Never exposes database credentials in error messages or logs.
    """
    test_url_str = (
        os.environ.get("OSIRIS_TEST_DATABASE_URL") or settings.test_database_url
    )
    if not test_url_str or not test_url_str.strip():
        pytest.skip(
            "OSIRIS_TEST_DATABASE_URL is not configured. PostgreSQL "
            "disposable-database tests require a dedicated test connection with "
            "CREATEDB privilege (e.g. export OSIRIS_TEST_DATABASE_URL="
            "'postgresql://osiris_test:password@localhost:5432/postgres')."
        )

    try:
        base_url = sa.engine.make_url(test_url_str.strip())
    except Exception as parse_err:
        pytest.skip(
            f"Invalid OSIRIS_TEST_DATABASE_URL format: "
            f"{_sanitize_error_msg(str(parse_err))}"
        )

    if not base_url.drivername.startswith("postgresql"):
        pytest.skip(
            "OSIRIS_TEST_DATABASE_URL must be a PostgreSQL connection URL."
        )

    test_db_name = f"osiris_disp_mig_{uuid.uuid4().hex[:12]}"
    assert _is_safe_disposable_db_name(
        test_db_name
    ), f"Invalid disposable database name: {test_db_name}"

    maintenance_url = _get_safe_maintenance_url(base_url, fallback_db="postgres")
    disposable_url = base_url.set(database=test_db_name)

    created = False
    creation_errors: list[str] = []

    # Attempt 1: SQLAlchemy on primary maintenance db (e.g. postgres, template1)
    for m_db in [maintenance_url.database or "postgres", "template1"]:
        if created:
            break
        current_m_url = base_url.set(database=m_db)
        try:
            m_engine = sa.create_engine(
                str(current_m_url), isolation_level="AUTOCOMMIT"
            )
            with m_engine.connect() as conn:
                conn.execute(sa.text(f'CREATE DATABASE "{test_db_name}"'))
            m_engine.dispose()
            maintenance_url = current_m_url
            created = True
        except Exception as sa_err:
            creation_errors.append(f"{m_db}: {_sanitize_error_msg(str(sa_err))}")

    # Attempt 2: Fallback to createdb CLI
    if not created:
        try:
            env = os.environ.copy()
            if base_url.password:
                env["PGPASSWORD"] = base_url.password
            cmd = ["createdb"]
            if base_url.host:
                cmd.extend(["-h", base_url.host])
            if base_url.port:
                cmd.extend(["-p", str(base_url.port)])
            if base_url.username:
                cmd.extend(["-U", base_url.username])
            cmd.append(test_db_name)
            res = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if res.returncode == 0:
                created = True
            else:
                creation_errors.append(
                    f"createdb CLI: {_sanitize_error_msg(res.stderr.strip())}"
                )
        except FileNotFoundError:
            creation_errors.append("createdb CLI not found")

    if not created:
        err_details = "; ".join(creation_errors)
        pytest.skip(
            f"PostgreSQL test database creation failed ({err_details}). "
            "Please configure OSIRIS_TEST_DATABASE_URL with a dedicated role having "
            "CREATEDB privileges (e.g. export OSIRIS_TEST_DATABASE_URL="
            "'postgresql://osiris_test:password@localhost:5432/postgres')."
        )

    try:
        yield str(disposable_url)
    finally:
        if _is_safe_disposable_db_name(test_db_name):
            dropped = False
            try:
                m_engine = sa.create_engine(
                    str(maintenance_url), isolation_level="AUTOCOMMIT"
                )
                with m_engine.connect() as conn:
                    conn.execute(
                        sa.text(
                            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                            "WHERE datname = :dbname AND pid <> pg_backend_pid()"
                        ),
                        {"dbname": test_db_name},
                    )
                    conn.execute(sa.text(f'DROP DATABASE IF EXISTS "{test_db_name}"'))
                m_engine.dispose()
                dropped = True
            except Exception:
                pass

            if not dropped:
                try:
                    env = os.environ.copy()
                    if base_url.password:
                        env["PGPASSWORD"] = base_url.password
                    cmd = ["dropdb", "--if-exists"]
                    if base_url.host:
                        cmd.extend(["-h", base_url.host])
                    if base_url.port:
                        cmd.extend(["-p", str(base_url.port)])
                    if base_url.username:
                        cmd.extend(["-U", base_url.username])
                    cmd.append(test_db_name)
                    subprocess.run(cmd, env=env, capture_output=True)
                except Exception:
                    pass


class TestDisposablePgSafety:
    """Safety tests for disposable PostgreSQL database fixtures."""

    def test_protected_database_names_rejected(self) -> None:
        """Protected databases must never be recognized as safe disposable databases."""
        assert not _is_safe_disposable_db_name("osiris")
        assert not _is_safe_disposable_db_name("osiris_dev")
        assert not _is_safe_disposable_db_name("osiris_desktop_dev")
        assert not _is_safe_disposable_db_name("osiris_l1_validation_d4daacd")
        assert not _is_safe_disposable_db_name("postgres")
        assert not _is_safe_disposable_db_name("template1")
        assert not _is_safe_disposable_db_name("production_db")
        assert _is_safe_disposable_db_name("osiris_disp_mig_abcdef012345")

    def test_maintenance_url_never_points_to_protected_database(self) -> None:
        """Maintenance URL must redirect away from protected application databases."""
        app_url = sa.engine.make_url("postgresql://osiris:pass@localhost:5432/osiris")
        m_url = _get_safe_maintenance_url(app_url, fallback_db="postgres")
        assert m_url.database != "osiris"
        assert m_url.database == "postgres"

        val_url = sa.engine.make_url(
            "postgresql://user:pass@localhost:5432/osiris_l1_validation_d4daacd"
        )
        m_val_url = _get_safe_maintenance_url(val_url, fallback_db="template1")
        assert m_val_url.database != "osiris_l1_validation_d4daacd"
        assert m_val_url.database == "template1"

    def test_password_sanitization_in_errors(self) -> None:
        """Database connection strings with passwords must be masked in errors."""
        raw_err = (
            "connect to postgresql://osiris_user:SuperSecretPass99@localhost:5432/db"
        )
        sanitized = _sanitize_error_msg(raw_err)
        assert "SuperSecretPass99" not in sanitized
        assert ":***@" in sanitized

    def test_absent_test_database_url_skips(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When OSIRIS_TEST_DATABASE_URL is absent, disposable_pg_url skips."""
        monkeypatch.delenv("OSIRIS_TEST_DATABASE_URL", raising=False)
        monkeypatch.setattr(settings, "test_database_url", None)

        with pytest.raises(
            pytest.skip.Exception,
            match="OSIRIS_TEST_DATABASE_URL is not configured",
        ):
            next(disposable_pg_url.__wrapped__())


class TestNormalizeFileTypesMigrationPostgreSQL:
    """Test 0002_normalize_file_types against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_normalization_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade to initial schema (0001_phase1_schema)
        command.upgrade(alembic_cfg, "0001_phase1_schema")

        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0001_phase1_schema"

        # 2. Seed test data containing legacy, canonical, and other values
        host_id = uuid.uuid4()
        file_ids = _populate_test_files(engine, host_id)

        initial_types = _get_file_types(engine, file_ids)
        assert initial_types["reg"] == "regular"
        assert initial_types["reg_alt"] == "regular_file"
        assert initial_types["canon_file"] == "file"
        assert initial_types["canon_dir"] == "directory"
        assert initial_types["canon_sym"] == "symlink"
        assert initial_types["null_type"] is None
        assert initial_types["empty_type"] == ""
        assert initial_types["custom_type"] == "fifo"
        assert initial_types["mixed_case_reg"] == "Regular"
        assert initial_types["upper_reg"] == "REGULAR"
        assert initial_types["similar_type"] == "regular_file_v2"

        # 3. Upgrade to 0002_normalize_file_types
        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        # 4. Verify normalized file_type values
        updated_types = _get_file_types(engine, file_ids)
        assert updated_types["reg"] == "file", "regular should be converted to file"
        assert updated_types["reg_alt"] == "file", "regular_file should be converted to file"
        assert updated_types["canon_file"] == "file", "canonical file should remain file"
        assert updated_types["canon_dir"] == "directory", "directory must be preserved"
        assert updated_types["canon_sym"] == "symlink", "symlink must be preserved"
        assert updated_types["null_type"] is None, "NULL file_type must be preserved"
        assert updated_types["empty_type"] == "", "Empty string must be preserved"
        assert updated_types["custom_type"] == "fifo", "custom types must be preserved"
        assert updated_types["mixed_case_reg"] == "Regular", "exact match only"
        assert updated_types["upper_reg"] == "REGULAR", "exact match only"
        assert updated_types["similar_type"] == "regular_file_v2", "exact match only"

        # 5. Insert a newly created canonical 'file' record while on 0002
        new_file_id = uuid.uuid4()
        now = _utcnow()
        with engine.begin() as conn:
            conn.execute(
                _files_table.insert().values(
                    id=new_file_id,
                    host_id=host_id,
                    path="/test/newly_created_canonical_file",
                    file_type="file",
                    first_seen_at=now,
                    created_at=now,
                )
            )

        # 6. Downgrade back to 0001_phase1_schema
        command.downgrade(alembic_cfg, "0001_phase1_schema")
        assert _get_current_revision(engine) == "0001_phase1_schema"

        # 7. Verify downgrade behavior
        downgraded_types = _get_file_types(engine, file_ids)
        assert downgraded_types["reg"] == "file"
        assert downgraded_types["reg_alt"] == "file"
        assert downgraded_types["canon_file"] == "file"
        assert downgraded_types["canon_dir"] == "directory"
        assert downgraded_types["canon_sym"] == "symlink"
        assert downgraded_types["null_type"] is None
        assert downgraded_types["empty_type"] == ""
        assert downgraded_types["custom_type"] == "fifo"

        new_file_type = _get_file_types(engine, {"new": new_file_id})["new"]
        assert new_file_type == "file", "newly created canonical file must not be corrupted on downgrade"

        # 8. Test re-upgrade to 0002_normalize_file_types is idempotent
        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"
        reupgraded_types = _get_file_types(engine, file_ids)
        assert reupgraded_types == updated_types

        engine.dispose()

    def test_empty_files_table_migration_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify migration upgrade and downgrade succeed on an empty files table in PostgreSQL."""
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        command.upgrade(alembic_cfg, "0001_phase1_schema")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0001_phase1_schema"

        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        command.downgrade(alembic_cfg, "0001_phase1_schema")
        assert _get_current_revision(engine) == "0001_phase1_schema"

        engine.dispose()

    def test_check_constraints_enforced_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify CHECK constraints (cpu_percent >= 0) are enforced in PostgreSQL."""
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        command.upgrade(alembic_cfg, "0001_phase1_schema")
        engine = sa.create_engine(disposable_pg_url)
        host_id = uuid.uuid4()
        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="constraint-test-host",
                    created_at=_utcnow(),
                )
            )

        resource_snapshots_table = sa.table(
            "resource_snapshots",
            sa.column("id", sa.Uuid),
            sa.column("host_id", sa.Uuid),
            sa.column("timestamp", sa.DateTime(timezone=True)),
            sa.column("cpu_percent", sa.Float),
            sa.column("created_at", sa.DateTime(timezone=True)),
        )

        with pytest.raises(sa.exc.IntegrityError):
            with engine.begin() as conn:
                conn.execute(
                    resource_snapshots_table.insert().values(
                        id=uuid.uuid4(),
                        host_id=host_id,
                        timestamp=_utcnow(),
                        cpu_percent=-10.0,
                        created_at=_utcnow(),
                    )
                )

        engine.dispose()


class TestSnapshotsAndSessionsMigrationSQLite:
    """Test 0003_snapshots_and_sessions against an isolated SQLite database."""

    def test_upgrade_and_downgrade_snapshots_and_sessions(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_path = tmp_path / "disposable_snap_sess.db"
        db_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        # 1. Upgrade through 0002
        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        inspector = sa.inspect(engine)
        pre_tables = set(inspector.get_table_names())
        assert "snapshots" not in pre_tables
        assert "sessions" not in pre_tables

        # 2. Upgrade to 0003_snapshots_and_sessions
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        # 3. Verify schema structure
        inspector = sa.inspect(engine)
        post_tables = set(inspector.get_table_names())
        assert "snapshots" in post_tables
        assert "sessions" in post_tables

        snapshot_cols = {col["name"] for col in inspector.get_columns("snapshots")}
        expected_snap_cols = {"id", "host_id", "timestamp", "snapshot_type", "data", "created_at"}
        assert expected_snap_cols.issubset(snapshot_cols)

        session_cols = {col["name"] for col in inspector.get_columns("sessions")}
        expected_sess_cols = {
            "id", "host_id", "linux_user_id", "session_type",
            "terminal", "remote_host", "started_at", "ended_at", "created_at"
        }
        assert expected_sess_cols.issubset(session_cols)

        # Verify indexes
        snap_indexes = {ix["name"] for ix in inspector.get_indexes("snapshots")}
        assert "ix_snapshots_host_ts" in snap_indexes

        sess_indexes = {ix["name"] for ix in inspector.get_indexes("sessions")}
        assert "ix_sessions_host_started" in sess_indexes
        assert "ix_sessions_linux_user_id" in sess_indexes

        # 4. Insert data into snapshots and sessions
        now = _utcnow()
        host_id = uuid.uuid4()
        user_id = uuid.uuid4()
        snap_id = uuid.uuid4()
        sess_id = uuid.uuid4()
        sess_null_user_id = uuid.uuid4()

        payload_data = {"metrics": {"cpu": 15.4, "memory": 55.2}, "processes": [101, 102]}

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="snapshot-mig-host",
                    created_at=now,
                )
            )
            conn.execute(
                _linux_users_table.insert().values(
                    id=user_id,
                    host_id=host_id,
                    uid=1001,
                    username="snapuser",
                    first_seen_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _snapshots_table.insert().values(
                    id=snap_id,
                    host_id=host_id,
                    timestamp=now,
                    snapshot_type="system",
                    data=payload_data,
                    created_at=now,
                )
            )
            conn.execute(
                _sessions_table.insert().values(
                    id=sess_id,
                    host_id=host_id,
                    linux_user_id=user_id,
                    session_type="ssh",
                    terminal="pts/2",
                    remote_host="192.168.1.55",
                    started_at=now,
                    ended_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _sessions_table.insert().values(
                    id=sess_null_user_id,
                    host_id=host_id,
                    linux_user_id=None,
                    session_type=None,
                    terminal=None,
                    remote_host=None,
                    started_at=now,
                    ended_at=None,
                    created_at=now,
                )
            )

        # 5. Read back and verify persisted records
        with engine.connect() as conn:
            snap_row = conn.execute(
                sa.select(_snapshots_table).where(_snapshots_table.c.id == snap_id)
            ).one()
            assert snap_row.host_id == host_id
            assert snap_row.snapshot_type == "system"
            import json
            actual_data = snap_row.data if isinstance(snap_row.data, dict) else json.loads(snap_row.data)
            assert actual_data["metrics"]["cpu"] == 15.4

            sess_row = conn.execute(
                sa.select(_sessions_table).where(_sessions_table.c.id == sess_id)
            ).one()
            assert sess_row.host_id == host_id
            assert sess_row.linux_user_id == user_id
            assert sess_row.session_type == "ssh"
            assert sess_row.terminal == "pts/2"
            assert sess_row.remote_host == "192.168.1.55"

            null_sess_row = conn.execute(
                sa.select(_sessions_table).where(_sessions_table.c.id == sess_null_user_id)
            ).one()
            assert null_sess_row.linux_user_id is None
            assert null_sess_row.session_type is None
            assert null_sess_row.terminal is None
            assert null_sess_row.remote_host is None
            assert null_sess_row.ended_at is None

        # 6. Downgrade to 0002_normalize_file_types
        command.downgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "snapshots" not in down_tables
        assert "sessions" not in down_tables
        assert "hosts" in down_tables

        # 7. Re-upgrade to 0003_snapshots_and_sessions is idempotent
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        inspector = sa.inspect(engine)
        reup_tables = set(inspector.get_table_names())
        assert "snapshots" in reup_tables
        assert "sessions" in reup_tables

        engine.dispose()

    def test_full_empty_cycle(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Verify full upgrade and downgrade cycle from base to 0003 on empty DB."""
        db_path = tmp_path / "empty_full_cycle.db"
        db_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        command.upgrade(alembic_cfg, "0001_phase1_schema")
        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0001_phase1_schema"

        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        command.downgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        command.downgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        command.downgrade(alembic_cfg, "0001_phase1_schema")
        assert _get_current_revision(engine) == "0001_phase1_schema"

        command.downgrade(alembic_cfg, "base")
        assert _get_current_revision(engine) is None

        engine.dispose()


class TestSnapshotsAndSessionsMigrationPostgreSQL:
    """Test 0003_snapshots_and_sessions against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_snapshots_and_sessions_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        command.upgrade(alembic_cfg, "0002_normalize_file_types")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        # Upgrade to 0003
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "snapshots" in tables
        assert "sessions" in tables

        snapshot_cols = {col["name"] for col in inspector.get_columns("snapshots")}
        expected_snap_cols = {"id", "host_id", "timestamp", "snapshot_type", "data", "created_at"}
        assert expected_snap_cols.issubset(snapshot_cols)

        session_cols = {col["name"] for col in inspector.get_columns("sessions")}
        expected_sess_cols = {
            "id", "host_id", "linux_user_id", "session_type",
            "terminal", "remote_host", "started_at", "ended_at", "created_at"
        }
        assert expected_sess_cols.issubset(session_cols)

        # Verify indexes on PostgreSQL
        snap_indexes = {ix["name"] for ix in inspector.get_indexes("snapshots")}
        assert "ix_snapshots_host_ts" in snap_indexes

        sess_indexes = {ix["name"] for ix in inspector.get_indexes("sessions")}
        assert "ix_sessions_host_started" in sess_indexes
        assert "ix_sessions_linux_user_id" in sess_indexes

        # Insert and verify JSONB in snapshots and sessions
        now = _utcnow()
        host_id = uuid.uuid4()
        user_id = uuid.uuid4()
        snap_id = uuid.uuid4()
        sess_id = uuid.uuid4()
        sess_null_user_id = uuid.uuid4()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="pg-snap-host",
                    created_at=now,
                )
            )
            conn.execute(
                _linux_users_table.insert().values(
                    id=user_id,
                    host_id=host_id,
                    uid=1002,
                    username="pguser",
                    first_seen_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _snapshots_table.insert().values(
                    id=snap_id,
                    host_id=host_id,
                    timestamp=now,
                    snapshot_type="system",
                    data={"nested": {"count": 100}},
                    created_at=now,
                )
            )
            conn.execute(
                _sessions_table.insert().values(
                    id=sess_id,
                    host_id=host_id,
                    linux_user_id=user_id,
                    session_type="tty",
                    terminal="tty1",
                    remote_host=None,
                    started_at=now,
                    ended_at=None,
                    created_at=now,
                )
            )
            conn.execute(
                _sessions_table.insert().values(
                    id=sess_null_user_id,
                    host_id=host_id,
                    linux_user_id=None,
                    session_type=None,
                    terminal=None,
                    remote_host=None,
                    started_at=now,
                    ended_at=None,
                    created_at=now,
                )
            )

        with engine.connect() as conn:
            snap_row = conn.execute(
                sa.select(_snapshots_table).where(_snapshots_table.c.id == snap_id)
            ).one()
            assert snap_row.data["nested"]["count"] == 100

            null_sess_row = conn.execute(
                sa.select(_sessions_table).where(_sessions_table.c.id == sess_null_user_id)
            ).one()
            assert null_sess_row.linux_user_id is None
            assert null_sess_row.session_type is None
            assert null_sess_row.terminal is None
            assert null_sess_row.remote_host is None
            assert null_sess_row.ended_at is None

        # Downgrade back to 0002
        command.downgrade(alembic_cfg, "0002_normalize_file_types")
        assert _get_current_revision(engine) == "0002_normalize_file_types"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "snapshots" not in down_tables
        assert "sessions" not in down_tables

        # Re-upgrade to 0003_snapshots_and_sessions
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        engine.dispose()


class TestDetectionsAndRulesMigrationSQLite:
    """Test 0004_detections_and_rules against an isolated SQLite database."""

    def test_upgrade_and_downgrade_detections_and_rules(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_path = tmp_path / "disposable_detect.db"
        db_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        # 1. Upgrade through 0003
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        inspector = sa.inspect(engine)
        pre_tables = set(inspector.get_table_names())
        assert "detection_rules" not in pre_tables
        assert "detections" not in pre_tables

        # 2. Upgrade to 0004_detections_and_rules
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        # 3. Verify schema structure
        inspector = sa.inspect(engine)
        post_tables = set(inspector.get_table_names())
        assert "detection_rules" in post_tables
        assert "detections" in post_tables

        rule_cols = {col["name"] for col in inspector.get_columns("detection_rules")}
        expected_rule_cols = {
            "id", "rule_id", "name", "description", "category", "severity",
            "enabled", "version", "rule_type", "conditions", "sequence_conditions",
            "time_window_seconds", "rule_metadata", "created_at", "updated_at"
        }
        assert expected_rule_cols.issubset(rule_cols)

        detection_cols = {col["name"] for col in inspector.get_columns("detections")}
        expected_detection_cols = {
            "id", "rule_id", "rule_version", "host_id", "event_id", "process_id",
            "session_id", "timestamp", "severity", "title", "description",
            "category", "status", "notification_status", "matched_conditions",
            "evidence", "dedup_hash", "created_at", "acknowledged_at", "acknowledged_by_id"
        }
        assert expected_detection_cols.issubset(detection_cols)

        # Verify indexes
        rule_indexes = {ix["name"] for ix in inspector.get_indexes("detection_rules")}
        assert "ix_detection_rules_rule_id" in rule_indexes
        assert "ix_detection_rules_category" in rule_indexes
        assert "ix_detection_rules_severity" in rule_indexes
        assert "ix_detection_rules_enabled" in rule_indexes

        detection_indexes = {ix["name"] for ix in inspector.get_indexes("detections")}
        assert "ix_detections_host_ts" in detection_indexes
        assert "ix_detections_rule_id" in detection_indexes
        assert "ix_detections_severity" in detection_indexes
        assert "ix_detections_status" in detection_indexes
        assert "ix_detections_category" in detection_indexes
        assert "ix_detections_dedup_hash" in detection_indexes

        # 4. Insert data into detection_rules and detections
        now = _utcnow()
        host_id = uuid.uuid4()
        rule_db_id = uuid.uuid4()
        detection_id = uuid.uuid4()

        conditions_data = {"all": [{"field": "command", "operator": "startswith", "value": "sudo "}]}
        evidence_data = {"triggering_events": [str(uuid.uuid4())], "summary": "sudo su executed"}
        matched_data = {"matched_field": "command", "value": "sudo su"}

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="detect-mig-host",
                    created_at=now,
                )
            )
            conn.execute(
                _detection_rules_table.insert().values(
                    id=rule_db_id,
                    rule_id="RULE-TEST-001",
                    name="Test Detection Rule",
                    description="Detects suspicious activity",
                    category="privilege_escalation",
                    severity="high",
                    enabled=True,
                    version=1,
                    rule_type="single_event",
                    conditions=conditions_data,
                    sequence_conditions=None,
                    time_window_seconds=None,
                    rule_metadata={"author": "Security Team"},
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _detections_table.insert().values(
                    id=detection_id,
                    rule_id=rule_db_id,
                    rule_version=1,
                    host_id=host_id,
                    event_id=None,
                    process_id=None,
                    session_id=None,
                    timestamp=now,
                    severity="high",
                    title="Suspicious Sudo Execution",
                    description="User executed sudo su",
                    category="privilege_escalation",
                    status="open",
                    notification_status="pending",
                    matched_conditions=matched_data,
                    evidence=evidence_data,
                    dedup_hash="abc123hash",
                    created_at=now,
                    acknowledged_at=None,
                    acknowledged_by_id=None,
                )
            )

        # 5. Read back and verify persisted records
        import json
        with engine.connect() as conn:
            rule_row = conn.execute(
                sa.select(_detection_rules_table).where(_detection_rules_table.c.id == rule_db_id)
            ).one()
            assert rule_row.rule_id == "RULE-TEST-001"
            assert rule_row.severity == "high"
            raw_cond = rule_row.conditions if isinstance(rule_row.conditions, dict) else json.loads(rule_row.conditions)
            assert raw_cond["all"][0]["operator"] == "startswith"

            detect_row = conn.execute(
                sa.select(_detections_table).where(_detections_table.c.id == detection_id)
            ).one()
            assert detect_row.host_id == host_id
            assert detect_row.title == "Suspicious Sudo Execution"
            assert detect_row.status == "open"
            raw_ev = detect_row.evidence if isinstance(detect_row.evidence, dict) else json.loads(detect_row.evidence)
            assert raw_ev["summary"] == "sudo su executed"

        # 6. Downgrade to 0003_snapshots_and_sessions
        command.downgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "detection_rules" not in down_tables
        assert "detections" not in down_tables
        assert "snapshots" in down_tables
        assert "sessions" in down_tables

        # 7. Re-upgrade to 0004_detections_and_rules is idempotent
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        inspector = sa.inspect(engine)
        reup_tables = set(inspector.get_table_names())
        assert "detection_rules" in reup_tables
        assert "detections" in reup_tables

        engine.dispose()


class TestDetectionsAndRulesMigrationPostgreSQL:
    """Test 0004_detections_and_rules against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_detections_and_rules_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade through 0003
        command.upgrade(alembic_cfg, "0003_snapshots_and_sessions")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        # 2. Upgrade to 0004_detections_and_rules
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "detection_rules" in tables
        assert "detections" in tables

        # Verify JSONB storage
        now = _utcnow()
        host_id = uuid.uuid4()
        rule_db_id = uuid.uuid4()
        detection_id = uuid.uuid4()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="pg-detect-host",
                    created_at=now,
                )
            )
            conn.execute(
                _detection_rules_table.insert().values(
                    id=rule_db_id,
                    rule_id="PG-RULE-001",
                    name="PG Test Rule",
                    description="PG test description",
                    category="reconnaissance",
                    severity="critical",
                    enabled=True,
                    version=1,
                    rule_type="single_event",
                    conditions={"all": [{"field": "object_path", "operator": "==", "value": "/etc/shadow"}]},
                    sequence_conditions=None,
                    time_window_seconds=None,
                    rule_metadata={"tactics": ["TA0007"]},
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _detections_table.insert().values(
                    id=detection_id,
                    rule_id=rule_db_id,
                    rule_version=1,
                    host_id=host_id,
                    event_id=None,
                    process_id=None,
                    session_id=None,
                    timestamp=now,
                    severity="critical",
                    title="Sensitive File Access",
                    description="/etc/shadow read detected",
                    category="reconnaissance",
                    status="open",
                    notification_status="pending",
                    matched_conditions={"object_path": "/etc/shadow"},
                    evidence={"file": "/etc/shadow", "user": "test"},
                    dedup_hash="pgdeduphash123",
                    created_at=now,
                    acknowledged_at=None,
                    acknowledged_by_id=None,
                )
            )

        with engine.connect() as conn:
            detect_row = conn.execute(
                sa.select(_detections_table).where(_detections_table.c.id == detection_id)
            ).one()
            assert detect_row.severity == "critical"
            assert detect_row.evidence["file"] == "/etc/shadow"

        # Downgrade back to 0003
        command.downgrade(alembic_cfg, "0003_snapshots_and_sessions")
        assert _get_current_revision(engine) == "0003_snapshots_and_sessions"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "detection_rules" not in down_tables
        assert "detections" not in down_tables

        # Re-upgrade to 0004
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        engine.dispose()


class TestFimMigrationSQLite:
    """Test 0005_fim_baselines_and_deviations migration against isolated SQLite database."""

    def test_upgrade_and_downgrade_fim_sqlite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_path = tmp_path / "test_fim_migration.db"
        sqlite_url = f"sqlite:///{db_path}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", sqlite_url)
        monkeypatch.setattr(settings, "database_url", sqlite_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", sqlite_url)

        # 1. Upgrade through 0004_detections_and_rules
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        engine = sa.create_engine(sqlite_url)
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        # 2. Upgrade to 0005_fim_baselines_deviations
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        # 3. Verify tables and columns exist
        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "fim_baselines" in tables
        assert "fim_baseline_files" in tables
        assert "fim_deviations" in tables

        detection_cols = {col["name"] for col in inspector.get_columns("detections")}
        assert "fim_deviation_id" in detection_cols

        # 4. Insert records across all tables and verify linkage
        now = _utcnow()
        host_id = uuid.uuid4()
        baseline_id = uuid.uuid4()
        file_id = uuid.uuid4()
        deviation_id = uuid.uuid4()
        rule_db_id = uuid.uuid4()
        detection_id = uuid.uuid4()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="sqlite-fim-host",
                    created_at=now,
                )
            )
            conn.execute(
                _fim_baselines_table.insert().values(
                    id=baseline_id,
                    host_id=host_id,
                    version=1,
                    status="completed",
                    path_scope=["/etc", "/bin"],
                    include_patterns=None,
                    exclude_patterns=[".git"],
                    total_files=1,
                    total_bytes=1024,
                    scan_duration_ms=45,
                    error_message=None,
                    baseline_metadata={"scanner": "fim_scanner_v1"},
                    baseline_at=now,
                    completed_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _fim_baseline_files_table.insert().values(
                    id=file_id,
                    baseline_id=baseline_id,
                    host_id=host_id,
                    file_path="/etc/passwd",
                    file_name="passwd",
                    file_type="file",
                    hash_sha256="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                    hash_sha1=None,
                    hash_md5=None,
                    file_size=1024,
                    permissions="0644",
                    mode=0o100644,
                    owner_uid=0,
                    owner_gid=0,
                    owner_user="root",
                    owner_group="root",
                    mtime=now,
                    ctime=now,
                    inode=123456,
                    device_id=1,
                    symlink_target=None,
                    is_suid=False,
                    is_sgid=False,
                    is_executable=False,
                    fingerprint_metadata=None,
                    created_at=now,
                )
            )
            conn.execute(
                _fim_deviations_table.insert().values(
                    id=deviation_id,
                    host_id=host_id,
                    baseline_id=baseline_id,
                    baseline_file_id=file_id,
                    detection_id=None,
                    file_path="/etc/passwd",
                    file_type="file",
                    deviation_type="modified_file",
                    severity="critical",
                    is_content_modified=True,
                    is_metadata_modified=False,
                    expected_values={"sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"},
                    observed_values={"sha256": "b5bb9d8014a0f9b1d61e21e796d78dccdf1352f23cd32812f4850b878ae4944c"},
                    summary="File /etc/passwd content modified",
                    explanation="Checksum mismatch detected on /etc/passwd.",
                    detected_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _detection_rules_table.insert().values(
                    id=rule_db_id,
                    rule_id="RULE-FIM-001",
                    name="Passwd Tampering",
                    description="Passwd modified",
                    category="file_integrity",
                    severity="critical",
                    enabled=True,
                    version=1,
                    rule_type="single_event",
                    conditions={"all": [{"field": "object_path", "operator": "==", "value": "/etc/passwd"}]},
                    sequence_conditions=None,
                    time_window_seconds=None,
                    rule_metadata=None,
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _detections_table_0005.insert().values(
                    id=detection_id,
                    rule_id=rule_db_id,
                    rule_version=1,
                    host_id=host_id,
                    event_id=None,
                    process_id=None,
                    session_id=None,
                    fim_deviation_id=deviation_id,
                    timestamp=now,
                    severity="critical",
                    title="Passwd Tampering Detected",
                    description="FIM detected change in /etc/passwd",
                    category="file_integrity",
                    status="open",
                    notification_status="pending",
                    matched_conditions={"conditions": []},
                    evidence={"path": "/etc/passwd"},
                    dedup_hash="fimdeduphash123",
                    created_at=now,
                    acknowledged_at=None,
                    acknowledged_by_id=None,
                )
            )

        with engine.connect() as conn:
            dev_row = conn.execute(
                sa.select(_fim_deviations_table).where(_fim_deviations_table.c.id == deviation_id)
            ).one()
            assert dev_row.deviation_type == "modified_file"
            assert dev_row.is_content_modified is True

            det_row = conn.execute(
                sa.select(_detections_table_0005).where(_detections_table_0005.c.id == detection_id)
            ).one()
            assert det_row.fim_deviation_id == deviation_id

        # 5. Downgrade back to 0004_detections_and_rules
        command.downgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "fim_baselines" not in down_tables
        assert "fim_baseline_files" not in down_tables
        assert "fim_deviations" not in down_tables

        # 6. Re-upgrade to 0005_fim_baselines_deviations is idempotent
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        inspector = sa.inspect(engine)
        reup_tables = set(inspector.get_table_names())
        assert "fim_baselines" in reup_tables
        assert "fim_baseline_files" in reup_tables
        assert "fim_deviations" in reup_tables

        engine.dispose()


class TestFimMigrationPostgreSQL:
    """Test 0005_fim_baselines_and_deviations against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_fim_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade through 0004
        command.upgrade(alembic_cfg, "0004_detections_and_rules")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        # 2. Upgrade to 0005
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "fim_baselines" in tables
        assert "fim_baseline_files" in tables
        assert "fim_deviations" in tables

        # Downgrade back to 0004
        command.downgrade(alembic_cfg, "0004_detections_and_rules")
        assert _get_current_revision(engine) == "0004_detections_and_rules"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "fim_baselines" not in down_tables
        assert "fim_baseline_files" not in down_tables
        assert "fim_deviations" not in down_tables

        # Re-upgrade to 0005
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        engine.dispose()


class TestIncidentMigrationSQLite:
    """Test 0006_incidents_and_evidence against an isolated temporary SQLite database."""

    def test_upgrade_and_downgrade_incidents_sqlite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_file = tmp_path / "test_mig_0006.db"
        sqlite_url = f"sqlite:///{db_file}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", sqlite_url)
        monkeypatch.setattr(settings, "database_url", sqlite_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", sqlite_url)

        # 1. Upgrade through 0005
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        engine = sa.create_engine(sqlite_url)
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        # 2. Upgrade to 0006_incidents_and_evidence
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        # 3. Verify tables and indexes exist
        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "incidents" in tables
        assert "incident_events" in tables
        assert "incident_evidence" in tables
        assert "incident_history" in tables

        # 4. Insert records across all 4 tables
        now = _utcnow()
        host_id = uuid.uuid4()
        user_id = uuid.uuid4()
        event_id = uuid.uuid4()
        incident_id = uuid.uuid4()
        event_assoc_id = uuid.uuid4()
        evidence_id = uuid.uuid4()
        history_id = uuid.uuid4()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="test-incident-host",
                    created_at=now,
                )
            )
            conn.execute(
                _events_table.insert().values(
                    id=event_id,
                    host_id=host_id,
                    process_id=None,
                    timestamp=now,
                    ingested_at=now,
                    source="process_collector",
                    event_type="process_spawn",
                    action="spawn",
                    severity="high",
                    uid=0,
                    username="root",
                    pid=1234,
                    ppid=1,
                    command="/bin/bash",
                    object_type="process",
                    object_path="/bin/bash",
                    success=True,
                    result="success",
                    payload={},
                    created_at=now,
                )
            )
            conn.execute(
                _incidents_table.insert().values(
                    id=incident_id,
                    title="Suspicious Root Activity",
                    description="Investigating suspicious root execution",
                    severity="high",
                    status="open",
                    category="privilege_escalation",
                    host_id=host_id,
                    created_by_id=None,
                    assigned_to_id=None,
                    first_observed_at=now,
                    last_observed_at=now,
                    contained_at=None,
                    containment_summary=None,
                    resolved_at=None,
                    resolution_summary=None,
                    closed_at=None,
                    closure_summary=None,
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _incident_events_table.insert().values(
                    id=event_assoc_id,
                    incident_id=incident_id,
                    event_id=event_id,
                    relationship="trigger",
                    association_timestamp=now,
                    investigation_notes="Triggering event",
                )
            )
            conn.execute(
                _incident_evidence_table.insert().values(
                    id=evidence_id,
                    incident_id=incident_id,
                    evidence_type="event",
                    source_id=str(event_id),
                    title="Primary Trigger Event",
                    description="Process spawn event under /tmp",
                    provenance={"source": "process_collector", "host_id": str(host_id)},
                    detection_id=None,
                    event_id=event_id,
                    fim_deviation_id=None,
                    session_id=None,
                    snapshot_id=None,
                    process_id=None,
                    file_id=None,
                    created_by_id=None,
                    created_at=now,
                )
            )
            conn.execute(
                _incident_history_table.insert().values(
                    id=history_id,
                    incident_id=incident_id,
                    change_type="incident_created",
                    from_status=None,
                    to_status="open",
                    from_severity=None,
                    to_severity="high",
                    user_id=None,
                    notes="Incident automatically created",
                    history_metadata={"source": "detection_correlation"},
                    created_at=now,
                )
            )

        with engine.connect() as conn:
            inc_row = conn.execute(
                sa.select(_incidents_table).where(_incidents_table.c.id == incident_id)
            ).one()
            assert inc_row.title == "Suspicious Root Activity"
            assert inc_row.severity == "high"
            assert inc_row.status == "open"

            ev_row = conn.execute(
                sa.select(_incident_evidence_table).where(_incident_evidence_table.c.id == evidence_id)
            ).one()
            assert ev_row.evidence_type == "event"
            assert ev_row.source_id == str(event_id)

        # 5. Downgrade back to 0005_fim_baselines_deviations
        command.downgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "incidents" not in down_tables
        assert "incident_events" not in down_tables
        assert "incident_evidence" not in down_tables
        assert "incident_history" not in down_tables

        # 6. Re-upgrade to 0006_incidents_and_evidence is idempotent
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        inspector = sa.inspect(engine)
        reup_tables = set(inspector.get_table_names())
        assert "incidents" in reup_tables
        assert "incident_events" in reup_tables
        assert "incident_evidence" in reup_tables
        assert "incident_history" in reup_tables

        engine.dispose()


class TestIncidentMigrationPostgreSQL:
    """Test 0006_incidents_and_evidence against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_incidents_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade through 0005
        command.upgrade(alembic_cfg, "0005_fim_baselines_deviations")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        # 2. Upgrade to 0006
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "incidents" in tables
        assert "incident_events" in tables
        assert "incident_evidence" in tables
        assert "incident_history" in tables

        # Downgrade back to 0005
        command.downgrade(alembic_cfg, "0005_fim_baselines_deviations")
        assert _get_current_revision(engine) == "0005_fim_baselines_deviations"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "incidents" not in down_tables
        assert "incident_events" not in down_tables
        assert "incident_evidence" not in down_tables
        assert "incident_history" not in down_tables

        # Re-upgrade to 0006
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        engine.dispose()


class TestWorkspaceMigrationSQLite:
    """Test 0007_workspaces_and_annotations against an isolated temporary SQLite database."""

    def test_upgrade_and_downgrade_workspaces_sqlite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_file = tmp_path / "test_mig_0007.db"
        sqlite_url = f"sqlite:///{db_file}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", sqlite_url)
        monkeypatch.setattr(settings, "database_url", sqlite_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", sqlite_url)

        # 1. Upgrade through 0006
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        engine = sa.create_engine(sqlite_url)
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        # 2. Upgrade to 0007_workspaces_and_annotations
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        # 3. Verify tables exist
        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "workspaces" in tables
        assert "evidence_tags" in tables
        assert "evidence_tag_associations" in tables
        assert "evidence_annotations" in tables

        # 4. Insert records across all 4 tables
        now = _utcnow()
        host_id = uuid.uuid4()
        user_id = uuid.uuid4()
        incident_id = uuid.uuid4()
        workspace_id = uuid.uuid4()
        tag_id = uuid.uuid4()
        assoc_id = uuid.uuid4()
        annotation_id = uuid.uuid4()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id,
                    hostname="test-ws-host",
                    created_at=now,
                )
            )
            conn.execute(
                _incidents_table.insert().values(
                    id=incident_id,
                    title="Investigation Incident",
                    description="Incident for workspace testing",
                    severity="high",
                    status="open",
                    category="malware",
                    host_id=host_id,
                    created_by_id=None,
                    assigned_to_id=None,
                    first_observed_at=now,
                    last_observed_at=now,
                    contained_at=None,
                    containment_summary=None,
                    resolved_at=None,
                    resolution_summary=None,
                    closed_at=None,
                    closure_summary=None,
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _workspaces_table.insert().values(
                    id=workspace_id,
                    name="Forensic Analysis Workspace",
                    description="Workspace for host intrusion investigation",
                    owner_id=None,
                    host_id=host_id,
                    incident_id=incident_id,
                    status="active",
                    configuration={
                        "active_panels": ["overview", "graph", "timeline"],
                        "layout_preferences": {"sidebar_open": True},
                        "selected_entities": [],
                        "pinned_evidence": [],
                    },
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _evidence_tags_table.insert().values(
                    id=tag_id,
                    name="threat-actor-apt",
                    description="Associated with APT threat group",
                    color="#e06c75",
                    category="threat_intel",
                    created_by_id=None,
                    created_at=now,
                )
            )
            conn.execute(
                _evidence_tag_associations_table.insert().values(
                    id=assoc_id,
                    tag_id=tag_id,
                    evidence_type="incident",
                    evidence_id=str(incident_id),
                    host_id=host_id,
                    created_by_id=None,
                    created_at=now,
                )
            )
            conn.execute(
                _evidence_annotations_table.insert().values(
                    id=annotation_id,
                    evidence_type="incident",
                    evidence_id=str(incident_id),
                    host_id=host_id,
                    workspace_id=workspace_id,
                    author_id=None,
                    annotation_text="Identified credential dumping indicator",
                    created_at=now,
                    updated_at=None,
                )
            )

        with engine.connect() as conn:
            ws_row = conn.execute(
                sa.select(_workspaces_table).where(_workspaces_table.c.id == workspace_id)
            ).one()
            assert ws_row.name == "Forensic Analysis Workspace"
            assert ws_row.status == "active"
            assert ws_row.configuration["active_panels"] == ["overview", "graph", "timeline"]

            tag_row = conn.execute(
                sa.select(_evidence_tags_table).where(_evidence_tags_table.c.id == tag_id)
            ).one()
            assert tag_row.name == "threat-actor-apt"
            assert tag_row.color == "#e06c75"

            assoc_row = conn.execute(
                sa.select(_evidence_tag_associations_table).where(_evidence_tag_associations_table.c.id == assoc_id)
            ).one()
            assert assoc_row.evidence_type == "incident"
            assert assoc_row.evidence_id == str(incident_id)

            annot_row = conn.execute(
                sa.select(_evidence_annotations_table).where(_evidence_annotations_table.c.id == annotation_id)
            ).one()
            assert annot_row.annotation_text == "Identified credential dumping indicator"

        # 5. Downgrade back to 0006_incidents_and_evidence
        command.downgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "workspaces" not in down_tables
        assert "evidence_tags" not in down_tables
        assert "evidence_tag_associations" not in down_tables
        assert "evidence_annotations" not in down_tables

        # 6. Re-upgrade to 0007_workspaces_and_annotations is idempotent
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        inspector = sa.inspect(engine)
        reup_tables = set(inspector.get_table_names())
        assert "workspaces" in reup_tables
        assert "evidence_tags" in reup_tables
        assert "evidence_tag_associations" in reup_tables
        assert "evidence_annotations" in reup_tables

        engine.dispose()


class TestWorkspaceMigrationPostgreSQL:
    """Test 0007_workspaces_and_annotations against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_workspaces_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade through 0006
        command.upgrade(alembic_cfg, "0006_incidents_and_evidence")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        # 2. Upgrade to 0007
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        inspector = sa.inspect(engine)
        tables = set(inspector.get_table_names())
        assert "workspaces" in tables
        assert "evidence_tags" in tables
        assert "evidence_tag_associations" in tables
        assert "evidence_annotations" in tables

        # Downgrade back to 0006
        command.downgrade(alembic_cfg, "0006_incidents_and_evidence")
        assert _get_current_revision(engine) == "0006_incidents_and_evidence"

        inspector = sa.inspect(engine)
        down_tables = set(inspector.get_table_names())
        assert "workspaces" not in down_tables
        assert "evidence_tags" not in down_tables
        assert "evidence_tag_associations" not in down_tables
        assert "evidence_annotations" not in down_tables

        # Re-upgrade to 0007
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        engine.dispose()


class TestOptimizationMigrationSQLite:
    """Test 0008_database_optimization against an isolated SQLite database."""

    def test_upgrade_downgrade_views_and_triggers_sqlite(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        db_file = tmp_path / "test_opt_mig.db"
        db_url = f"sqlite:///{db_file}"

        monkeypatch.setenv("OSIRIS_DATABASE_URL", db_url)
        monkeypatch.setattr(settings, "database_url", db_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", db_url)

        # 1. Upgrade through 0007
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        engine = sa.create_engine(db_url)
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        # 2. Upgrade to 0008_database_optimization
        command.upgrade(alembic_cfg, "0008_database_optimization")
        assert _get_current_revision(engine) == "0008_database_optimization"

        inspector = sa.inspect(engine)

        # Verify new indexes
        event_indexes = {idx["name"] for idx in inspector.get_indexes("events")}
        assert "ix_events_host_uid" in event_indexes
        assert "ix_events_host_pid" in event_indexes
        assert "ix_events_host_event_type_ts" in event_indexes

        proc_indexes = {idx["name"] for idx in inspector.get_indexes("processes")}
        assert "ix_processes_host_started" in proc_indexes
        assert "ix_processes_host_user" in proc_indexes
        assert "ix_processes_host_ended" in proc_indexes

        sess_indexes = {idx["name"] for idx in inspector.get_indexes("sessions")}
        assert "ix_sessions_host_user_started" in sess_indexes
        assert "ix_sessions_host_ended" in sess_indexes

        det_indexes = {idx["name"] for idx in inspector.get_indexes("detections")}
        assert "ix_detections_host_status_ts" in det_indexes

        inc_indexes = {idx["name"] for idx in inspector.get_indexes("incidents")}
        assert "ix_incidents_host_created" in inc_indexes
        assert "ix_incidents_host_status" in inc_indexes

        ev_indexes = {idx["name"] for idx in inspector.get_indexes("incident_evidence")}
        assert "ix_incident_evidence_session_id" in ev_indexes
        assert "ix_incident_evidence_snapshot_id" in ev_indexes
        assert "ix_incident_evidence_process_id" in ev_indexes
        assert "ix_incident_evidence_file_id" in ev_indexes
        assert "ix_incident_evidence_inc_type" in ev_indexes

        # Verify views exist in sqlite_master
        with engine.connect() as conn:
            views = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT name FROM sqlite_master WHERE type='view'")
                ).fetchall()
            ]
            assert "view_active_detections" in views
            assert "view_incident_summary" in views
            assert "view_fim_deviation_details" in views
            assert "view_process_lineage" in views
            assert "view_session_overview" in views

            triggers = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT name FROM sqlite_master WHERE type='trigger'")
                ).fetchall()
            ]
            assert "trg_hosts_updated_at" in triggers
            assert "trg_incidents_updated_at" in triggers
            assert "trg_incident_history_immutable" in triggers
            assert "trg_incident_history_no_delete" in triggers
            assert "trg_app_audit_log_immutable" in triggers
            assert "trg_app_audit_log_no_delete" in triggers

        # 3. Test View Querying and Correctness with inserted data
        host_id = uuid.uuid4()
        user_id = uuid.uuid4()
        parent_proc_id = uuid.uuid4()
        proc_id = uuid.uuid4()
        sess_id = uuid.uuid4()
        inc_id = uuid.uuid4()
        ev_id = uuid.uuid4()
        rule_db_id = uuid.uuid4()
        det_id = uuid.uuid4()
        base_id = uuid.uuid4()
        base_file_id = uuid.uuid4()
        dev_id = uuid.uuid4()
        now = _utcnow()

        with engine.begin() as conn:
            conn.execute(
                _hosts_table.insert().values(
                    id=host_id, hostname="forensic-srv01", created_at=now
                )
            )
            conn.execute(
                _linux_users_table.insert().values(
                    id=user_id, host_id=host_id, uid=1000, username="analyst", first_seen_at=now, created_at=now
                )
            )
            procs_tbl = sa.table(
                "processes",
                sa.column("id", sa.Uuid),
                sa.column("host_id", sa.Uuid),
                sa.column("pid", sa.Integer),
                sa.column("ppid", sa.Integer),
                sa.column("command", sa.String),
                sa.column("executable", sa.String),
                sa.column("linux_user_id", sa.Uuid),
                sa.column("started_at", sa.DateTime(timezone=True)),
                sa.column("created_at", sa.DateTime(timezone=True)),
            )
            conn.execute(
                procs_tbl.insert().values(
                    id=parent_proc_id,
                    host_id=host_id,
                    pid=1,
                    ppid=0,
                    command="/sbin/init",
                    executable="/sbin/init",
                    linux_user_id=None,
                    started_at=now - timedelta(hours=1),
                    created_at=now - timedelta(hours=1),
                )
            )
            conn.execute(
                procs_tbl.insert().values(
                    id=proc_id,
                    host_id=host_id,
                    pid=1234,
                    ppid=1,
                    command="/usr/bin/python3 suspicious.py",
                    executable="/usr/bin/python3",
                    linux_user_id=user_id,
                    started_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _sessions_table.insert().values(
                    id=sess_id,
                    host_id=host_id,
                    linux_user_id=user_id,
                    session_type="ssh",
                    terminal="pts/1",
                    remote_host="192.168.1.50",
                    started_at=now,
                    ended_at=None,
                    created_at=now,
                )
            )
            conn.execute(
                _incidents_table.insert().values(
                    id=inc_id,
                    title="Suspicious Privilege Escalation",
                    description="Unusual process execution",
                    severity="high",
                    status="investigating",
                    category="privilege_escalation",
                    host_id=host_id,
                    created_by_id=None,
                    assigned_to_id=None,
                    first_observed_at=now,
                    last_observed_at=now,
                    created_at=now,
                    updated_at=None,
                )
            )
            conn.execute(
                _incident_evidence_table.insert().values(
                    id=ev_id,
                    incident_id=inc_id,
                    evidence_type="process",
                    source_id=str(proc_id),
                    title="Suspicious Process",
                    provenance={"cmd": "suspicious.py"},
                    process_id=proc_id,
                    created_at=now,
                )
            )
            conn.execute(
                _detection_rules_table.insert().values(
                    id=rule_db_id,
                    rule_id="RULE-SEC-001",
                    name="Privilege Escalation Rule",
                    description="Detects priv esc",
                    category="privilege_escalation",
                    severity="high",
                    enabled=True,
                    version=1,
                    rule_type="single_event",
                    conditions={"field": "action", "operator": "equals", "value": "escalate"},
                    created_at=now,
                )
            )
            conn.execute(
                _detections_table.insert().values(
                    id=det_id,
                    rule_id=rule_db_id,
                    rule_version=1,
                    host_id=host_id,
                    timestamp=now,
                    severity="high",
                    title="Detected escalation",
                    description="Alert description",
                    category="privilege_escalation",
                    status="open",
                    notification_status="pending",
                    matched_conditions={},
                    evidence={},
                    dedup_hash="hash-1234567890",
                    created_at=now,
                )
            )
            conn.execute(
                _fim_baselines_table.insert().values(
                    id=base_id,
                    host_id=host_id,
                    version=1,
                    status="completed",
                    path_scope=["/etc"],
                    total_files=10,
                    total_bytes=2048,
                    baseline_at=now,
                    created_at=now,
                )
            )
            conn.execute(
                _fim_baseline_files_table.insert().values(
                    id=base_file_id,
                    baseline_id=base_id,
                    host_id=host_id,
                    file_path="/etc/shadow",
                    file_name="shadow",
                    file_type="file",
                    hash_sha256="sha256_shadow_golden",
                    permissions="0640",
                    file_size=1024,
                    created_at=now,
                )
            )
            conn.execute(
                _fim_deviations_table.insert().values(
                    id=dev_id,
                    host_id=host_id,
                    baseline_id=base_id,
                    baseline_file_id=base_file_id,
                    file_path="/etc/shadow",
                    deviation_type="modified_file",
                    severity="critical",
                    detected_at=now,
                    created_at=now,
                )
            )

        with engine.connect() as conn:
            # Query view_incident_summary
            inc_summary = conn.execute(
                sa.text("SELECT incident_id, title, status, hostname, evidence_count FROM view_incident_summary WHERE incident_id = :id OR incident_id = :id_hex"),
                {"id": str(inc_id), "id_hex": inc_id.hex},
            ).one()
            assert inc_summary.title == "Suspicious Privilege Escalation"
            assert inc_summary.status == "investigating"
            assert inc_summary.hostname == "forensic-srv01"
            assert inc_summary.evidence_count == 1

            # Query view_active_detections
            act_det = conn.execute(
                sa.text("SELECT detection_id, rule_identifier, rule_name, hostname FROM view_active_detections WHERE detection_id = :id OR detection_id = :id_hex"),
                {"id": str(det_id), "id_hex": det_id.hex},
            ).one()
            assert act_det.rule_identifier == "RULE-SEC-001"
            assert act_det.rule_name == "Privilege Escalation Rule"
            assert act_det.hostname == "forensic-srv01"

            # Query view_fim_deviation_details
            fim_dev = conn.execute(
                sa.text("SELECT deviation_id, file_path, baseline_version, hostname, expected_hash_sha256 FROM view_fim_deviation_details WHERE deviation_id = :id OR deviation_id = :id_hex"),
                {"id": str(dev_id), "id_hex": dev_id.hex},
            ).one()
            assert fim_dev.file_path == "/etc/shadow"
            assert fim_dev.baseline_version == 1
            assert fim_dev.hostname == "forensic-srv01"
            assert fim_dev.expected_hash_sha256 == "sha256_shadow_golden"

            # Query view_process_lineage
            proc_lin = conn.execute(
                sa.text("SELECT process_id, command, uid, username, hostname, parent_command FROM view_process_lineage WHERE process_id = :id OR process_id = :id_hex"),
                {"id": str(proc_id), "id_hex": proc_id.hex},
            ).one()
            assert proc_lin.command == "/usr/bin/python3 suspicious.py"
            assert proc_lin.uid == 1000
            assert proc_lin.username == "analyst"
            assert proc_lin.parent_command == "/sbin/init"

            # Query view_session_overview
            sess_ov = conn.execute(
                sa.text("SELECT session_id, session_type, username, hostname FROM view_session_overview WHERE session_id = :id OR session_id = :id_hex"),
                {"id": str(sess_id), "id_hex": sess_id.hex},
            ).one()
            assert sess_ov.session_type == "ssh"
            assert sess_ov.username == "analyst"

        # 4. Test Trigger Behavior
        with engine.begin() as conn:
            # Positive trigger: updating incident title automatically sets updated_at
            conn.execute(
                sa.text("UPDATE incidents SET title = 'Escalation Confirmed' WHERE id = :id OR id = :id_hex"),
                {"id": str(inc_id), "id_hex": inc_id.hex},
            )
        with engine.connect() as conn:
            updated_at = conn.execute(
                sa.text("SELECT updated_at FROM incidents WHERE id = :id OR id = :id_hex"),
                {"id": str(inc_id), "id_hex": inc_id.hex},
            ).scalar()
            assert updated_at is not None

        # Negative trigger: updating incident_history must be aborted
        hist_id = uuid.uuid4()
        with engine.begin() as conn:
            conn.execute(
                _incident_history_table.insert().values(
                    id=hist_id,
                    incident_id=inc_id,
                    change_type="status_change",
                    from_status="open",
                    to_status="investigating",
                    user_id=None,
                    notes="Analyst started investigation",
                    created_at=now,
                )
            )

        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(
                    sa.text("UPDATE incident_history SET notes = 'Tampered note' WHERE id = :id OR id = :id_hex"),
                    {"id": str(hist_id), "id_hex": hist_id.hex},
                )

        # Negative trigger: deleting incident_history must be aborted
        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(
                    sa.text("DELETE FROM incident_history WHERE id = :id OR id = :id_hex"),
                    {"id": str(hist_id), "id_hex": hist_id.hex},
                )

        # Negative trigger: updating & deleting app_audit_log must be aborted
        audit_id = uuid.uuid4()
        with engine.begin() as conn:
            conn.execute(
                sa.table(
                    "app_audit_log",
                    sa.column("id", sa.Uuid),
                    sa.column("action", sa.String),
                    sa.column("created_at", sa.DateTime(timezone=True)),
                ).insert().values(
                    id=audit_id,
                    action="user.login",
                    created_at=now,
                )
            )

        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(
                    sa.text("UPDATE app_audit_log SET action = 'tampered' WHERE id = :id OR id = :id_hex"),
                    {"id": str(audit_id), "id_hex": audit_id.hex},
                )

        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(
                    sa.text("DELETE FROM app_audit_log WHERE id = :id OR id = :id_hex"),
                    {"id": str(audit_id), "id_hex": audit_id.hex},
                )

        # 5. Downgrade to 0007_workspaces_and_annotations
        command.downgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        with engine.connect() as conn:
            down_views = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT name FROM sqlite_master WHERE type='view'")
                ).fetchall()
            ]
            assert "view_active_detections" not in down_views
            assert "view_incident_summary" not in down_views

            down_triggers = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT name FROM sqlite_master WHERE type='trigger'")
                ).fetchall()
            ]
            assert "trg_incidents_updated_at" not in down_triggers
            assert "trg_incident_history_immutable" not in down_triggers
            assert "trg_incident_history_no_delete" not in down_triggers
            assert "trg_app_audit_log_no_delete" not in down_triggers

        # 6. Re-upgrade to 0008_database_optimization is idempotent
        command.upgrade(alembic_cfg, "0008_database_optimization")
        assert _get_current_revision(engine) == "0008_database_optimization"

        with engine.connect() as conn:
            reup_views = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT name FROM sqlite_master WHERE type='view'")
                ).fetchall()
            ]
            assert "view_incident_summary" in reup_views

        engine.dispose()


class TestOptimizationMigrationPostgreSQL:
    """Test 0008_database_optimization against an isolated disposable PostgreSQL database."""

    def test_upgrade_and_downgrade_optimization_postgres(
        self, disposable_pg_url: str, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("OSIRIS_DATABASE_URL", disposable_pg_url)
        monkeypatch.setattr(settings, "database_url", disposable_pg_url)

        alembic_cfg = Config("alembic.ini")
        alembic_cfg.set_main_option("sqlalchemy.url", disposable_pg_url)

        # 1. Upgrade through 0007
        command.upgrade(alembic_cfg, "0007_workspaces_and_annotations")
        engine = sa.create_engine(disposable_pg_url)
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        # 2. Upgrade to 0008
        command.upgrade(alembic_cfg, "0008_database_optimization")
        assert _get_current_revision(engine) == "0008_database_optimization"

        # Verify views and triggers in PostgreSQL
        with engine.connect() as conn:
            views = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT table_name FROM information_schema.views WHERE table_schema='public'")
                ).fetchall()
            ]
            assert "view_active_detections" in views
            assert "view_incident_summary" in views
            assert "view_fim_deviation_details" in views
            assert "view_process_lineage" in views
            assert "view_session_overview" in views

            triggers = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT trigger_name FROM information_schema.triggers WHERE trigger_schema='public'")
                ).fetchall()
            ]
            assert "trg_incidents_updated_at" in triggers
            assert "trg_hosts_updated_at" in triggers
            assert "trg_incident_history_immutable" in triggers

        # Verify PostgreSQL immutability trigger blocks update and delete
        inc_id = uuid.uuid4()
        hist_id = uuid.uuid4()
        now = _utcnow()
        with engine.begin() as conn:
            conn.execute(_hosts_table.insert().values(id=uuid.uuid4(), hostname="pg-immut-host", created_at=now))
            conn.execute(_incidents_table.insert().values(
                id=inc_id, title="PG Incident", severity="low", status="open", category="general", created_at=now
            ))
            conn.execute(_incident_history_table.insert().values(
                id=hist_id, incident_id=inc_id, change_type="created", notes="Initial entry", created_at=now
            ))

        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(sa.text("UPDATE incident_history SET notes = 'tampered' WHERE id = :id"), {"id": hist_id})

        with pytest.raises(Exception):
            with engine.begin() as conn:
                conn.execute(sa.text("DELETE FROM incident_history WHERE id = :id"), {"id": hist_id})

        # Downgrade back to 0007
        command.downgrade(alembic_cfg, "0007_workspaces_and_annotations")
        assert _get_current_revision(engine) == "0007_workspaces_and_annotations"

        with engine.connect() as conn:
            down_views = [
                row[0]
                for row in conn.execute(
                    sa.text("SELECT table_name FROM information_schema.views WHERE table_schema='public'")
                ).fetchall()
            ]
            assert "view_active_detections" not in down_views

        # Re-upgrade to 0008
        command.upgrade(alembic_cfg, "0008_database_optimization")
        assert _get_current_revision(engine) == "0008_database_optimization"

        engine.dispose()
