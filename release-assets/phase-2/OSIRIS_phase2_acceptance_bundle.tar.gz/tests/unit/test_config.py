"""Unit tests for OSIRIS secret-key configuration and fail-fast validation.

Tests:
- Production mode (debug=False) rejects missing, empty, and known placeholder secrets.
- Production mode accepts valid strong secrets and secrets with substring keywords.
- Development mode (debug=True) permits intentional development placeholders.
- Validation errors never disclose secret values in messages or representations.
- Instantiation with validate_on_init=True enforces validation on construction.
- Application startup (lifespan) fails fast before serving traffic in misconfigured
  production environments.
- Importing modules and creating settings without validation does not break test
  collection or unrelated utilities.
"""

from __future__ import annotations

import pytest
from starlette.testclient import TestClient

from backend.api.security import create_access_token, decode_access_token
from backend.config import (
    KNOWN_INSECURE_SECRETS,
    ConfigurationError,
    Settings,
    settings,
    validate_secret_key,
)
from backend.main import app


class TestSecretKeyValidation:
    """Tests for Settings.validate_secret_key fail-fast logic."""

    def test_non_string_secret_key_rejected(self) -> None:
        cfg = Settings(debug=False)
        object.__setattr__(cfg, "secret_key", 12345)
        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            cfg.validate_secret_key()

    def test_production_missing_secret_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key=None)
        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            cfg.validate_secret_key()

    def test_production_empty_secret_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key="")
        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            cfg.validate_secret_key()

    def test_production_whitespace_secret_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key="   \t\n  ")
        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            cfg.validate_secret_key()

    def test_production_change_me_default_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key="CHANGE-ME-IN-PRODUCTION")
        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            cfg.validate_secret_key()

    def test_production_change_me_case_insensitive_and_whitespace_rejected(
        self,
    ) -> None:
        for placeholder in [
            "  change-me-in-production  ",
            "Change-Me-In-Production",
            "CHANGE-ME-IN-PRODUCTION\n",
        ]:
            cfg = Settings(debug=False, secret_key=placeholder)
            with pytest.raises(
                ConfigurationError, match="Insecure or placeholder secret_key"
            ):
                cfg.validate_secret_key()

    def test_production_dev_only_placeholder_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key="dev-only-not-for-production")
        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            cfg.validate_secret_key()

    def test_production_changeme_placeholder_rejected(self) -> None:
        cfg = Settings(debug=False, secret_key="changeme")
        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            cfg.validate_secret_key()

    @pytest.mark.parametrize("placeholder", sorted(KNOWN_INSECURE_SECRETS))
    def test_production_all_known_insecure_placeholders_rejected(
        self, placeholder: str
    ) -> None:
        cfg = Settings(debug=False, secret_key=placeholder)
        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            cfg.validate_secret_key()

    def test_production_valid_configured_secret_accepted(self) -> None:
        valid_secrets = [
            "a-very-strong-production-signing-secret-key-9999",
            "9f8a3c2b1e0d4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9",
            "dGVzdC1zZWNyZXQta2V5LXZhbGlkLXByb2R1Y3Rpb24tb3Npcmlz",
            "!@#$%^&*()_+~|}{[]:;?><,./-complex-passphrase",
        ]
        for sec in valid_secrets:
            cfg = Settings(debug=False, secret_key=sec)
            cfg.validate_secret_key()  # Must not raise

    def test_production_legitimate_secret_with_keyword_substring_accepted(
        self,
    ) -> None:
        """Secrets containing substrings like 'secret' must not be rejected."""
        legit_secrets = [
            "my_super_secret_jwt_signing_key_production_environment_ready",
            "secure_password_salt_derived_application_token_secret_12345",
            "enterprise_default_zone_alpha_incident_response_system_key",
        ]
        for sec in legit_secrets:
            cfg = Settings(debug=False, secret_key=sec)
            cfg.validate_secret_key()  # Must not raise

    def test_development_mode_allows_known_placeholders(self) -> None:
        for placeholder in [
            "CHANGE-ME-IN-PRODUCTION",
            "dev-only-not-for-production",
            "changeme",
            "secret",
        ]:
            cfg = Settings(debug=True, secret_key=placeholder)
            cfg.validate_secret_key()  # Must not raise in dev mode

    def test_development_mode_allows_custom_secret(self) -> None:
        cfg = Settings(debug=True, secret_key="local-dev-key")
        cfg.validate_secret_key()  # Must not raise in dev mode

    def test_development_mode_rejects_missing_or_empty_secret(self) -> None:
        for empty_val in [None, "", "   \t  "]:
            cfg = Settings(debug=True, secret_key=empty_val)
            with pytest.raises(
                ConfigurationError, match="OSIRIS secret_key is not configured"
            ):
                cfg.validate_secret_key()

    def test_error_message_does_not_disclose_secret_content(self) -> None:
        canary_secrets = [
            "CHANGE-ME-IN-PRODUCTION",
            "dev-only-not-for-production",
            "changeme",
            "password123",
            "admin",
        ]
        for sec in canary_secrets:
            cfg = Settings(debug=False, secret_key=sec)
            with pytest.raises(ConfigurationError) as exc_info:
                cfg.validate_secret_key()
            err_msg = str(exc_info.value)
            err_repr = repr(exc_info.value)
            assert sec not in err_msg
            assert sec.lower() not in err_msg.lower()
            assert sec not in err_repr

    def test_validate_on_init_option(self) -> None:
        with pytest.raises(ConfigurationError):
            Settings(
                debug=False,
                secret_key="CHANGE-ME-IN-PRODUCTION",
                validate_on_init=True,
            )

        # Valid secret on init succeeds
        cfg = Settings(
            debug=False,
            secret_key="valid-prod-secret-key-12345",
            validate_on_init=True,
        )
        assert cfg.secret_key == "valid-prod-secret-key-12345"

    def test_validate_secret_key_helper_function(self) -> None:
        valid_cfg = Settings(debug=False, secret_key="valid-key-999")
        validate_secret_key(valid_cfg)

        invalid_cfg = Settings(debug=False, secret_key="changeme")
        with pytest.raises(ConfigurationError):
            validate_secret_key(invalid_cfg)


class TestApplicationStartupSecretKey:
    """Tests for application startup fail-fast behavior in FastAPI lifespan."""

    def test_app_startup_fails_in_production_with_placeholder_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "CHANGE-ME-IN-PRODUCTION")

        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            with TestClient(app):
                pass

    def test_app_startup_fails_in_production_with_dev_placeholder(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "dev-only-not-for-production")

        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            with TestClient(app):
                pass

    def test_app_startup_fails_in_production_with_empty_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "")

        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            with TestClient(app):
                pass

    def test_app_startup_fails_in_production_with_missing_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", None)

        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            with TestClient(app):
                pass

    def test_app_middleware_blocks_traffic_even_when_lifespan_is_bypassed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When an ASGI caller invokes app without lifespan, middleware blocks."""
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "CHANGE-ME-IN-PRODUCTION")

        client = TestClient(app, raise_server_exceptions=True)
        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            client.get("/health")

        # Caught server exceptions yield HTTP 500, never serving 200 traffic
        safe_client = TestClient(app, raise_server_exceptions=False)
        resp = safe_client.get("/health")
        assert resp.status_code == 500

    def test_app_middleware_blocks_missing_secret_when_lifespan_bypassed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", None)

        client = TestClient(app, raise_server_exceptions=True)
        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            client.get("/health")

    def test_app_startup_succeeds_in_production_with_valid_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "production-cryptographically-secure-key-99"
        )
        monkeypatch.setattr(
            settings,
            "database_url",
            "postgresql://osiris_acceptance_app:strong_crypto_pass_999@localhost:5432/osiris_acceptance_phase2",
        )

        with TestClient(app) as client:
            resp = client.get("/health")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok", "system": "osiris"}

    def test_app_startup_fails_in_production_with_unconfigured_database_url(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "production-cryptographically-secure-key-99"
        )
        monkeypatch.setattr(settings, "database_url", None)

        with pytest.raises(
            ConfigurationError, match="OSIRIS database_url is not configured"
        ):
            with TestClient(app):
                pass

    def test_app_startup_fails_in_production_with_default_osiris_credentials(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "production-cryptographically-secure-key-99"
        )
        monkeypatch.setattr(
            settings,
            "database_url",
            "postgresql://osiris:osiris@localhost:5432/my_custom_db",
        )

        with pytest.raises(
            ConfigurationError, match="Default database credentials"
        ):
            with TestClient(app):
                pass

    def test_app_startup_fails_in_production_with_protected_database(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "production-cryptographically-secure-key-99"
        )
        monkeypatch.setattr(
            settings,
            "database_url",
            "postgresql://osiris_app:strong_crypto_pass_999@localhost:5432/osiris",
        )

        with pytest.raises(
            ConfigurationError, match="protected database"
        ):
            with TestClient(app):
                pass

    def test_app_middleware_blocks_invalid_database_url_when_lifespan_bypassed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "production-cryptographically-secure-key-99"
        )
        monkeypatch.setattr(
            settings,
            "database_url",
            "postgresql://osiris:osiris@localhost:5432/my_custom_db",
        )

        client = TestClient(app, raise_server_exceptions=True)
        with pytest.raises(
            ConfigurationError, match="Default database credentials"
        ):
            client.get("/health")

    def test_app_startup_succeeds_in_dev_with_placeholder(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", True)
        monkeypatch.setattr(settings, "secret_key", "dev-only-not-for-production")

        with TestClient(app) as client:
            resp = client.get("/health")
            assert resp.status_code == 200
            assert resp.json() == {"status": "ok", "system": "osiris"}

    def test_app_startup_failure_discloses_no_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        canary = "CHANGE-ME-IN-PRODUCTION"
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", canary)

        with pytest.raises(ConfigurationError) as exc_info:
            with TestClient(app):
                pass
        assert canary not in str(exc_info.value)


class TestTokenSecurityFailFast:
    """Tests ensuring token signing and decoding fail fast with insecure config."""

    def test_token_creation_fails_fast_in_production_with_placeholder(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "CHANGE-ME-IN-PRODUCTION")

        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            create_access_token(user_id="user-123", username="alice")

    def test_token_creation_fails_fast_in_production_with_missing_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", None)

        with pytest.raises(
            ConfigurationError, match="OSIRIS secret_key is not configured"
        ):
            create_access_token(user_id="user-123", username="alice")

    def test_token_decoding_fails_fast_in_production_with_placeholder(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        token = create_access_token(
            user_id="user-123",
            username="alice",
            secret_key="explicit-temp-key-for-test",
        )
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "dev-only-not-for-production")

        with pytest.raises(
            ConfigurationError, match="Insecure or placeholder secret_key"
        ):
            decode_access_token(token)

    def test_token_creation_succeeds_in_dev_with_placeholder(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", True)
        monkeypatch.setattr(settings, "secret_key", "dev-only-not-for-production")

        token = create_access_token(user_id="user-123", username="alice")
        assert isinstance(token, str)

    def test_token_creation_succeeds_in_prod_with_strong_secret(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(
            settings, "secret_key", "cryptographically-strong-production-signing-key-99"
        )

        token = create_access_token(user_id="user-123", username="alice")
        assert isinstance(token, str)
        payload = decode_access_token(token)
        assert payload["username"] == "alice"


class TestImportAndUtilitySafety:
    """Tests ensuring settings instantiation and imports do not cause side effects."""

    def test_instantiating_settings_without_validation_does_not_raise(
        self,
    ) -> None:
        """Utilities instantiating Settings directly should not crash."""
        cfg = Settings(debug=False, secret_key="CHANGE-ME-IN-PRODUCTION")
        assert cfg.debug is False
        assert cfg.secret_key == "CHANGE-ME-IN-PRODUCTION"

    def test_import_main_does_not_trigger_lifespan(self) -> None:
        """Module import must not run lifespan or crash test collection."""
        import backend.main

        assert backend.main.app is not None


class TestDatabaseUrlConfiguration:
    """Tests for OSIRIS database and test-only database URL configuration."""

    def test_default_test_database_url_is_none(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """test_database_url defaults to None when unconfigured."""
        monkeypatch.delenv("OSIRIS_TEST_DATABASE_URL", raising=False)
        cfg = Settings(_env_file=None)
        assert cfg.test_database_url is None

    def test_test_database_url_loaded_from_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """OSIRIS_TEST_DATABASE_URL populates test_database_url setting."""
        test_url = "postgresql://test_role:test_pass@localhost:5432/postgres"
        monkeypatch.setenv("OSIRIS_TEST_DATABASE_URL", test_url)
        cfg = Settings(_env_file=None)
        assert cfg.test_database_url == test_url

    def test_test_database_url_preserves_unprivileged_app_database_url(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Configuring OSIRIS_TEST_DATABASE_URL preserves normal database_url."""
        app_url = "postgresql://osiris:osiris@localhost:5432/osiris"
        test_url = "postgresql://test_role:test_pass@localhost:5432/postgres"
        monkeypatch.setenv("OSIRIS_DATABASE_URL", app_url)
        monkeypatch.setenv("OSIRIS_TEST_DATABASE_URL", test_url)
        cfg = Settings(_env_file=None)
        assert cfg.database_url == app_url
        assert cfg.test_database_url == test_url


class TestCorsConfiguration:
    """Tests for CORS origin parsing and production validation."""

    def test_default_dev_cors_origins(self) -> None:
        cfg = Settings(_env_file=None)
        origins = cfg.get_cors_origins()
        assert "http://localhost:8000" in origins
        assert "http://127.0.0.1:8000" in origins
        assert "*" not in origins

    def test_cors_origins_parsed_from_comma_string(self) -> None:
        cfg = Settings(
            cors_allowed_origins="http://example.com, https://app.osiris.internal ",
            _env_file=None,
        )
        origins = cfg.get_cors_origins()
        assert origins == ["http://example.com", "https://app.osiris.internal"]

    def test_production_mode_rejects_wildcard_cors(self) -> None:
        cfg = Settings(
            debug=False,
            secret_key="valid-crypto-key-for-prod-testing",
            cors_allowed_origins=["*"],
            _env_file=None,
        )
        with pytest.raises(ConfigurationError, match="Wildcard CORS origin"):
            cfg.validate_cors_configuration()

    def test_production_mode_rejects_wildcard_in_comma_separated_origins(
        self,
    ) -> None:
        cfg = Settings(
            debug=False,
            secret_key="valid-crypto-key-for-prod-testing",
            cors_allowed_origins="https://app.osiris.io, *",
            _env_file=None,
        )
        with pytest.raises(ConfigurationError, match="Wildcard CORS origin"):
            cfg.validate_cors_configuration()

    def test_production_mode_allows_explicit_origins(self) -> None:
        cfg = Settings(
            debug=False,
            secret_key="valid-crypto-key-for-prod-testing",
            cors_allowed_origins=["https://osiris.enterprise.internal"],
            _env_file=None,
        )
        cfg.validate_cors_configuration()  # Must not raise

    def test_development_mode_allows_wildcard(self) -> None:
        cfg = Settings(
            debug=True,
            cors_allowed_origins=["*"],
            _env_file=None,
        )
        cfg.validate_cors_configuration()  # Allowed in dev mode

    def test_app_startup_fails_in_production_with_wildcard_cors(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(settings, "debug", False)
        monkeypatch.setattr(settings, "secret_key", "valid-crypto-key-for-prod-testing")
        monkeypatch.setattr(settings, "cors_allowed_origins", ["*"])

        with pytest.raises(ConfigurationError, match="Wildcard CORS origin"):
            with TestClient(app):
                pass


class TestDeploymentDatabaseValidation:
    """Tests ensuring database_url fails closed against default and protected targets."""

    def test_default_database_url_is_none_no_default_fallback(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """database_url must default to None and never silently fall back to 'osiris'."""
        monkeypatch.delenv("OSIRIS_DATABASE_URL", raising=False)
        cfg = Settings(_env_file=None)
        assert cfg.database_url is None

    def test_validate_database_url_requires_explicit_in_production(self) -> None:
        """In production mode or when explicit, unconfigured URL raises ConfigurationError."""
        cfg = Settings(debug=False, _env_file=None)
        with pytest.raises(ConfigurationError, match="OSIRIS database_url is not configured"):
            cfg.validate_database_url(require_explicit=True)

    def test_validate_database_url_rejects_default_osiris_credentials(self) -> None:
        """Default 'osiris:osiris' credentials must be rejected in deployment."""
        cfg = Settings(
            database_url="postgresql://osiris:osiris@localhost:5432/my_custom_db",
            debug=False,
            _env_file=None,
        )
        with pytest.raises(ConfigurationError, match="Default database credentials"):
            cfg.validate_database_url()

    def test_validate_database_url_rejects_insecure_passwords(self) -> None:
        """Insecure or placeholder passwords must be rejected in deployment."""
        for bad_pass in ["password", "123456", "secret", "change-me", "changeme", "admin"]:
            cfg = Settings(
                database_url=f"postgresql://app_user:{bad_pass}@localhost:5432/my_db",
                debug=False,
                _env_file=None,
            )
            with pytest.raises(ConfigurationError, match="Insecure or placeholder database password"):
                cfg.validate_database_url()

    def test_validate_database_url_rejects_protected_databases(self) -> None:
        """Protected databases (osiris, review, demo, validation) must be rejected."""
        protected = [
            "osiris",
            "osiris_phase2_review",
            "osiris_phase2_demo",
            "osiris_dev",
            "osiris_desktop_dev",
            "osiris_l1_validation_d4daacd",
            "postgres",
            "template1",
            "acceptance_validation_db",
        ]
        for db in protected:
            cfg = Settings(
                database_url=f"postgresql://app_user:strong_crypto_pass_999@localhost:5432/{db}",
                debug=False,
                _env_file=None,
            )
            with pytest.raises(ConfigurationError, match="protected database"):
                cfg.validate_database_url()

    def test_validate_database_url_accepts_valid_deployment_database(self) -> None:
        """Valid dedicated database and strong credentials must be accepted."""
        cfg = Settings(
            database_url="postgresql://osiris_acceptance_app:strong_crypto_pass_999@localhost:5432/osiris_acceptance_phase2",
            debug=False,
            _env_file=None,
        )
        cfg.validate_database_url()  # Must not raise

    def test_validate_database_url_requires_explicit_in_production_without_argument(self) -> None:
        """In production mode, validate_database_url() without args must fail closed on None."""
        cfg = Settings(debug=False, _env_file=None)
        with pytest.raises(ConfigurationError, match="OSIRIS database_url is not configured"):
            cfg.validate_database_url()

    def test_validate_database_url_rejects_missing_database_name(self) -> None:
        """Database URL with empty database name must be rejected."""
        cfg = Settings(
            database_url="postgresql://user:validpass123456@localhost:5432/",
            debug=False,
            _env_file=None,
        )
        with pytest.raises(ConfigurationError, match="specify a target database name"):
            cfg.validate_database_url()

    def test_sanitize_url_handles_various_url_formats(self) -> None:
        """sanitize_url should mask passwords without corrupting URLs missing passwords."""
        from backend.config import sanitize_url

        assert sanitize_url("postgresql://app_user:secret123@localhost:5432/mydb") == (
            "postgresql://app_user:***@localhost:5432/mydb"
        )
        assert sanitize_url("postgresql://app_user@localhost:5432/mydb") == (
            "postgresql://app_user@localhost:5432/mydb"
        )
        assert sanitize_url("postgresql://localhost:5432/mydb") == (
            "postgresql://localhost:5432/mydb"
        )
        assert sanitize_url("sqlite:///:memory:") == "sqlite:///:memory:"

    def test_database_url_error_message_never_discloses_password(self) -> None:
        """Sanitized error messages must mask passwords and never leak secrets."""
        canary = "SuperSecretCanaryPassword999"
        cfg = Settings(
            database_url=f"postgresql://app_user:{canary}@localhost:5432/osiris",
            debug=False,
            _env_file=None,
        )
        with pytest.raises(ConfigurationError) as exc_info:
            cfg.validate_database_url()
        assert canary not in str(exc_info.value)
        assert "***" in str(exc_info.value)


class TestDeploymentPreflightValidatorScript:
    """Tests for scripts/validate_deployment_env.py preflight validator."""

    def test_preflight_passes_with_valid_env_file(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_HOST_ID=ubuntu-test-host\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is True
        assert len(errors) == 0

    def test_preflight_fails_when_file_missing(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        missing_path = tmp_path / "nonexistent.env"
        is_valid, errors = validate_deployment_environment(
            env_file_path=missing_path, strict_ownership=False
        )
        assert is_valid is False
        assert any("does not exist" in e for e in errors)

    def test_preflight_fails_when_symlink(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        real_file = tmp_path / "real.env"
        real_file.write_text("OSIRIS_DEBUG=false\n", encoding="utf-8")
        symlink_file = tmp_path / "symlink.env"
        symlink_file.symlink_to(real_file)

        is_valid, errors = validate_deployment_environment(
            env_file_path=symlink_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("symlink" in e for e in errors)

    def test_preflight_fails_with_insecure_world_permissions(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )
        env_file.chmod(0o666)  # World writable & readable

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("world permissions" in e for e in errors)

    def test_preflight_fails_when_debug_is_true(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=true\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("OSIRIS_DEBUG must be explicitly set to 'false'" in e for e in errors)

    def test_preflight_fails_with_placeholder_secret(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=CHANGE-ME-IN-PRODUCTION\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("secret template" in e or "insecure" in e for e in errors)

    def test_preflight_fails_with_protected_database(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        for protected_name in ["osiris", "osiris_phase2_review", "osiris_phase2_demo", "osiris_l1_validation_d4daacd"]:
            env_file = tmp_path / f".env_{protected_name}"
            env_file.write_text(
                "OSIRIS_DEBUG=false\n"
                "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
                f"OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/{protected_name}\n",
                encoding="utf-8",
            )
            env_file.chmod(0o600)

            is_valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=False
            )
            assert is_valid is False
            assert any("targets protected database" in e for e in errors)

    def test_preflight_fails_with_default_osiris_credentials(self, tmp_path: Path) -> None:
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris:osiris@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("default database credentials" in e for e in errors)

    def test_preflight_fails_when_env_file_missing_keys_despite_ambient_os_environ(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Mandatory keys missing from the .env file must NOT be masked by ambient os.environ."""
        from scripts.validate_deployment_env import validate_deployment_environment

        # Ambient shell environment contains valid values
        monkeypatch.setenv("OSIRIS_DEBUG", "false")
        monkeypatch.setenv(
            "OSIRIS_SECRET_KEY", "cryptographically-strong-secret-key-32chars-min"
        )
        monkeypatch.setenv(
            "OSIRIS_DATABASE_URL",
            "postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2",
        )

        # But the deployment .env file itself is empty
        empty_env = tmp_path / "empty.env"
        empty_env.write_text("# empty deployment file\n", encoding="utf-8")
        empty_env.chmod(0o600)

        is_valid, errors = validate_deployment_environment(
            env_file_path=empty_env, strict_ownership=False
        )
        assert is_valid is False
        assert any("OSIRIS_DEBUG is not defined" in e for e in errors)
        assert any("OSIRIS_SECRET_KEY is missing" in e for e in errors)
        assert any("OSIRIS_DATABASE_URL is missing" in e for e in errors)

    def test_preflight_fails_when_executable_bits_set(self, tmp_path: Path) -> None:
        """Executable permissions on the .env file must be strictly rejected."""
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )
        env_file.chmod(0o700)  # Executable!

        is_valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert is_valid is False
        assert any("execute permissions" in e for e in errors)

    def test_preflight_root_ownership_and_group_readability(
        self, tmp_path: Path
    ) -> None:
        """Root-owned .env must have group osiris and group-read bit set (0640)."""
        import stat
        from unittest.mock import MagicMock, patch
        from scripts.validate_deployment_env import validate_deployment_environment

        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )

        mock_pw = MagicMock(pw_uid=1001, pw_gid=1001)
        mock_grp = MagicMock(gr_gid=1001)

        # Case 1: Owned by root:root (gid 0), mode 0640 -> backend user osiris cannot read!
        stat_root_root = MagicMock(st_mode=stat.S_IFREG | 0o640, st_uid=0, st_gid=0)
        with patch("pwd.getpwnam", return_value=mock_pw), patch(
            "grp.getgrnam", return_value=mock_grp
        ), patch("os.lstat", return_value=stat_root_root), patch(
            "os.access", return_value=True
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is False
            assert any("must have group 'osiris'" in e for e in errors)

        # Case 2: Owned by root:osiris (gid 1001), but mode 0600 -> backend user osiris cannot read!
        stat_root_osiris_0600 = MagicMock(
            st_mode=stat.S_IFREG | 0o600, st_uid=0, st_gid=1001
        )
        with patch("pwd.getpwnam", return_value=mock_pw), patch(
            "grp.getgrnam", return_value=mock_grp
        ), patch("os.lstat", return_value=stat_root_osiris_0600), patch(
            "os.access", return_value=True
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is False
            assert any("must have group 'osiris'" in e for e in errors)

        # Case 3: Owned by root:osiris (gid 1001) with mode 0640 -> valid!
        stat_root_osiris_0640 = MagicMock(
            st_mode=stat.S_IFREG | 0o640, st_uid=0, st_gid=1001
        )
        with patch("pwd.getpwnam", return_value=mock_pw), patch(
            "grp.getgrnam", return_value=mock_grp
        ), patch("os.lstat", return_value=stat_root_osiris_0640), patch(
            "os.access", return_value=True
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is True
            assert len(errors) == 0

