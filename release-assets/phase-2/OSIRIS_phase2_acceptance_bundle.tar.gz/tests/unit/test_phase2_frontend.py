"""Unit test suite for OSIRIS Phase 2 Frontend and Web Controllers.

Verifies:
- All Phase 2 and core JavaScript files pass syntax checks.
- Security Invariants:
  - Zero localStorage usage.
  - Zero innerHTML usage.
  - Zero eval(), new Function(), or document.write.
  - Zero console.log calls.
  - Zero hardcoded passwords or bearer tokens.
- DOM and Semantic Shell Invariants:
  - Brand logo is inline SVG (not emoji).
  - Nav label for Reconstruct is Investigations.
  - view-timeline panel starts hidden.
  - Detection detail modal contains investigation pivot buttons.
- Real-time Runtime Execution Tests:
  - setAuthenticatedState executes without TypeError.
  - OsirisRouter.navigateTo functions properly.
  - OsirisProcessTree and OsirisApi methods execute.
"""

from __future__ import annotations

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
FRONTEND_DIR = PROJECT_ROOT / "frontend"
TEMPLATES_DIR = FRONTEND_DIR / "templates"
STATIC_DIR = FRONTEND_DIR / "static"
JS_DIR = STATIC_DIR / "js"
VIEWS_DIR = JS_DIR / "views"

ALL_JS_FILES = sorted(list(JS_DIR.glob("*.js")) + list(VIEWS_DIR.glob("*.js")))


class TestPhase2FrontendSecurity:
    """Validate strict security and formatting invariants across all JS controllers."""

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_localstorage(self, js_file: Path) -> None:
        """localStorage must NEVER be used; sessionStorage or Api getters only."""
        content = js_file.read_text(encoding="utf-8")
        assert "localStorage" not in content, (
            f"Forbidden localStorage in {js_file.name}"
        )

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_innerhtml(self, js_file: Path) -> None:
        """innerHTML must NEVER be used; textContent and createElement only."""
        content = js_file.read_text(encoding="utf-8")
        assert "innerHTML" not in content, f"Forbidden innerHTML in {js_file.name}"

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_eval_or_function_constructor(self, js_file: Path) -> None:
        """eval() and new Function() must NEVER be used."""
        content = js_file.read_text(encoding="utf-8")
        assert "eval(" not in content, f"Forbidden eval() in {js_file.name}"
        assert "new Function(" not in content, (
            f"Forbidden new Function() in {js_file.name}"
        )

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_document_write(self, js_file: Path) -> None:
        """document.write must NEVER be used."""
        content = js_file.read_text(encoding="utf-8")
        assert "document.write" not in content, (
            f"Forbidden document.write in {js_file.name}"
        )

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_console_logging(self, js_file: Path) -> None:
        """Zero console.log statements permitted."""
        content = js_file.read_text(encoding="utf-8")
        assert "console.log" not in content, f"Accidental console.log in {js_file.name}"

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_zero_hardcoded_secrets(self, js_file: Path) -> None:
        """No passwords, test credentials, or static JWTs."""
        content = js_file.read_text(encoding="utf-8").lower()
        forbidden = ["changeme", "password123", "bearer ey", "secret_key"]
        for pattern in forbidden:
            assert pattern not in content, (
                f"Forbidden secret '{pattern}' in {js_file.name}"
            )


class TestIndexHtmlDomContract:
    """Validate DOM structure and semantic shell invariants in index.html."""

    @pytest.fixture
    def index_html_content(self) -> str:
        index_file = TEMPLATES_DIR / "index.html"
        assert index_file.exists(), "index.html not found"
        return index_file.read_text(encoding="utf-8")

    def test_brand_logo_is_svg(self, index_html_content: str) -> None:
        """Brand logo must be SVG, not an emoji character."""
        assert "&#x1F6E1;" not in index_html_content
        assert '<svg class="brand-logo"' in index_html_content

    def test_reconstruct_nav_label(self, index_html_content: str) -> None:
        """The reconstruct workspace nav item must be labeled Investigations."""
        assert '<span class="nav-label">Investigations</span>' in index_html_content

    def test_timeline_hidden_by_default(self, index_html_content: str) -> None:
        """The timeline view panel must have the hidden class on initial load."""
        assert 'id="view-timeline" class="view-panel hidden"' in index_html_content

    def test_detection_pivot_buttons_present(self, index_html_content: str) -> None:
        """Detection modal must include pivot buttons to ptree, timeline, and ws."""
        assert 'id="detection-pivot-ptree-btn"' in index_html_content
        assert 'id="detection-pivot-timeline-btn"' in index_html_content
        assert 'id="detection-pivot-workspace-btn"' in index_html_content


class TestJavaScriptRuntimeExecution:
    """Verify script syntax and execution flows in the JavaScript engine."""

    @pytest.mark.parametrize(
        "js_file", ALL_JS_FILES, ids=[f.name for f in ALL_JS_FILES]
    )
    def test_javascript_syntax(self, js_file: Path) -> None:
        from tests.helpers.js_runtime import SKIP_REASON, find_js_runtime

        runtime = find_js_runtime()
        if runtime is None:
            pytest.skip(SKIP_REASON)

        result = runtime.check_syntax(js_file)
        assert result.returncode == 0, f"{js_file.name} syntax error:\n{result.stderr}"

    def test_login_flow_and_api_runtime_execution(self) -> None:
        """Test mock browser execution of login flow, ws handlers, and navigation."""
        from tests.helpers.js_runtime import SKIP_REASON, find_js_runtime

        runtime = find_js_runtime()
        if runtime is None:
            pytest.skip(SKIP_REASON)

        # Mock minimal browser environment
        harness = """
        var window = this;
        var document = {
          readyState: 'complete',
          addEventListener: function(evt, cb) {},
          getElementById: function(id) {
            return {
              classList: {
                add: function(){},
                remove: function(){},
                contains: function(){ return false; },
                toggle: function(){ return false; }
              },
              setAttribute: function(){},
              getAttribute: function(){ return ''; },
              addEventListener: function(){},
              textContent: '',
              disabled: false,
              value: '',
              style: {},
              reset: function() {}
            };
          },
          querySelector: function(sel) { return null; },
          querySelectorAll: function(sel) { return []; },
          createElement: function(tag) {
            return {
              classList: {
                add: function(){},
                remove: function(){},
                toggle: function(){ return false; }
              },
              appendChild: function(){},
              removeChild: function(){},
              firstChild: null,
              addEventListener: function(){},
              textContent: '',
              value: '',
              style: {},
              reset: function() {}
            };
          }
        };
        var sessionStorage = {
          getItem: function(k) { return null; },
          setItem: function(k, v) {},
          removeItem: function(k) {}
        };
        var location = { hash: '' };
        """

        # Read scripts
        api_code = (JS_DIR / "api.js").read_text(encoding="utf-8")
        ws_code = (JS_DIR / "ws.js").read_text(encoding="utf-8")
        router_code = (JS_DIR / "router.js").read_text(encoding="utf-8")
        ptree_code = (VIEWS_DIR / "process_tree.js").read_text(encoding="utf-8")
        app_code = (JS_DIR / "app.js").read_text(encoding="utf-8")

        test_code = """
        // 1. Verify OsirisWs exports
        if (typeof window.OsirisWs.onStatusChange !== 'function') {
          throw new Error('window.OsirisWs.onStatusChange missing');
        }
        if (typeof window.OsirisWs.onEvent !== 'function') {
          throw new Error('window.OsirisWs.onEvent missing');
        }

        // 2. Verify OsirisRouter exports
        if (typeof window.OsirisRouter.navigateTo !== 'function') {
          throw new Error('window.OsirisRouter.navigateTo missing');
        }

        // 3. Verify OsirisApi getters
        if (typeof window.OsirisApi.getProcesses !== 'function') {
          throw new Error('window.OsirisApi.getProcesses missing');
        }
        if (typeof window.OsirisApi.getActiveHostId !== 'function') {
          throw new Error('window.OsirisApi.getActiveHostId missing');
        }

        // 4. Verify setAuthenticatedState execution does not throw
        window.OsirisApp.setAuthenticatedState({
          id: '00000000-0000-0000-0000-000000000001',
          username: 'admin',
          role: 'admin',
          display_name: 'Administrator'
        });

        // 5. Verify setUnauthenticatedState execution does not throw
        window.OsirisApp.setUnauthenticatedState();

        print('JS_RUNTIME_SUCCESS');
        """

        scripts = [
            harness,
            api_code,
            ws_code,
            router_code,
            ptree_code,
            app_code,
            test_code,
        ]
        full_script = "\n".join(scripts)
        result = runtime.run_script(full_script)
        assert result.returncode == 0, (
            f"JS execution failed:\n{result.stderr}\n{result.stdout}"
        )
        assert "JS_RUNTIME_SUCCESS" in result.stdout
