"""Security and compatibility unit tests for Unix domain socket IPC."""

from __future__ import annotations

import asyncio
import json
import os
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from backend.services.events.ipc_broadcast import (
    DEFAULT_IPC_SOCK_NAME,
    DEFAULT_PG_CHANNEL,
    IPCRateLimiter,
    IPCServer,
    get_ipc_socket_path,
    get_private_dev_runtime_dir,
    is_peer_authorized,
    send_ipc_notification,
    validate_ipc_payload,
    verify_and_hydrate_heartbeat,
)


def get_short_test_sock() -> Path:
    """Return a short socket path (<104 chars) for macOS AF_UNIX compatibility."""
    return Path(f"/tmp/o_t_{uuid.uuid4().hex[:8]}.sock")


class TestSocketPermissionEnforcement:
    """Tests ensuring socket and runtime directory permission enforcement."""

    def test_socket_created_with_0660_permissions(self) -> None:
        """Socket file must have mode 0660 (no world-readable/world-writable bits)."""
        sock_file = get_short_test_sock()
        received = []

        async def dummy_handler(payload: dict) -> None:
            received.append(payload)

        async def _test() -> None:
            server = IPCServer(dummy_handler, socket_path=sock_file)
            await server.start()
            try:
                assert sock_file.exists()
                file_stat = sock_file.stat()
                file_mode = file_stat.st_mode & 0o777

                # Must be 0660 (or stricter 0600)
                assert file_mode in (0o660, 0o600)

                # Strictly verify NO world permissions (others bits must be 0)
                assert (file_mode & 0o007) == 0, (
                    f"Socket has world permissions: {oct(file_mode)}"
                )
                # Strictly verify NOT world-writable
                assert (file_mode & 0o002) == 0
                # Strictly verify NOT world-readable
                assert (file_mode & 0o004) == 0
            finally:
                await server.stop()
                sock_file.unlink(missing_ok=True)

        asyncio.run(_test())

    def test_private_dev_runtime_dir_mode_0700(self) -> None:
        """Private development directory must be restricted to mode 0700."""
        dev_dir = get_private_dev_runtime_dir()
        assert dev_dir.exists()
        dir_stat = dev_dir.stat()
        dir_mode = dir_stat.st_mode & 0o777
        assert dir_mode == 0o700, f"Dev directory mode is not 0700: {oct(dir_mode)}"

    def test_shared_tmp_osiris_ipc_sock_fallback_removed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The insecure fallback /tmp/osiris_ipc.sock must never be returned."""
        monkeypatch.delenv("OSIRIS_IPC_SOCK", raising=False)
        resolved = get_ipc_socket_path()
        assert resolved != Path("/tmp/osiris_ipc.sock")
        assert resolved.name == DEFAULT_IPC_SOCK_NAME

    def test_unwritable_run_osiris_falls_back_to_private_dev_dir(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When /run/osiris is unwritable, get_ipc_socket_path falls back to private dev dir."""
        monkeypatch.delenv("OSIRIS_IPC_SOCK", raising=False)

        def fake_access(path: str, mode: int) -> bool:
            if "/run/osiris" in str(path):
                return False
            return True

        with patch.object(Path, "exists", return_value=True):
            monkeypatch.setattr(os, "access", fake_access)
            resolved = get_ipc_socket_path()
            assert resolved == get_private_dev_runtime_dir() / DEFAULT_IPC_SOCK_NAME


class TestPeerCredentialAuthorization:
    """Tests for connecting process identity verification via SO_PEERCRED."""

    def test_is_peer_authorized_allows_root_and_current_user(self) -> None:
        """UID 0 (collector root) and current user UID must be authorized."""
        current_uid = os.geteuid() if hasattr(os, "geteuid") else 1000
        current_gid = os.getegid() if hasattr(os, "getegid") else 1000

        mock_sock = MagicMock()

        with patch(
            "backend.services.events.ipc_broadcast.get_peer_credentials",
            return_value=(1234, 0, current_gid),
        ):
            assert is_peer_authorized(mock_sock) is True

        with patch(
            "backend.services.events.ipc_broadcast.get_peer_credentials",
            return_value=(1235, current_uid, current_gid),
        ):
            assert is_peer_authorized(mock_sock) is True

    def test_unauthorized_unix_socket_connection_rejected(self) -> None:
        """Processes running under untrusted UID/GID must be rejected."""
        mock_sock = MagicMock()
        with patch(
            "backend.services.events.ipc_broadcast.get_peer_credentials",
            return_value=(9999, 9999, 9999),
        ):
            authorized = is_peer_authorized(
                mock_sock, allowed_uids={0, 1000}, allowed_gids={1000}
            )
            assert authorized is False

    def test_linux_getsockopt_failure_rejects_peer(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """On Linux, failure of getsockopt (SO_PEERCRED) must reject connection (fail-closed)."""
        monkeypatch.setattr("sys.platform", "linux")
        mock_sock = MagicMock()
        mock_sock.getsockopt.side_effect = OSError("SO_PEERCRED extraction failed")

        authorized = is_peer_authorized(mock_sock)
        assert authorized is False

    def test_linux_none_credentials_rejects_peer(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """On Linux, None peer credential result must reject connection."""
        monkeypatch.setattr("sys.platform", "linux")
        mock_sock = MagicMock()
        with patch(
            "backend.services.events.ipc_broadcast.get_peer_credentials",
            return_value=None,
        ):
            assert is_peer_authorized(mock_sock) is False

    def test_non_linux_none_credentials_preserves_compatible_behavior(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """On non-Linux platforms (macOS/Darwin), None credentials preserves compatibility."""
        monkeypatch.setattr("sys.platform", "darwin")
        mock_sock = MagicMock()
        with patch(
            "backend.services.events.ipc_broadcast.get_peer_credentials",
            return_value=None,
        ):
            assert is_peer_authorized(mock_sock) is True

    def test_is_peer_authorized_rejects_none_socket_on_all_platforms(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A None socket object must always be rejected across all platforms."""
        for plat in ["linux", "darwin", "freebsd", "win32"]:
            monkeypatch.setattr("sys.platform", plat)
            assert is_peer_authorized(None) is False

    def test_ipc_server_disconnects_unauthorized_peer(self) -> None:
        """IPCServer must close connection immediately when peer is unauthorized."""
        sock_file = get_short_test_sock()
        handled = []

        async def handler(payload: dict) -> None:
            handled.append(payload)

        async def _test() -> None:
            server = IPCServer(handler, socket_path=sock_file)
            await server.start()

            try:
                with patch(
                    "backend.services.events.ipc_broadcast.is_peer_authorized",
                    return_value=False,
                ):
                    r, w = await asyncio.open_unix_connection(path=str(sock_file))
                    ev_uid = str(uuid.uuid4()).encode()
                    msg = b'{"type": "event", "id": "' + ev_uid + b'"}\n'
                    w.write(msg)
                    try:
                        await w.drain()
                    except (ConnectionResetError, BrokenPipeError):
                        pass

                    # Server should disconnect
                    await asyncio.sleep(0.1)
                    try:
                        w.close()
                        await w.wait_closed()
                    except Exception:
                        pass

                assert len(handled) == 0
            finally:
                await server.stop()
                sock_file.unlink(missing_ok=True)

        asyncio.run(_test())

    def test_unprivileged_local_process_cannot_inject_notifications(self) -> None:
        """Ordinary unprivileged local process cannot inject notifications over IPC."""
        sock_file = get_short_test_sock()
        handled = []

        async def handler(payload: dict) -> None:
            handled.append(payload)

        async def _test() -> None:
            server = IPCServer(handler, socket_path=sock_file)
            await server.start()

            try:
                # Simulate an ordinary unprivileged local process (untrusted UID 9999, GID 9999)
                with patch(
                    "backend.services.events.ipc_broadcast.get_peer_credentials",
                    return_value=(8888, 9999, 9999),
                ):
                    r, w = await asyncio.open_unix_connection(path=str(sock_file))
                    fake_ev = {
                        "type": "event",
                        "id": str(uuid.uuid4()),
                        "host_id": "spoofed-host",
                    }
                    w.write(json.dumps(fake_ev).encode("utf-8") + b"\n")
                    try:
                        await w.drain()
                    except (ConnectionResetError, BrokenPipeError):
                        pass

                    await asyncio.sleep(0.1)
                    try:
                        w.close()
                        await w.wait_closed()
                    except Exception:
                        pass

                # Handler must NOT have received any message
                assert len(handled) == 0
            finally:
                await server.stop()
                sock_file.unlink(missing_ok=True)

        asyncio.run(_test())


class TestIpcSchemaValidation:
    """Tests for validating incoming IPC message types, fields, and UUIDs."""

    def test_non_dict_payload_rejected(self) -> None:
        for invalid in ["string", [1, 2, 3], 12345, None]:
            valid, reason = validate_ipc_payload(invalid)
            assert valid is False
            assert "dictionary" in reason

    def test_unknown_message_type_rejected(self) -> None:
        payload = {"type": "arbitrary_execution", "cmd": "rm -rf"}
        valid, reason = validate_ipc_payload(payload)
        assert valid is False
        assert "Invalid or missing IPC message type" in reason

    def test_event_missing_id_rejected(self) -> None:
        payload = {"type": "event"}
        valid, reason = validate_ipc_payload(payload)
        assert valid is False
        assert "requires 'id' or 'ids'" in reason

    def test_event_non_uuid_id_rejected(self) -> None:
        payload = {"type": "event", "id": "not-a-valid-uuid"}
        valid, reason = validate_ipc_payload(payload)
        assert valid is False
        assert "Invalid UUID" in reason

    def test_valid_event_payload_accepted(self) -> None:
        ev_id = str(uuid.uuid4())
        payload = {"type": "event", "id": ev_id, "host_id": "test-host"}
        valid, reason = validate_ipc_payload(payload)
        assert valid is True
        assert reason == ""

    def test_valid_detection_and_resource_payloads_accepted(self) -> None:
        det_id = str(uuid.uuid4())
        res_id = str(uuid.uuid4())

        valid_det, _ = validate_ipc_payload({"type": "detection", "ids": [det_id]})
        valid_res, _ = validate_ipc_payload({"type": "resource", "id": res_id})

        assert valid_det is True
        assert valid_res is True

    def test_heartbeat_payload_validation(self) -> None:
        valid_hb, _ = validate_ipc_payload(
            {"type": "heartbeat", "data": {"status": "running"}}
        )
        assert valid_hb is True

        invalid_hb, reason = validate_ipc_payload(
            {"type": "heartbeat", "data": "not-a-dict"}
        )
        assert invalid_hb is False
        assert "must be a dictionary" in reason


class TestHeartbeatSecurityAndSpoofRejection:
    """Tests verifying rejection of untrusted/spoofed heartbeat injection."""

    def test_heartbeat_rejected_when_no_authoritative_health_file(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Heartbeats without an authoritative status file must be rejected."""
        empty_dir = tmp_path / "empty_dir"
        empty_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: empty_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(empty_dir / "nonexistent_col"),
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_BACKEND_RUNTIME_DIR",
            str(empty_dir / "nonexistent_bak"),
        )

        spoofed = {"supervisor_pid": 9999, "status": "spoofed", "healthy": False}
        with patch.object(Path, "exists", return_value=False):
            result = verify_and_hydrate_heartbeat(spoofed)
            assert result is None

    def test_spoofed_heartbeat_contradicting_authoritative_file_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If payload data contradicts authoritative health status file, reject it."""
        health_dir = tmp_path / "collector_health"
        health_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: health_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(health_dir),
        )

        auth_file = health_dir / "osiris_collector_health.json"
        auth_data = {
            "supervisor_pid": os.getpid(),
            "status": "running",
            "healthy": True,
            "cycle_count": 10,
            "collectors": {"proc": {"healthy": True}},
        }
        auth_file.write_text(json.dumps(auth_data), encoding="utf-8")

        # Attacker attempts to inject fake "compromised" status
        spoofed = {
            "supervisor_pid": os.getpid(),
            "status": "compromised",
            "healthy": False,
        }
        result = verify_and_hydrate_heartbeat(spoofed)
        assert result is None

    def test_authoritative_heartbeat_hydration_succeeds(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Legitimate heartbeat matching authoritative file hydrates correctly."""
        health_dir = tmp_path / "collector_health"
        health_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: health_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(health_dir),
        )

        auth_file = health_dir / "osiris_collector_health.json"
        auth_data = {
            "supervisor_pid": os.getpid(),
            "status": "running",
            "healthy": True,
            "cycle_count": 12,
            "collectors": {"proc": {"healthy": True}},
        }
        auth_file.write_text(json.dumps(auth_data), encoding="utf-8")

        result = verify_and_hydrate_heartbeat(None)
        assert result is not None
        assert result["cycle_count"] == 12
        assert result["status"] == "running"

    def test_heartbeat_rejected_when_supervisor_pid_dead(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Heartbeat must be rejected if the supervisor PID from the health file is dead."""
        health_dir = tmp_path / "collector_health"
        health_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: health_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(health_dir),
        )

        auth_file = health_dir / "osiris_collector_health.json"
        # Find a non-running PID
        dead_pid = 999999
        auth_data = {
            "supervisor_pid": dead_pid,
            "status": "running",
            "healthy": True,
            "cycle_count": 5,
        }
        auth_file.write_text(json.dumps(auth_data), encoding="utf-8")

        result = verify_and_hydrate_heartbeat(None)
        assert result is None

    def test_heartbeat_rejected_when_health_file_world_writable(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Heartbeat must be rejected if the health file is world-writable."""
        health_dir = tmp_path / "collector_health"
        health_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: health_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(health_dir),
        )

        auth_file = health_dir / "osiris_collector_health.json"
        auth_data = {
            "supervisor_pid": os.getpid(),
            "status": "running",
            "healthy": True,
            "cycle_count": 5,
        }
        auth_file.write_text(json.dumps(auth_data), encoding="utf-8")
        auth_file.chmod(0o666)  # Make world-writable

        result = verify_and_hydrate_heartbeat(None)
        assert result is None

    def test_heartbeat_rejected_when_health_file_is_symlink(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Heartbeat must be rejected if the health file path is a symlink."""
        health_dir = tmp_path / "collector_health"
        health_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: health_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(health_dir),
        )

        target_file = health_dir / "real_health.json"
        target_file.write_text(
            json.dumps({"supervisor_pid": os.getpid(), "status": "running", "healthy": True}),
            encoding="utf-8",
        )
        symlink_file = health_dir / "osiris_collector_health.json"
        symlink_file.symlink_to(target_file)

        result = verify_and_hydrate_heartbeat(None)
        assert result is None

    def test_shared_tmp_health_file_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Insecure shared /tmp/osiris_collector_health.json must never be loaded."""
        empty_dir = tmp_path / "empty_dir"
        empty_dir.mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.get_private_dev_runtime_dir",
            lambda: empty_dir,
        )
        monkeypatch.setattr(
            "backend.services.events.ipc_broadcast.DEFAULT_COLLECTOR_RUNTIME_DIR",
            str(empty_dir / "col"),
        )

        # Place a fake health file in /tmp/osiris_collector_health.json
        tmp_fake = Path("/tmp/osiris_collector_health.json")
        try:
            tmp_fake.write_text(
                json.dumps({"supervisor_pid": os.getpid(), "status": "running", "healthy": True}),
                encoding="utf-8",
            )
            result = verify_and_hydrate_heartbeat(None)
            assert result is None, "Insecure shared /tmp health file was loaded!"
        finally:
            tmp_fake.unlink(missing_ok=True)


class TestIpcSizeLimitsAndRateLimiting:
    """Tests for bounded message sizes and rate-limiting."""

    def test_oversized_ipc_message_rejected(self) -> None:
        """Messages exceeding MAX_IPC_MESSAGE_SIZE must be dropped safely."""
        sock_file = get_short_test_sock()
        handled = []

        async def handler(payload: dict) -> None:
            handled.append(payload)

        async def _test() -> None:
            server = IPCServer(handler, socket_path=sock_file)
            await server.start()

            try:
                r, w = await asyncio.open_unix_connection(path=str(sock_file))
                # Send 100 KB payload (limit is 64 KB)
                oversized = b'{"type": "event", "id": "' + (b"A" * 70000) + b'"}\n'
                w.write(oversized)
                try:
                    await w.drain()
                except (ConnectionResetError, BrokenPipeError, Exception):
                    pass

                await asyncio.sleep(0.1)
                try:
                    w.close()
                    await w.wait_closed()
                except Exception:
                    pass

                assert len(handled) == 0
            finally:
                await server.stop()
                sock_file.unlink(missing_ok=True)

        asyncio.run(_test())

    def test_ipc_rate_limiter_throttles(self) -> None:
        """Rate limiter must permit burst and throttle excess requests."""

        async def _test() -> None:
            limiter = IPCRateLimiter(max_rate=10.0, burst=5.0)

            # First 5 immediate acquires succeed (burst capacity)
            for _ in range(5):
                assert await limiter.acquire() is True

            # 6th acquire exceeds burst and fails
            assert await limiter.acquire() is False

        asyncio.run(_test())


class TestRuntimeDirectorySeparationAndProtection:
    """Tests for separate systemd runtime directories and PID protection."""

    def test_systemd_service_declarations_separated(self) -> None:
        """Backend and collector systemd units must declare separate runtime dirs."""
        b_path = Path("deployment/systemd/osiris-backend.service")
        c_path = Path("deployment/systemd/osiris-collector.service")
        backend_unit = b_path.read_text(encoding="utf-8")
        collector_unit = c_path.read_text(encoding="utf-8")

        # Backend uses osiris runtime dir
        assert "RuntimeDirectory=osiris" in backend_unit
        assert "User=osiris" in backend_unit

        # Collector uses osiris-collector runtime dir with mode 0755 (no group write)
        assert "RuntimeDirectory=osiris-collector" in collector_unit
        assert "RuntimeDirectoryMode=0755" in collector_unit
        assert "User=root" in collector_unit
        assert "Group=osiris" in collector_unit

    def test_collector_pid_protected_from_backend_unlink(self, tmp_path: Path) -> None:
        """Unprivileged backend user cannot unlink PID file in root-owned 0755 dir."""
        root_dir = tmp_path / "osiris-collector"
        root_dir.mkdir(parents=True, exist_ok=True)
        pid_file = root_dir / "osiris_collector_supervisor.pid"
        pid_file.write_text("12345\n", encoding="ascii")

        # Simulate root-owned directory without write permission (mode 0555)
        root_dir.chmod(0o555)
        try:
            with pytest.raises(PermissionError):
                pid_file.unlink()
        finally:
            # Restore permissions for cleanup
            root_dir.chmod(0o755)

    def test_backend_health_file_read_access(self, tmp_path: Path) -> None:
        """Backend user can read collector health status in 0755 directory."""
        collector_dir = tmp_path / "osiris-collector"
        collector_dir.mkdir(parents=True, exist_ok=True)
        collector_dir.chmod(0o755)

        health_file = collector_dir / "osiris_collector_health.json"
        health_payload = {"status": "running", "healthy": True, "cycle_count": 42}
        health_file.write_text(json.dumps(health_payload), encoding="utf-8")
        health_file.chmod(0o644)

        # Read must succeed
        read_data = json.loads(health_file.read_text(encoding="utf-8"))
        assert read_data["cycle_count"] == 42


class TestPostgresAndUdsNotificationDelivery:
    """Tests for PostgreSQL LISTEN/NOTIFY and UDS delivery paths."""

    def test_send_ipc_notification_dispatches_pg_notify(self) -> None:
        """send_ipc_notification dispatches pg_notify when dialect is postgresql."""
        mock_bind = MagicMock()
        mock_bind.dialect.name = "postgresql"
        mock_session = MagicMock()
        mock_session.get_bind.return_value = mock_bind

        ev_id = str(uuid.uuid4())
        payload = {"type": "event", "id": ev_id}

        delivered = send_ipc_notification(payload, session=mock_session)
        assert delivered is True
        mock_session.execute.assert_called_once()
        args, kwargs = mock_session.execute.call_args
        params = (
            args[1]
            if len(args) > 1
            else kwargs.get("parameters") or kwargs.get("params")
        )
        assert params["channel"] == DEFAULT_PG_CHANNEL

    def test_legitimate_collector_to_backend_ipc_delivery(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Legitimate event delivery over Unix socket bridge succeeds."""
        sock_file = get_short_test_sock()
        monkeypatch.setenv("OSIRIS_IPC_SOCK", str(sock_file))

        handled = []

        async def handler(payload: dict) -> None:
            handled.append(payload)

        async def _test() -> None:
            server = IPCServer(handler, socket_path=sock_file)
            await server.start()

            try:
                ev_id = str(uuid.uuid4())
                payload = {"type": "event", "id": ev_id, "host_id": "test-host"}

                delivered = send_ipc_notification(payload)
                assert delivered is True

                await asyncio.sleep(0.1)
                assert len(handled) == 1
                assert handled[0]["id"] == ev_id
                assert handled[0]["type"] == "event"
            finally:
                await server.stop()
                sock_file.unlink(missing_ok=True)

        asyncio.run(_test())
