"""Unit tests for frontend disk I/O rate calculation and formatting.

Verifies:
1. Differential rate calculation (Δbytes / Δt) across multiple resource snapshots.
2. First sample baseline handling (returns null rate).
3. Counter reset / negative difference handling (e.g. system reboot
   or counter overflow clamps to 0).
4. Missing / null measurements handling (returns null rate).
5. Zero or negative Δt handling (returns null rate).
6. formatRate unit scaling (B/s, KB/s, MB/s, GB/s).
7. HTML template markup contract: table headers and metric cards
   reflect throughput rates.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.helpers.js_runtime import SKIP_REASON, find_js_runtime

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
RESOURCES_JS_PATH = (
    PROJECT_ROOT / "frontend" / "static" / "js" / "views" / "resources.js"
)
INDEX_HTML_PATH = PROJECT_ROOT / "frontend" / "templates" / "index.html"


def run_js_eval(code: str) -> str:
    """Execute JavaScript code with minimal DOM environment and return stdout."""
    runtime = find_js_runtime()
    if runtime is None:
        pytest.skip(SKIP_REASON)

    setup = (
        "var window = {}; "
        "var document = { "
        "addEventListener: function() {}, "
        "getElementById: function() { return null; } "
        "}; "
        f"load('{RESOURCES_JS_PATH}'); "
    )
    full_code = setup + code
    if runtime.name in ("node", "nodejs"):
        import subprocess

        res = subprocess.run(
            [runtime.binary, "-e", full_code],
            capture_output=True,
            text=True,
        )
    else:
        # JSC
        import subprocess

        res = subprocess.run(
            [runtime.binary, "-e", full_code],
            capture_output=True,
            text=True,
        )
    assert res.returncode == 0, f"JS execution failed: {res.stderr}"
    return res.stdout.strip()


class TestResourcesDiskRateCalculation:
    """Unit tests executing computeDiskRates and formatRate in the JS runtime."""

    def test_format_rate_units(self) -> None:
        out = run_js_eval(
            "print(JSON.stringify(["
            "  window.OsirisResources.formatRate(null),"
            "  window.OsirisResources.formatRate(0),"
            "  window.OsirisResources.formatRate(512),"
            "  window.OsirisResources.formatRate(1024),"
            "  window.OsirisResources.formatRate(2048),"
            "  window.OsirisResources.formatRate(1048576),"
            "  window.OsirisResources.formatRate(1073741824)"
            "]));"
        )
        data = json.loads(out)
        assert data[0] == "0 B/s" or data[0] == "-"
        assert data[1] == "0 B/s"
        assert "512 B/s" in data[2]
        assert "1.0" in data[3] and "KB/s" in data[3]
        assert "2.0" in data[4] and "KB/s" in data[4]
        assert "1.0" in data[5] and "MB/s" in data[5]
        assert "1.0" in data[6] and "GB/s" in data[6]

    def test_empty_snapshots(self) -> None:
        out = run_js_eval(
            "print(JSON.stringify(window.OsirisResources.computeDiskRates([])));"
        )
        assert json.loads(out) == []

    def test_single_snapshot_baseline(self) -> None:
        out = run_js_eval(
            "var s = window.OsirisResources.computeDiskRates(["
            "  { timestamp: '2026-01-01T00:00:00Z',"
            "    disk_read_bytes: 1000, disk_write_bytes: 2000 }"
            "]);"
            "print(JSON.stringify(s));"
        )
        res = json.loads(out)
        assert len(res) == 1
        assert res[0]["readRate"] is None
        assert res[0]["writeRate"] is None

    def test_normal_rate_calculation(self) -> None:
        # dt = 10s: read delta 5000 bytes => 500 B/s,
        # write delta 10000 bytes => 1000 B/s
        out = run_js_eval(
            "var s = window.OsirisResources.computeDiskRates(["
            "  { timestamp: '2026-01-01T00:00:00Z',"
            "    disk_read_bytes: 1000, disk_write_bytes: 2000 },"
            "  { timestamp: '2026-01-01T00:00:10Z',"
            "    disk_read_bytes: 6000, disk_write_bytes: 12000 }"
            "]);"
            "print(JSON.stringify(s));"
        )
        res = json.loads(out)
        assert len(res) == 2
        assert res[0]["readRate"] is None
        assert res[1]["readRate"] == 500
        assert res[1]["writeRate"] == 1000

    def test_counter_reset_reboot_handling(self) -> None:
        # Counter reset: read bytes drops from 6000 to 500 -> rate clamps to 0
        out = run_js_eval(
            "var s = window.OsirisResources.computeDiskRates(["
            "  { timestamp: '2026-01-01T00:00:00Z',"
            "    disk_read_bytes: 6000, disk_write_bytes: 12000 },"
            "  { timestamp: '2026-01-01T00:00:10Z',"
            "    disk_read_bytes: 500, disk_write_bytes: 100 }"
            "]);"
            "print(JSON.stringify(s));"
        )
        res = json.loads(out)
        assert len(res) == 2
        assert res[1]["readRate"] == 0
        assert res[1]["writeRate"] == 0

    def test_zero_or_negative_dt(self) -> None:
        # dt <= 0 -> rate is null
        out = run_js_eval(
            "var s = window.OsirisResources.computeDiskRates(["
            "  { timestamp: '2026-01-01T00:00:10Z',"
            "    disk_read_bytes: 1000, disk_write_bytes: 2000 },"
            "  { timestamp: '2026-01-01T00:00:10Z',"
            "    disk_read_bytes: 6000, disk_write_bytes: 12000 }"
            "]);"
            "print(JSON.stringify(s));"
        )
        res = json.loads(out)
        assert res[1]["readRate"] is None
        assert res[1]["writeRate"] is None

    def test_missing_or_null_measurements(self) -> None:
        out = run_js_eval(
            "var s = window.OsirisResources.computeDiskRates(["
            "  { timestamp: '2026-01-01T00:00:00Z',"
            "    disk_read_bytes: null, disk_write_bytes: null },"
            "  { timestamp: '2026-01-01T00:00:10Z',"
            "    disk_read_bytes: 5000, disk_write_bytes: 10000 }"
            "]);"
            "print(JSON.stringify(s));"
        )
        res = json.loads(out)
        assert res[1]["readRate"] is None
        assert res[1]["writeRate"] is None


class TestResourcesMarkupContract:
    """Verify that index.html markup uses Rate labels for disk read/write."""

    def test_index_html_has_disk_rate_headers_and_cards(self) -> None:
        assert INDEX_HTML_PATH.exists()
        content = INDEX_HTML_PATH.read_text(encoding="utf-8")

        # Metric card labels
        assert "Disk Read Rate" in content
        assert "Disk Write Rate" in content

        # Table header columns
        assert "Disk Read Rate</th>" in content
        assert "Disk Write Rate</th>" in content
