"""Unit tests for deployment ownership, permissions, and runtime directory isolation.

Verifies:
1. Application source code write protection:
   - Files and directories owned by root:osiris.
   - Directory mode 0750 prevents unprivileged backend user write/tamper.
   - Regular file mode 0640 prevents backend modification of code executed by root.
   - Script/binary mode 0750 allows execution without group/world write permissions.
   - Virtual environment root-owned and not writable by backend user 'osiris'.
2. Environment configuration (.env) preflight security:
   - Root:osiris ownership with mode 0640 passes preflight.
   - Mode 0440 (read-only for root and group) passes preflight.
   - Missing owner-read permission (e.g. 0040, 0240) is strictly rejected.
   - Ownership by backend account ('osiris') is strictly rejected in production.
   - Group-writable (0660), world-accessible (0644/0666), and executable
     (0750) rejected.
   - CORS validation rejects wildcard '*' and requires explicit origins.
3. Separated runtime directories:
   - Root collector (/run/osiris-collector, mode 0755, root:osiris) protects
     supervisor PID lock and health file from backend modification or unlinking.
   - Backend (/run/osiris, mode 0775, osiris:osiris) hosts IPC socket with mode 0660.
4. Runtime path consistency across service units, supervisor, IPC broadcast, and
   scripts.
"""

from __future__ import annotations

import stat
from pathlib import Path
from unittest.mock import MagicMock, patch

from scripts.validate_deployment_env import validate_deployment_environment


class TestApplicationCodeWriteProtection:
    """Verify application code and virtual environment write-protection."""

    def test_directory_mode_0750_denies_group_and_world_write(self) -> None:
        """Mode 0750 must give root full access and deny all write to group/world."""
        mode = 0o750
        # Owner permissions
        assert mode & stat.S_IRUSR
        assert mode & stat.S_IWUSR
        assert mode & stat.S_IXUSR
        # Group permissions: read + exec only, NO write
        assert mode & stat.S_IRGRP
        assert not (mode & stat.S_IWGRP), "Directory must NOT be group-writable"
        assert mode & stat.S_IXGRP
        # World permissions: completely none
        assert not (mode & 0o007), "Directory must have ZERO world permissions"

    def test_regular_file_mode_0640_denies_group_and_world_write_and_execute(
        self,
    ) -> None:
        """Mode 0640 must give root read+write, group read-only, deny write/exec."""
        mode = 0o0640
        # Owner permissions
        assert mode & stat.S_IRUSR
        assert mode & stat.S_IWUSR
        assert not (mode & stat.S_IXUSR), "Regular files must not be executable"
        # Group permissions: read-only, NO write, NO execute
        assert mode & stat.S_IRGRP
        assert not (mode & stat.S_IWGRP), "Files must NOT be group-writable"
        assert not (mode & stat.S_IXGRP), "Files must NOT be group-executable"
        # World permissions: completely none
        assert not (mode & 0o007), "Regular files must have ZERO world permissions"

    def test_executable_script_mode_0750_denies_group_write(self) -> None:
        """Mode 0750 for scripts allows root and group execute without group write."""
        mode = 0o0750
        assert mode & stat.S_IXUSR
        assert mode & stat.S_IXGRP
        assert not (mode & stat.S_IWGRP), "Scripts must NOT be group-writable"
        assert not (mode & 0o007), "Scripts must have ZERO world permissions"

    def test_unprivileged_backend_cannot_modify_root_owned_file(
        self, tmp_path: Path
    ) -> None:
        """Simulate root:osiris file mode 0640: backend user cannot write."""
        test_file = tmp_path / "service.py"
        test_file.write_text("print('genuine code')\n", encoding="utf-8")
        test_file.chmod(0o0640)

        # Check permission bits: group write bit is 0
        file_stat = test_file.stat()
        file_mode = file_stat.st_mode & 0o777
        assert (file_mode & stat.S_IWGRP) == 0
        assert (file_mode & stat.S_IWOTH) == 0

    def test_virtual_environment_protection_structure(self, tmp_path: Path) -> None:
        """Virtual environment directories and packages must not be group-writable."""
        venv_dir = tmp_path / ".venv"
        bin_dir = venv_dir / "bin"
        lib_dir = venv_dir / "lib" / "python3.12" / "site-packages"
        bin_dir.mkdir(parents=True)
        lib_dir.mkdir(parents=True)

        py_bin = bin_dir / "python"
        py_bin.write_text("#!/bin/sh\nexit 0\n", encoding="utf-8")
        py_bin.chmod(0o0750)

        pkg_init = lib_dir / "module.py"
        pkg_init.write_text("# module\n", encoding="utf-8")
        pkg_init.chmod(0o0640)

        # Verify permissions
        assert (py_bin.stat().st_mode & stat.S_IWGRP) == 0
        assert (pkg_init.stat().st_mode & stat.S_IWGRP) == 0


class TestEnvironmentConfigPreflightValidation:
    """Verify preflight validation of .env ownership, permissions, and CORS."""

    def test_preflight_accepts_root_osiris_mode_0640(self, tmp_path: Path) -> None:
        """Root-owned file with group osiris and mode 0640 passes preflight."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=http://localhost:8000,http://127.0.0.1:8000\n",
            encoding="utf-8",
        )

        mock_pw = MagicMock(pw_uid=1001, pw_gid=1001)
        mock_grp = MagicMock(gr_gid=1001)
        stat_valid = MagicMock(st_mode=stat.S_IFREG | 0o640, st_uid=0, st_gid=1001)

        with (
            patch("pwd.getpwnam", return_value=mock_pw),
            patch("grp.getgrnam", return_value=mock_grp),
            patch("os.lstat", return_value=stat_valid),
            patch("os.access", return_value=True),
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is True
            assert len(errors) == 0

    def test_preflight_accepts_root_osiris_mode_0440(self, tmp_path: Path) -> None:
        """Read-only mode 0440 (root and group read) passes preflight cleanly."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=http://localhost:8000\n",
            encoding="utf-8",
        )

        mock_pw = MagicMock(pw_uid=1001, pw_gid=1001)
        mock_grp = MagicMock(gr_gid=1001)
        stat_valid = MagicMock(st_mode=stat.S_IFREG | 0o440, st_uid=0, st_gid=1001)

        with (
            patch("pwd.getpwnam", return_value=mock_pw),
            patch("grp.getgrnam", return_value=mock_grp),
            patch("os.lstat", return_value=stat_valid),
            patch("os.access", return_value=True),
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is True
            assert len(errors) == 0

    def test_preflight_rejects_missing_owner_read_permission(
        self, tmp_path: Path
    ) -> None:
        """Environment file without owner-read permission (mode 0040) is rejected."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )

        mock_stat = MagicMock(st_mode=stat.S_IFREG | 0o040, st_uid=0, st_gid=1001)
        with (
            patch("os.lstat", return_value=mock_stat),
            patch("os.access", return_value=True),
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=False
            )
            assert valid is False
            assert any("not owner-readable" in e for e in errors)

    def test_preflight_rejects_backend_user_ownership(self, tmp_path: Path) -> None:
        """When user 'osiris' exists, .env owned by osiris (UID 1001) is rejected."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n",
            encoding="utf-8",
        )

        mock_pw = MagicMock(pw_uid=1001, pw_gid=1001)
        # Owned by osiris:osiris (UID 1001, GID 1001)
        stat_osiris_owned = MagicMock(
            st_mode=stat.S_IFREG | 0o640, st_uid=1001, st_gid=1001
        )

        with (
            patch("pwd.getpwnam", return_value=mock_pw),
            patch("os.lstat", return_value=stat_osiris_owned),
            patch("os.access", return_value=True),
        ):
            valid, errors = validate_deployment_environment(
                env_file_path=env_file, strict_ownership=True
            )
            assert valid is False
            assert any("must be owned by 'root' (UID 0)" in e for e in errors)

    def test_preflight_rejects_wildcard_cors(self, tmp_path: Path) -> None:
        """Wildcard CORS origin '*' in .env is strictly rejected for deployment."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=*\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert valid is False
        assert any("Wildcard CORS origin '*'" in e for e in errors)

    def test_preflight_rejects_wildcard_cors_in_list(self, tmp_path: Path) -> None:
        """Wildcard inside origin list (e.g. 'https://app.osiris.io, *') rejected."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=https://app.osiris.io, *\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert valid is False
        assert any("Wildcard CORS origin '*'" in e for e in errors)

    def test_preflight_rejects_empty_cors(self, tmp_path: Path) -> None:
        """Empty OSIRIS_CORS_ALLOWED_ORIGINS is rejected."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert valid is False
        assert any(
            "OSIRIS_CORS_ALLOWED_ORIGINS is defined but empty" in e for e in errors
        )

    def test_preflight_accepts_explicit_cors_origins(self, tmp_path: Path) -> None:
        """Explicit comma-separated CORS origins pass cleanly."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "OSIRIS_DEBUG=false\n"
            "OSIRIS_SECRET_KEY=cryptographically-strong-secret-key-32chars-min\n"
            "OSIRIS_DATABASE_URL=postgresql://osiris_app:strong_pw_123456789@localhost:5432/osiris_acceptance_phase2\n"
            "OSIRIS_CORS_ALLOWED_ORIGINS=https://app.osiris.internal, https://soc.internal:8443\n",
            encoding="utf-8",
        )
        env_file.chmod(0o600)

        valid, errors = validate_deployment_environment(
            env_file_path=env_file, strict_ownership=False
        )
        assert valid is True
        assert len(errors) == 0


class TestSeparatedRuntimeDirectories:
    """Verify runtime directory isolation between root collector and backend."""

    def test_root_collector_runtime_dir_mode_0755_prevents_group_write(
        self,
    ) -> None:
        """Mode 0755 on /run/osiris-collector prevents group write."""
        mode = 0o0755
        assert (mode & stat.S_IWGRP) == 0, "Collector dir must NOT be group-writable"
        assert (mode & stat.S_IWOTH) == 0, "Collector dir must NOT be world-writable"
        assert mode & stat.S_IRGRP, "Collector dir must be group-readable"
        assert mode & stat.S_IXGRP, "Collector dir must be group-traversable"

    def test_backend_runtime_dir_mode_0775_allows_authorized_group(
        self,
    ) -> None:
        """Mode 0775 on /run/osiris allows root collector to connect."""
        mode = 0o0775
        assert mode & stat.S_IRGRP
        assert mode & stat.S_IWGRP
        assert mode & stat.S_IXGRP
        assert not (mode & stat.S_IWOTH), "Backend dir must NOT be world-writable"

    def test_backend_ipc_socket_mode_0660_restricts_access(self) -> None:
        """Socket mode 0660 allows backend and collector but NO world access."""
        mode = 0o0660
        assert mode & stat.S_IRUSR
        assert mode & stat.S_IWUSR
        assert mode & stat.S_IRGRP
        assert mode & stat.S_IWGRP
        assert not (mode & 0o007), "IPC socket must have ZERO world permissions"


class TestRuntimePathConsistency:
    """Verify exact path consistency across service units, supervisor, IPC, scripts."""

    def test_systemd_backend_runtime_directory_matches(self) -> None:
        service_file = Path("deployment/systemd/osiris-backend.service")
        assert service_file.exists()
        content = service_file.read_text(encoding="utf-8")
        assert "RuntimeDirectory=osiris" in content
        assert "RuntimeDirectoryMode=0775" in content

    def test_systemd_collector_runtime_directory_matches(self) -> None:
        service_file = Path("deployment/systemd/osiris-collector.service")
        assert service_file.exists()
        content = service_file.read_text(encoding="utf-8")
        assert "RuntimeDirectory=osiris-collector" in content
        assert "RuntimeDirectoryMode=0755" in content
        expected_cmd = (
            "--pid-file /run/osiris-collector/osiris_collector_supervisor.pid"
        )
        assert expected_cmd in content

    def test_collector_supervisor_default_paths(self) -> None:
        from collectors.supervisor import (
            DEFAULT_COLLECTOR_RUNTIME_DIR,
            DEFAULT_HEALTH_FILE,
            DEFAULT_PID_FILE,
        )

        assert DEFAULT_COLLECTOR_RUNTIME_DIR == "/run/osiris-collector"
        assert (
            DEFAULT_PID_FILE == "/run/osiris-collector/osiris_collector_supervisor.pid"
        )
        assert (
            DEFAULT_HEALTH_FILE == "/run/osiris-collector/osiris_collector_health.json"
        )

    def test_ipc_broadcast_default_paths(self) -> None:
        from backend.services.events.ipc_broadcast import (
            DEFAULT_BACKEND_RUNTIME_DIR,
            DEFAULT_COLLECTOR_RUNTIME_DIR,
            DEFAULT_IPC_SOCK_NAME,
        )

        assert DEFAULT_BACKEND_RUNTIME_DIR == "/run/osiris"
        assert DEFAULT_COLLECTOR_RUNTIME_DIR == "/run/osiris-collector"
        assert DEFAULT_IPC_SOCK_NAME == "osiris_ipc.sock"

    def test_service_script_runtime_dir_resolution(self) -> None:
        script = Path("scripts/osiris-service.sh").read_text(encoding="utf-8")
        assert "/run/osiris" in script
        assert "/run/osiris-collector" in script
        assert "osiris_collector_supervisor.pid" in script
        assert "osiris_backend.pid" in script
