"""Unit tests for CollectorSupervisor and PID locking."""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from backend.db.base import Base
from collectors.filesystem.inotify import MockInotifyBackend
from collectors.orchestrator import OrchestratorConfig
from collectors.supervisor import CollectorSupervisor, PIDLock, SupervisorLockError


@pytest.fixture
def temp_pid_file(tmp_path: Path) -> Path:
    return tmp_path / "supervisor_test.pid"


@pytest.fixture
def temp_health_file(tmp_path: Path) -> Path:
    return tmp_path / "health_test.json"


@pytest.fixture
def mock_db_session() -> Session:
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)
    engine.dispose()


class TestPIDLock:
    """Test suite for PIDLock mutual exclusion."""

    def test_acquire_and_release(self, temp_pid_file: Path) -> None:
        lock = PIDLock(temp_pid_file)
        lock.acquire()
        assert temp_pid_file.exists()
        assert str(os.getpid()) in temp_pid_file.read_text(encoding="ascii")

        lock.release()
        assert not temp_pid_file.exists()

    def test_duplicate_lock_raises_supervisor_lock_error(
        self, temp_pid_file: Path
    ) -> None:
        lock1 = PIDLock(temp_pid_file)
        lock1.acquire()

        lock2 = PIDLock(temp_pid_file)
        with pytest.raises(SupervisorLockError):
            lock2.acquire()

        lock1.release()

        # Now lock2 can acquire
        lock2.acquire()
        lock2.release()

    def test_default_pid_lock_resolution_and_fallback(self) -> None:
        from backend.services.events.ipc_broadcast import get_private_dev_runtime_dir
        from collectors.supervisor import (
            get_default_health_file,
            get_default_pid_file,
            get_default_runtime_dir,
        )

        r_dir = get_default_runtime_dir()
        assert r_dir in (
            Path("/run/osiris-collector"),
            get_private_dev_runtime_dir(),
        )

        pid_file = get_default_pid_file()
        assert pid_file.name == "osiris_collector_supervisor.pid"

        health_file = get_default_health_file()
        assert health_file.name == "osiris_collector_health.json"

        lock = PIDLock()
        lock.acquire()
        assert lock.pid_file.exists()
        lock.release()
        assert not lock.pid_file.exists()

    def test_unprivileged_fallback_when_run_collector_unwritable(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from backend.services.events.ipc_broadcast import get_private_dev_runtime_dir
        from collectors.supervisor import get_default_runtime_dir

        def fake_access(path: str, mode: int) -> bool:
            if "/run/osiris-collector" in str(path):
                return False
            return True

        monkeypatch.setattr(os, "access", fake_access)
        r_dir = get_default_runtime_dir()
        assert r_dir == get_private_dev_runtime_dir()
        assert (r_dir.stat().st_mode & 0o777) == 0o700


class TestCollectorSupervisor:
    """Test suite for CollectorSupervisor lifecycle."""

    def test_supervisor_single_cycle_writes_health_status(
        self, temp_pid_file: Path, temp_health_file: Path, mock_db_session: Session
    ) -> None:
        host_id = uuid.uuid4()
        config = OrchestratorConfig(
            host_id=host_id,
            process_interval=1.0,
            resource_interval=1.0,
            proc_dir=Path(__file__).parent,  # Safe dummy dir
            fs_backend=MockInotifyBackend(),
        )
        supervisor = CollectorSupervisor(
            config=config,
            pid_file=temp_pid_file,
            health_file=temp_health_file,
            session=mock_db_session,
            interval=0.1,
        )

        code = supervisor.start(watch=False, cycles=1)
        assert code == 0
        assert not temp_pid_file.exists()
        assert temp_health_file.exists()

        data = json.loads(temp_health_file.read_text(encoding="utf-8"))
        assert data["cycle_count"] == 1
        assert "collectors" in data
        assert "proc" in data["collectors"]
        assert "resource" in data["collectors"]
        assert "fs" in data["collectors"]


class TestPIDLockSecurity:
    """Security test suite validating symlink and permission attacks."""

    def test_symlink_attack_rejected_without_truncating_target(
        self, tmp_path: Path
    ) -> None:
        target_file = tmp_path / "sensitive_system_file.txt"
        target_content = "CRITICAL_SYSTEM_DATA_DO_NOT_TRUNCATE"
        target_file.write_text(target_content, encoding="utf-8")

        symlink_pid = tmp_path / "supervisor_attack.pid"
        os.symlink(target_file, symlink_pid)

        lock = PIDLock(symlink_pid)
        with pytest.raises(SupervisorLockError, match="symlink"):
            lock.acquire()

        # Target file must remain untouched
        assert target_file.read_text(encoding="utf-8") == target_content

    def test_broken_symlink_rejected(self, tmp_path: Path) -> None:
        nonexistent = tmp_path / "does_not_exist.txt"
        symlink_pid = tmp_path / "broken_symlink.pid"
        os.symlink(nonexistent, symlink_pid)

        lock = PIDLock(symlink_pid)
        with pytest.raises(SupervisorLockError):
            lock.acquire()

    def test_non_regular_file_rejected(self, tmp_path: Path) -> None:
        dir_pid = tmp_path / "pid_as_dir"
        dir_pid.mkdir()

        lock = PIDLock(dir_pid)
        match_pat = "not a regular file|Is a directory"
        with pytest.raises(SupervisorLockError, match=match_pat):
            lock.acquire()

    def test_mismatched_uid_rejected(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        pid_file = tmp_path / "mismatched_uid.pid"
        pid_file.write_text("1234\n", encoding="ascii")

        # Mock geteuid to simulate running as another user (e.g. root UID 0)
        real_uid = os.geteuid()
        fake_uid = 0 if real_uid != 0 else 9999
        monkeypatch.setattr(os, "geteuid", lambda: fake_uid)

        lock = PIDLock(pid_file)
        with pytest.raises(SupervisorLockError, match="owned by UID"):
            lock.acquire()

    def test_atomic_health_file_write_does_not_follow_symlink(
        self, tmp_path: Path, mock_db_session: Session
    ) -> None:
        target_file = tmp_path / "do_not_overwrite.txt"
        target_content = "HEALTH_TARGET_DATA"
        target_file.write_text(target_content, encoding="utf-8")

        health_file = tmp_path / "health_status.json"
        # Pre-place symlink at health_file location pointing to sensitive target
        os.symlink(target_file, health_file)

        supervisor = CollectorSupervisor(
            pid_file=tmp_path / "dummy.pid",
            health_file=health_file,
            session=mock_db_session,
        )
        supervisor.write_health_status()

        # The target file must NOT be modified
        assert target_file.read_text(encoding="utf-8") == target_content
        # The health file path is atomically replaced with a regular file
        assert not health_file.is_symlink()
        assert health_file.is_file()
