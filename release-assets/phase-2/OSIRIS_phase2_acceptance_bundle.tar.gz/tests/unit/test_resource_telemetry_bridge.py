"""Unit tests for ResourceTelemetryService and API Event projection."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool
from starlette.testclient import TestClient

from backend.api.deps import get_db
from backend.api.security import create_access_token
from backend.db.base import Base
from backend.db.models.app_user import AppUser
from backend.db.models.event import Event
from backend.db.models.host import Host
from backend.db.models.resource_snapshot import ResourceSnapshot
from backend.main import app
from backend.services.events.resource_telemetry import ResourceTelemetryService
from backend.services.events.schemas import RawObservation


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@pytest.fixture
def db_session() -> Session:
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def client(db_session: Session) -> TestClient:
    app.dependency_overrides[get_db] = lambda: db_session
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def sample_host(db_session: Session) -> Host:
    host = Host(
        id=uuid.uuid4(),
        hostname="telemetry-host",
        created_at=utcnow(),
    )
    db_session.add(host)
    db_session.commit()
    return host


@pytest.fixture
def auth_headers(db_session: Session) -> dict[str, str]:
    user = AppUser(
        id=uuid.uuid4(),
        username="res_tester",
        password_hash="pbkdf2_sha256$...",
        role="analyst",
        is_active=True,
        created_at=utcnow(),
    )
    db_session.add(user)
    db_session.commit()
    token = create_access_token(user_id=user.id, username=user.username, role=user.role)
    return {"Authorization": f"Bearer {token}"}


class TestResourceTelemetryBridge:
    """Test suite for ResourceTelemetryService."""

    def test_apply_first_sample_null_cpu(
        self, db_session: Session, sample_host: Host
    ) -> None:
        """First collection cycle has cpu_percent=None (baseline). Must not fail."""
        service = ResourceTelemetryService()
        obs = RawObservation(
            source="resource",
            host_id=str(sample_host.id),
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            observed_at=utcnow(),
            object_type="system",
            payload={
                "cpu_percent": None,
                "memory_total": 8589934592,
                "memory_used": 4294967296,
                "memory_percent": 50.0,
                "disk_usage_percent": 35.5,
            },
        )
        res = service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        assert len(res) == 1
        assert res[0].cpu_percent is None
        assert res[0].memory_percent == 50.0

        saved = db_session.execute(
            select(ResourceSnapshot).where(ResourceSnapshot.host_id == sample_host.id)
        ).scalar_one()
        assert saved.cpu_percent is None
        assert saved.memory_total == 8589934592

    def test_apply_subsequent_sample_with_cpu(
        self, db_session: Session, sample_host: Host
    ) -> None:
        """Subsequent collection cycle computes CPU differential percent."""
        service = ResourceTelemetryService()
        obs = RawObservation(
            source="resource",
            host_id=str(sample_host.id),
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            observed_at=utcnow(),
            object_type="system",
            payload={
                "cpu_percent": 24.8,
                "memory_total": 8589934592,
                "memory_used": 4294967296,
                "memory_percent": 50.0,
                "disk_read_bytes": 1048576,
                "disk_write_bytes": 2097152,
                "disk_usage_percent": 40.0,
            },
        )
        res = service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        assert len(res) == 1
        assert res[0].cpu_percent == 24.8
        assert res[0].disk_read_bytes == 1048576

    def test_idempotent_duplicate_sample(
        self, db_session: Session, sample_host: Host
    ) -> None:
        """Duplicate observations with same timestamp do not create extra rows."""
        service = ResourceTelemetryService()
        ts = utcnow()
        obs = RawObservation(
            source="resource",
            host_id=str(sample_host.id),
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            observed_at=ts,
            object_type="system",
            payload={"cpu_percent": 12.0},
        )
        service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        # Repeat
        service.apply_observations(db_session, [obs], sample_host.id)
        db_session.commit()

        rows = (
            db_session.execute(
                select(ResourceSnapshot).where(
                    ResourceSnapshot.host_id == sample_host.id
                )
            )
            .scalars()
            .all()
        )
        assert len(rows) == 1

    def test_resources_api_event_projection_fallback(
        self,
        client: TestClient,
        db_session: Session,
        sample_host: Host,
        auth_headers: dict[str, str],
    ) -> None:
        """When resource_snapshots is empty, /api/resources derives from events."""
        # Insert resource.snapshot event into events table
        ev = Event(
            id=uuid.uuid4(),
            host_id=sample_host.id,
            timestamp=utcnow(),
            source="resource",
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            payload={
                "cpu_percent": 42.5,
                "memory_total": 16000000000,
                "memory_used": 8000000000,
                "memory_percent": 50.0,
                "disk_usage_percent": 60.0,
            },
            created_at=utcnow(),
        )
        db_session.add(ev)
        db_session.commit()

        # Verify resource_snapshots is empty
        assert db_session.execute(select(ResourceSnapshot)).scalars().first() is None

        # Call /api/resources
        resp = client.get(
            f"/api/resources?host_id={sample_host.id}", headers=auth_headers
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        item = data["items"][0]
        assert item["cpu_percent"] == 42.5
        assert item["memory_percent"] == 50.0
        assert item["disk_usage_percent"] == 60.0
