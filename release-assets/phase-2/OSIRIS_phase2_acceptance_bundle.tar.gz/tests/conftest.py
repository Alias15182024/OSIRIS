from __future__ import annotations

"""Shared pytest fixtures for OSIRIS database tests.

Uses a dedicated test database (SQLite in-memory for unit tests, or a
PostgreSQL test database for integration tests controlled by environment).

The test database is created fresh for each test session and torn down after.
"""

from typing import Generator
import os
import uuid
from datetime import datetime, timezone

# Ensure safe test environment defaults for isolated bundle test runs
os.environ.setdefault("OSIRIS_DEBUG", "true")
os.environ.setdefault(
    "OSIRIS_SECRET_KEY", "acceptance-testing-key-32chars-minimum-length"
)

import pytest
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from backend.db.base import Base

# Import all models so they register with Base.metadata
import backend.db.models  # noqa: F401
from backend.db.models.host import Host
from backend.db.models.linux_user import LinuxUser
from backend.db.models.process import Process
from backend.db.models.app_user import AppUser


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


# Fixed UUIDs for reproducible test fixtures
TEST_HOST_ID = uuid.UUID("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa")
TEST_ROOT_USER_ID = uuid.UUID("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbb01")
TEST_REGULAR_USER_ID = uuid.UUID("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbb02")
TEST_PROCESS_ID = uuid.UUID("cccccccc-cccc-4ccc-8ccc-cccccccccccc")
TEST_APP_USER_ID = uuid.UUID("dddddddd-dddd-4ddd-8ddd-dddddddddddd")
CONTRACT_ADMIN_USER_ID = uuid.UUID("00000000-0000-4000-8000-000000000100")

PROTECTED_DATABASES: frozenset[str] = frozenset(
    {
        "osiris",
        "osiris_dev",
        "osiris_desktop_dev",
        "osiris_l1_validation_d4daacd",
    }
)
MAINTENANCE_DATABASES: frozenset[str] = frozenset({"postgres", "template1"})


def _create_session_pg_db(admin_url: object, db_name: str) -> None:
    """Create a dedicated session database using the administrative connection."""
    import os
    import subprocess

    created = False
    err_msg = ""
    try:
        admin_engine = create_engine(str(admin_url), isolation_level="AUTOCOMMIT")
        with admin_engine.connect() as conn:
            conn.execute(text(f'CREATE DATABASE "{db_name}"'))
        admin_engine.dispose()
        created = True
    except Exception as exc:
        err_msg = str(exc)

    if not created:
        try:
            env = os.environ.copy()
            pw = getattr(admin_url, "password", None)
            host = getattr(admin_url, "host", None)
            port = getattr(admin_url, "port", None)
            user = getattr(admin_url, "username", None)
            if pw:
                env["PGPASSWORD"] = pw
            cmd = ["createdb"]
            if host:
                cmd.extend(["-h", host])
            if port:
                cmd.extend(["-p", str(port)])
            if user:
                cmd.extend(["-U", user])
            cmd.append(db_name)
            res = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if res.returncode == 0:
                created = True
            else:
                err_msg = res.stderr.strip()
        except Exception:
            pass

    if not created:
        raise RuntimeError(
            f"Failed to create dedicated PostgreSQL session database "
            f"'{db_name}': {err_msg}"
        )


def _drop_session_pg_db(admin_url: object, db_name: str) -> None:
    """Terminate connections and drop the dedicated session database."""
    import os
    import subprocess

    dropped = False
    try:
        admin_engine = create_engine(str(admin_url), isolation_level="AUTOCOMMIT")
        with admin_engine.connect() as conn:
            conn.execute(
                text(
                    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                    "WHERE datname = :dbname AND pid <> pg_backend_pid()"
                ),
                {"dbname": db_name},
            )
            conn.execute(text(f'DROP DATABASE IF EXISTS "{db_name}"'))
        admin_engine.dispose()
        dropped = True
    except Exception:
        pass

    if not dropped:
        try:
            env = os.environ.copy()
            pw = getattr(admin_url, "password", None)
            host = getattr(admin_url, "host", None)
            port = getattr(admin_url, "port", None)
            user = getattr(admin_url, "username", None)
            if pw:
                env["PGPASSWORD"] = pw
            cmd = ["dropdb", "--if-exists"]
            if host:
                cmd.extend(["-h", host])
            if port:
                cmd.extend(["-p", str(port)])
            if user:
                cmd.extend(["-U", user])
            cmd.append(db_name)
            subprocess.run(cmd, env=env, capture_output=True)
        except Exception:
            pass


@pytest.fixture(scope="session")
def db_engine():
    """Create a test database engine.

    Uses SQLite in-memory for fast unit tests. For full PostgreSQL
    integration tests, set OSIRIS_TEST_DATABASE_URL in the environment.

    Safety invariants:
    - Never creates tables or modifies maintenance databases (postgres, template1).
    - Never connects to or modifies protected application databases.
    - When pointing to an administrative maintenance database, automatically
      creates a dedicated disposable session database (osiris_test_session_<hex>)
      and drops it at teardown.
    """
    import os

    from sqlalchemy.engine import make_url

    test_url_str = os.environ.get("OSIRIS_TEST_DATABASE_URL")
    created_session_db: str | None = None
    admin_url: object | None = None

    if test_url_str:
        url = make_url(test_url_str)
        target_db = url.database or "postgres"

        if target_db in PROTECTED_DATABASES:
            raise RuntimeError(
                f"Refusing to run tests against protected database: {target_db}"
            )

        connect_args = {}
        if url.drivername.startswith("postgresql"):
            connect_args = {"options": "-c timezone=utc"}

        is_pg = url.drivername.startswith("postgresql")
        if is_pg and target_db in MAINTENANCE_DATABASES:
            # Do NOT create application tables in maintenance databases.
            # Instead, create a dedicated session-scoped test database.
            created_session_db = f"osiris_test_session_{uuid.uuid4().hex[:12]}"
            admin_url = url.set(database=target_db)
            session_db_url = url.set(database=created_session_db)

            _create_session_pg_db(admin_url, created_session_db)
            eng = create_engine(
                str(session_db_url), echo=False, connect_args=connect_args
            )
        else:
            eng = create_engine(test_url_str, echo=False, connect_args=connect_args)
    else:
        eng = create_engine("sqlite:///:memory:", echo=False)
        # Enable foreign key enforcement in SQLite
        @event.listens_for(eng, "connect")
        def set_sqlite_pragma(dbapi_conn, connection_record):  # type: ignore[no-untyped-def]
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    # Create all tables
    Base.metadata.create_all(eng)

    yield eng

    # Cleanup
    try:
        Base.metadata.drop_all(eng)
    except Exception:
        pass
    eng.dispose()

    if created_session_db and admin_url:
        _drop_session_pg_db(admin_url, created_session_db)


@pytest.fixture(scope="function")
def db_session(db_engine):
    """Provide a transactional database session for a test.

    Each test runs in a transaction that is rolled back after the test,
    ensuring test isolation.
    """
    connection = db_engine.connect()
    transaction = connection.begin()
    session = Session(bind=connection, join_transaction_mode="create_savepoint")

    yield session

    session.close()
    if transaction.is_active:
        transaction.rollback()
    connection.close()


@pytest.fixture
def sample_host(db_session: Session) -> Host:
    """Create and return a sample host."""
    now = utcnow()
    host = Host(
        id=TEST_HOST_ID,
        hostname="test-host",
        os_info="Ubuntu 22.04",
        ip_address="10.0.0.1",
        created_at=now,
    )
    db_session.add(host)
    db_session.flush()
    return host


@pytest.fixture
def sample_linux_users(db_session: Session, sample_host: Host) -> dict:
    """Create and return sample Linux users keyed by name."""
    now = utcnow()
    root = LinuxUser(
        id=TEST_ROOT_USER_ID,
        host_id=sample_host.id,
        uid=0,
        username="root",
        first_seen_at=now,
        created_at=now,
    )
    student = LinuxUser(
        id=TEST_REGULAR_USER_ID,
        host_id=sample_host.id,
        uid=1000,
        username="student",
        first_seen_at=now,
        created_at=now,
    )
    db_session.add_all([root, student])
    db_session.flush()
    return {"root": root, "student": student}


@pytest.fixture
def sample_process(
    db_session: Session,
    sample_host: Host,
    sample_linux_users: dict,
) -> Process:
    """Create and return a sample process."""
    now = utcnow()
    proc = Process(
        id=TEST_PROCESS_ID,
        host_id=sample_host.id,
        pid=1,
        ppid=0,
        command="/sbin/init",
        executable="/sbin/init",
        linux_user_id=sample_linux_users["root"].id,
        started_at=now,
        created_at=now,
    )
    db_session.add(proc)
    db_session.flush()
    return proc


@pytest.fixture
def sample_app_user(db_session: Session) -> AppUser:
    """Create and return a sample application user."""
    now = utcnow()
    user = AppUser(
        id=TEST_APP_USER_ID,
        username="testadmin",
        password_hash="$2b$12$TEST_HASH_NOT_REAL",
        display_name="Test Admin",
        role="admin",
        is_active=True,
        created_at=now,
    )
    db_session.add(user)
    db_session.flush()
    return user


@pytest.fixture
def sample_event() -> dict:
    """Provide a minimal sample event for testing."""
    return {
        "event_id": "test-0001",
        "host_id": "test-host",
        "timestamp": "2026-01-01T00:00:00Z",
        "source": "test",
        "event_type": "test.sample",
        "action": "test",
        "severity": "info",
    }


@pytest.fixture
def contract_db_session() -> Generator[Session, None, None]:
    """Provide an isolated, thread-safe in-memory SQLite database session for contract tests.

    Creates all tables from Base.metadata, enables SQLite foreign keys, and seeds
    the minimal required active admin user expected by contract test authentication.
    Cleans up and disposes the schema and engine safely after each test.
    """
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):  # type: ignore[no-untyped-def]
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    session = Session(engine)

    try:
        admin_user = AppUser(
            id=CONTRACT_ADMIN_USER_ID,
            username="admin",
            password_hash="$2b$12$TEST_HASH_NOT_REAL",
            display_name="OSIRIS Administrator",
            role="admin",
            is_active=True,
            created_at=utcnow(),
        )
        session.add(admin_user)
        session.commit()

        yield session
    finally:
        session.close()
        try:
            Base.metadata.drop_all(engine)
        finally:
            engine.dispose()
