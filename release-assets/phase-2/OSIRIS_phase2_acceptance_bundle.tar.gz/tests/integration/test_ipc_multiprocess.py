"""Integration test for cross-process IPC and real-time WebSocket broadcast.

Verifies end-to-end multi-process interaction:
1. Spawns FastAPI backend with Uvicorn in a separate OS process.
2. Connects a real WebSocket client to ws://127.0.0.1:{port}/ws over TCP.
3. Authenticates via first-message handshake protocol.
4. Subscribes client to target host telemetry.
5. In parent process, persists Event to shared DB and emits notification
   over IPC Unix domain socket.
6. Asserts WebSocket client receives the hydrated event payload.
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pytest
import websockets.sync.client
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from backend.db.base import Base
from backend.db.models.app_user import AppUser
from backend.db.models.event import Event
from backend.db.models.host import Host
from backend.services.events.ipc_broadcast import send_ipc_notification


def get_free_port() -> int:
    """Find an available ephemeral port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_for_server(url: str, timeout: float = 10.0) -> bool:
    """Poll health endpoint until server responds or timeout expires."""
    start = time.time()
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen(url, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            time.sleep(0.1)
    return False


@pytest.fixture
def multiprocess_env(tmp_path: Path):
    """Set up shared database, IPC socket, and isolated backend environment."""
    port = get_free_port()
    db_file = tmp_path / "ipc_multiprocess.db"
    sock_path = Path(f"/tmp/osiris_test_ipc_{port}.sock")
    db_url = f"sqlite:///{db_file}"

    # Initialize shared database schema
    engine = create_engine(db_url, connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    session_factory = sessionmaker(bind=engine)

    # Seed an admin user for authentication
    session = session_factory()
    user_id = uuid.uuid4()
    # SHA-256 / PBKDF2 hash for password 'Secret123!'
    from backend.api.security import hash_password

    user = AppUser(
        id=user_id,
        username="ipc_tester",
        password_hash=hash_password("Secret123!"),
        role="admin",
        is_active=True,
        created_at=datetime.now(timezone.utc),
    )
    host_id = uuid.UUID("77777777-8888-4999-a000-bbbbbbbbbbbb")
    host = Host(
        id=host_id,
        hostname="ipc-prod-host",
        created_at=datetime.now(timezone.utc),
    )
    session.add(user)
    session.add(host)
    session.commit()
    session.close()

    env = {
        **os.environ,
        "OSIRIS_DATABASE_URL": db_url,
        "DATABASE_URL": db_url,
        "OSIRIS_IPC_SOCK": str(sock_path),
        "OSIRIS_SECRET_KEY": "a" * 64,
        "SECRET_KEY": "a" * 64,
        "PYTHONPATH": str(Path(__file__).resolve().parent.parent.parent),
    }

    # Spawn FastAPI/Uvicorn server as a separate OS process
    cmd = [
        sys.executable,
        "-m",
        "uvicorn",
        "backend.main:app",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--log-level",
        "warning",
    ]
    proc = subprocess.Popen(
        cmd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    health_url = f"http://127.0.0.1:{port}/health"
    ready = wait_for_server(health_url, timeout=12.0)
    if not ready:
        proc.kill()
        out, err = proc.communicate()
        fail_msg = (
            f"Backend failed to start within timeout.\n"
            f"STDOUT: {out.decode()}\nSTDERR: {err.decode()}"
        )
        pytest.fail(fail_msg)

    yield {
        "port": port,
        "sock_path": sock_path,
        "engine": engine,
        "session_maker": session_factory,
        "host_id": host_id,
    }

    # Teardown: terminate backend process
    proc.terminate()
    try:
        proc.wait(timeout=5.0)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait()
    engine.dispose()


class TestIpcMultiprocess:
    """Verify cross-process IPC communication and WebSocket telemetry hydration."""

    def test_cross_process_event_broadcast_and_hydration(
        self, multiprocess_env: dict
    ) -> None:
        port = multiprocess_env["port"]
        sock_path = multiprocess_env["sock_path"]
        session_maker = multiprocess_env["session_maker"]
        host_id = multiprocess_env["host_id"]

        # 1. Login via HTTP to obtain access token
        login_payload = json.dumps(
            {
                "username": "ipc_tester",
                "password": "Secret123!",
            }
        ).encode("utf-8")
        login_req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/auth/login",
            data=login_payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(login_req) as login_resp:
            login_data = json.loads(login_resp.read().decode("utf-8"))
            access_token = login_data["access_token"]

        # 2. Obtain single-use WebSocket ticket
        ticket_req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/auth/ws-ticket",
            headers={"Authorization": f"Bearer {access_token}"},
            method="POST",
        )
        with urllib.request.urlopen(ticket_req) as ticket_resp:
            ticket_data = json.loads(ticket_resp.read().decode("utf-8"))
            ws_ticket = ticket_data["ticket"]

        # 3. Connect real WebSocket client over TCP
        ws_url = f"ws://127.0.0.1:{port}/ws"
        with websockets.sync.client.connect(ws_url, close_timeout=2.0) as ws:
            # Perform first-message handshake authentication
            ws.send(json.dumps({"action": "authenticate", "ticket": ws_ticket}))
            ack_raw = ws.recv(timeout=5.0)
            ack = json.loads(ack_raw)
            assert ack.get("type") == "authenticated"

            # Subscribe to the target host
            ws.send(json.dumps({"action": "subscribe", "host_id": str(host_id)}))
            sub_raw = ws.recv(timeout=5.0)
            sub = json.loads(sub_raw)
            assert sub.get("type") == "subscribed"
            assert sub.get("host_id") == str(host_id)

            # 4. In test process, persist event to shared DB
            event_id = uuid.uuid4()
            now = datetime.now(timezone.utc)
            session = session_maker()
            test_event = Event(
                id=event_id,
                host_id=host_id,
                timestamp=now,
                ingested_at=now,
                source="proc",
                event_type="proc:start",
                action="execute",
                severity="info",
                uid=1000,
                username="analyst_ipc",
                pid=5544,
                command="/usr/bin/ipc_probe --active",
            )
            session.add(test_event)
            session.commit()
            session.close()

            # 5. Emit compact wake-up notification over IPC Unix domain socket
            # Point OSIRIS_IPC_SOCK to the socket being served by backend process
            os.environ["OSIRIS_IPC_SOCK"] = str(sock_path)
            delivered = send_ipc_notification(
                {
                    "type": "event",
                    "id": str(event_id),
                    "host_id": str(host_id),
                }
            )
            assert delivered is True, "IPC socket notification was not delivered"

            # 6. WebSocket client must receive hydrated event from backend
            received_raw = ws.recv(timeout=5.0)
            received = json.loads(received_raw)

            assert received.get("type") == "event"
            assert received.get("host_id") == str(host_id)
            event_data = received.get("data", {})
            assert event_data.get("id") == str(event_id)
            assert event_data.get("command") == "/usr/bin/ipc_probe --active"
            assert event_data.get("username") == "analyst_ipc"
