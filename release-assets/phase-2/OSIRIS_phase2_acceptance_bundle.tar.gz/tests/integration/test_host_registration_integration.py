"""Integration tests for automatic local-host registration on startup.

Verifies:
1. Collector startup automatically creates the expected Host record on a fresh
   disposable database with NO Host records.
2. The Host UUID exactly matches `resolve_host_uuid(OSIRIS_HOST_ID)`.
3. The first collector cycle persists events successfully without foreign
   key violations.
4. Process and resource records can be persisted without pre-existing seed data.
5. Filesystem records remain host-scoped.
6. Repeated registration does not create duplicate hosts.
7. Existing Host metadata is preserved (administrator-maintained fields are
   not overwritten).
8. Database foreign key violations do not occur across users, processes,
   files, and events.
9. Different host identifiers remain strictly isolated.
10. Seed data is not required for live collector operation.
11. Concurrent registration across threads/sessions is safe and race-free.
12. Registration failures are logged and do not mark collection as healthy.
"""

from __future__ import annotations

import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from sqlalchemy import create_engine, event, func, select
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import NullPool, StaticPool

from backend.config import settings
from backend.db.base import Base
from backend.db.models.event import Event
from backend.db.models.file import File
from backend.db.models.host import Host
from backend.db.models.linux_user import LinuxUser
from backend.db.models.process import Process
from backend.db.models.resource_snapshot import ResourceSnapshot
from backend.services.events.host_registration import (
    HostRegistrationService,
    get_system_hostname,
    get_system_os_info,
)
from backend.services.events.resolver import resolve_host_uuid
from backend.services.events.schemas import RawObservation
from collectors.filesystem.inotify import MockInotifyBackend
from collectors.orchestrator import (
    CollectorOrchestrator,
    OrchestratorConfig,
)
from collectors.runner import CollectorRunner
from collectors.supervisor import CollectorSupervisor


@pytest.fixture
def fresh_engine():
    """Create a completely clean, isolated engine with foreign keys enabled."""
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def fresh_session(fresh_engine) -> Session:
    """Create a direct session against fresh_engine with NO Host records."""
    session_cls = sessionmaker(bind=fresh_engine, autoflush=False, autocommit=False)
    session = session_cls()

    # Precondition assertion: fresh disposable database must have zero Host records
    count = session.scalar(select(func.count(Host.id)))
    assert count == 0, "fresh_session must start with 0 Host records"

    yield session
    session.close()


@pytest.fixture
def fresh_session_factory(fresh_engine):
    """Return a session factory creating sessions against the fresh engine."""
    return sessionmaker(bind=fresh_engine, autoflush=False, autocommit=False)


def make_test_orchestrator(
    config: OrchestratorConfig,
    *,
    session: Session | None = None,
    session_factory=None,
    proc_obs: list[RawObservation] | None = None,
    res_obs: list[RawObservation] | None = None,
    fs_obs: list[RawObservation] | None = None,
    user_provider=None,
) -> CollectorOrchestrator:
    """Construct an orchestrator with collectors stubbed for test isolation."""
    orch = CollectorOrchestrator(
        config,
        session=session,
        session_factory=session_factory,
    )
    orch.process_collector = MagicMock()
    orch.process_collector.collect_observations = MagicMock(return_value=proc_obs or [])
    orch.resource_collector = MagicMock()
    orch.resource_collector.collect_observations = MagicMock(return_value=res_obs or [])
    orch.filesystem_collector = MagicMock()
    orch.filesystem_collector.collect_observations = MagicMock(
        return_value=fs_obs or []
    )
    if user_provider is not None:
        orch.user_synchronizer.user_provider = user_provider
    return orch


# ============================================================================
# 1. AUTOMATIC HOST REGISTRATION & UUID RESOLUTION
# ============================================================================


class TestAutomaticHostRegistration:
    def test_collector_startup_creates_expected_host_record_and_canonical_uuid(
        self, fresh_session: Session
    ):
        """Verify collector creates Host record with exact canonical UUID."""
        host_identifier = "ubuntu-acceptance-host"
        expected_uuid = resolve_host_uuid(host_identifier)

        # Database starts with zero Host records
        assert fresh_session.scalar(select(func.count(Host.id))) == 0

        config = OrchestratorConfig(
            host_id=host_identifier,
            process_interval=1.0,
            resource_interval=1.0,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config,
            session=fresh_session,
            user_provider=lambda: [(1000, "ubuntu")],
        )

        assert orchestrator.host_uuid == expected_uuid

        # Execute first cycle
        result = orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        assert result.success is True

        # Verify host record in database
        host_record = fresh_session.get(Host, expected_uuid)
        assert host_record is not None
        assert host_record.id == expected_uuid
        assert host_record.hostname is not None
        assert len(host_record.hostname) > 0
        assert host_record.ip_address is None  # Never fabricate IP addresses
        assert host_record.created_at is not None

    def test_configured_osiris_hostname_respected(
        self, fresh_session: Session, monkeypatch: pytest.MonkeyPatch
    ):
        """Verify OSIRIS_HOSTNAME configuration populates Host.hostname."""
        monkeypatch.setenv("OSIRIS_HOSTNAME", "prod-acceptance-node-01")
        monkeypatch.setattr(settings, "hostname", "prod-acceptance-node-01")

        host_id = "test-custom-hostname-node"
        expected_uuid = resolve_host_uuid(host_id)

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config, session=fresh_session, user_provider=lambda: []
        )
        orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        host_record = fresh_session.get(Host, expected_uuid)
        assert host_record is not None
        assert host_record.hostname == "prod-acceptance-node-01"

    def test_os_info_populated_from_system(self, fresh_session: Session):
        """Verify operating system info is extracted from the local system."""
        host_id = "os-info-test-host"
        expected_uuid = resolve_host_uuid(host_id)

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config, session=fresh_session, user_provider=lambda: []
        )
        orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        host_record = fresh_session.get(Host, expected_uuid)
        assert host_record is not None
        expected_os = get_system_os_info()
        assert host_record.os_info == expected_os


# ============================================================================
# 2. FIRST CYCLE PERSISTENCE & FOREIGN KEY INTEGRITY WITHOUT SEEDS
# ============================================================================


class TestPersistenceWithoutSeedData:
    def test_first_collector_cycle_persists_events_successfully(
        self, fresh_session: Session
    ):
        """Verify first cycle persists events on fresh DB without FK violations."""
        host_id = "ubuntu-acceptance-host"
        expected_uuid = resolve_host_uuid(host_id)

        now = datetime.now(timezone.utc)
        test_obs = RawObservation(
            source="proc",
            host_id=expected_uuid,
            event_type="process.start",
            action="start",
            severity="info",
            observed_at=now,
            pid=4567,
            ppid=1,
            command="/usr/bin/acceptance-agent",
            uid=1000,
            payload={"executable": "/usr/bin/acceptance-agent"},
        )

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config,
            session=fresh_session,
            proc_obs=[test_obs],
            user_provider=lambda: [(1000, "ubuntu")],
        )

        result = orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        assert result.success is True
        assert len(result.events) >= 1

        persisted_events = (
            fresh_session.execute(
                select(Event).where(Event.host_id == expected_uuid)
            )
            .scalars()
            .all()
        )
        assert len(persisted_events) >= 1
        assert persisted_events[0].host_id == expected_uuid

    def test_process_and_resource_records_persisted(
        self, fresh_session: Session
    ):
        """Verify process and resource tables are populated with valid Host FK."""
        host_id = "telemetry-acceptance-host"
        expected_uuid = resolve_host_uuid(host_id)
        now = datetime.now(timezone.utc)

        proc_obs = RawObservation(
            source="proc",
            host_id=expected_uuid,
            event_type="process.start",
            action="start",
            severity="info",
            observed_at=now,
            pid=8888,
            ppid=1,
            command="/usr/sbin/daemon-proc",
            uid=0,
            payload={"executable": "/usr/sbin/daemon-proc"},
        )

        res_obs = RawObservation(
            source="resource",
            host_id=expected_uuid,
            event_type="resource.snapshot",
            action="snapshot",
            severity="info",
            observed_at=now,
            payload={
                "cpu_percent": 12.5,
                "memory_total": 16 * 1024 * 1024 * 1024,
                "memory_used": 8 * 1024 * 1024 * 1024,
                "disk_total": 100 * 1024 * 1024 * 1024,
                "disk_used": 40 * 1024 * 1024 * 1024,
            },
        )

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config,
            session=fresh_session,
            proc_obs=[proc_obs],
            res_obs=[res_obs],
            user_provider=lambda: [(0, "root"), (1000, "ubuntu")],
        )

        result = orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        assert result.success is True

        # Verify linux users persisted
        users = (
            fresh_session.execute(
                select(LinuxUser).where(LinuxUser.host_id == expected_uuid)
            )
            .scalars()
            .all()
        )
        assert len(users) == 2

        # Verify processes persisted
        procs = (
            fresh_session.execute(
                select(Process).where(Process.host_id == expected_uuid)
            )
            .scalars()
            .all()
        )
        assert len(procs) == 1
        assert procs[0].pid == 8888
        assert procs[0].host_id == expected_uuid

        # Verify resource snapshots persisted
        snaps = (
            fresh_session.execute(
                select(ResourceSnapshot).where(
                    ResourceSnapshot.host_id == expected_uuid
                )
            )
            .scalars()
            .all()
        )
        assert len(snaps) == 1
        assert snaps[0].host_id == expected_uuid
        assert snaps[0].cpu_percent == 12.5

    def test_filesystem_records_remain_host_scoped(
        self, fresh_session: Session
    ):
        """Verify filesystem inventory records are created and scoped to Host."""
        host_id = "fs-scope-acceptance-host"
        expected_uuid = resolve_host_uuid(host_id)
        now = datetime.now(timezone.utc)

        fs_obs = RawObservation(
            source="fs",
            host_id=expected_uuid,
            event_type="filesystem.create",
            action="create",
            severity="info",
            observed_at=now,
            object_path="/etc/osiris/custom.conf",
            object_type="file",
            payload={
                "inode": 123456,
                "size_bytes": 512,
                "sha256": (
                    "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
                ),
            },
        )

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config,
            session=fresh_session,
            fs_obs=[fs_obs],
            user_provider=lambda: [],
        )

        result = orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        assert result.success is True

        files = (
            fresh_session.execute(
                select(File).where(File.host_id == expected_uuid)
            )
            .scalars()
            .all()
        )
        assert len(files) == 1
        assert files[0].path == "/etc/osiris/custom.conf"
        assert files[0].host_id == expected_uuid



# ============================================================================
# 3. IDEMPOTENCY, PRESERVATION & ISOLATION
# ============================================================================


class TestIdempotencyAndIsolation:
    def test_repeated_registration_does_not_create_duplicate_hosts(
        self, fresh_session: Session
    ):
        """Verify repeated cycles or registration never produce duplicate hosts."""
        host_id = "repeated-reg-host"
        expected_uuid = resolve_host_uuid(host_id)

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config, session=fresh_session, user_provider=lambda: []
        )

        # Run 5 cycles
        for _ in range(5):
            res = orchestrator.run_cycle(force_all=True)
            assert res.success is True
            fresh_session.commit()

        count = fresh_session.scalar(
            select(func.count(Host.id)).where(Host.id == expected_uuid)
        )
        assert count == 1

    def test_existing_host_metadata_is_preserved(self, fresh_session: Session):
        """Verify valid admin-maintained metadata is never overwritten."""
        host_id = "admin-preserved-host"
        expected_uuid = resolve_host_uuid(host_id)

        # Pre-seed an administrator-maintained host
        admin_host = Host(
            id=expected_uuid,
            hostname="custom-admin-name",
            os_info="Hardened Linux 6.1 Enterprise",
            ip_address="198.51.100.42",
            created_at=datetime.now(timezone.utc),
        )
        fresh_session.add(admin_host)
        fresh_session.commit()

        # Run collector cycle
        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = make_test_orchestrator(
            config, session=fresh_session, user_provider=lambda: []
        )
        result = orchestrator.run_cycle(force_all=True)
        fresh_session.commit()

        assert result.success is True

        refreshed = fresh_session.get(Host, expected_uuid)
        assert refreshed is not None
        assert refreshed.hostname == "custom-admin-name"
        assert refreshed.os_info == "Hardened Linux 6.1 Enterprise"
        assert refreshed.ip_address == "198.51.100.42"

    def test_different_host_identifiers_remain_isolated(
        self, fresh_session: Session
    ):
        """Verify distinct host identifiers create distinct, isolated records."""
        host_a = "cluster-node-alpha"
        host_b = "cluster-node-beta"
        uuid_a = resolve_host_uuid(host_a)
        uuid_b = resolve_host_uuid(host_b)

        assert uuid_a != uuid_b

        # Cycle on Host A
        cfg_a = OrchestratorConfig(
            host_id=host_a,
            fs_backend=MockInotifyBackend(),
        )
        orch_a = make_test_orchestrator(
            cfg_a, session=fresh_session, user_provider=lambda: [(1001, "user_alpha")]
        )
        orch_a.run_cycle(force_all=True)
        fresh_session.commit()

        # Cycle on Host B
        cfg_b = OrchestratorConfig(
            host_id=host_b,
            fs_backend=MockInotifyBackend(),
        )
        orch_b = make_test_orchestrator(
            cfg_b, session=fresh_session, user_provider=lambda: [(1002, "user_beta")]
        )
        orch_b.run_cycle(force_all=True)
        fresh_session.commit()

        # Both hosts exist
        rec_a = fresh_session.get(Host, uuid_a)
        rec_b = fresh_session.get(Host, uuid_b)
        assert rec_a is not None and rec_b is not None
        assert rec_a.id != rec_b.id

        # Users isolated
        users_a = (
            fresh_session.execute(
                select(LinuxUser).where(LinuxUser.host_id == uuid_a)
            )
            .scalars()
            .all()
        )
        users_b = (
            fresh_session.execute(
                select(LinuxUser).where(LinuxUser.host_id == uuid_b)
            )
            .scalars()
            .all()
        )
        assert len(users_a) == 1 and users_a[0].username == "user_alpha"
        assert len(users_b) == 1 and users_b[0].username == "user_beta"


# ============================================================================
# 4. CONCURRENCY & ERROR HANDLING
# ============================================================================


class TestConcurrencyAndErrorHandling:
    def test_concurrent_registration_is_safe(self, tmp_path: Path):
        """Verify concurrent registration attempts across threads safely converge."""
        db_file = tmp_path / "concurrent_test.db"
        engine = create_engine(
            f"sqlite:///{db_file}",
            poolclass=NullPool,
            connect_args={"timeout": 15},
        )
        Base.metadata.create_all(engine)

        session_cls = sessionmaker(bind=engine, autoflush=False, autocommit=False)
        host_id = "concurrent-startup-node"
        expected_uuid = resolve_host_uuid(host_id)

        service = HostRegistrationService()
        errors: list[Exception] = []

        def worker():
            sess = session_cls()
            try:
                service.register_or_get_host(sess, host_id)
                sess.commit()
            except Exception as e:
                sess.rollback()
                errors.append(e)
            finally:
                sess.close()

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent registration threw errors: {errors}"

        verify_session = session_cls()
        count = verify_session.scalar(
            select(func.count(Host.id)).where(Host.id == expected_uuid)
        )
        verify_session.close()
        engine.dispose()

        assert count == 1

    def test_registration_failure_logged_and_marks_cycle_unhealthy(
        self, fresh_session: Session
    ):
        """Verify registration failure records sink_error and marks cycle failed."""
        host_id = "fail-test-host"

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )

        failing_service = HostRegistrationService()
        failing_service.register_or_get_host = MagicMock(
            side_effect=RuntimeError(
                "Database connectivity failed during host registration"
            )
        )

        orchestrator = CollectorOrchestrator(
            config,
            session=fresh_session,
            host_registration_service=failing_service,
        )

        result = orchestrator.run_cycle(force_all=True)

        assert result.success is False
        assert "host_registration" in result.sink_errors
        assert "Database connectivity failed" in result.sink_errors["host_registration"]


# ============================================================================
# 5. RUNNER & SUPERVISOR LIVE STARTUP ON EMPTY DB
# ============================================================================


class TestRunnerAndSupervisorStartupOnFreshDb:
    def test_collector_runner_once_creates_host_record_on_fresh_db(
        self, fresh_session_factory
    ):
        """Verify CollectorRunner --once creates Host record and completes."""
        host_id = "runner-acceptance-host"
        expected_uuid = resolve_host_uuid(host_id)

        runner = CollectorRunner(
            once=True,
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
            session_factory=fresh_session_factory,
        )
        runner.orchestrator.user_synchronizer = None
        runner.orchestrator.process_lifecycle_service = None

        exit_code = runner.run()
        assert exit_code == 0
        assert runner.cycle_count == 1

        sess = fresh_session_factory()
        host = sess.get(Host, expected_uuid)
        sess.close()

        assert host is not None
        assert host.id == expected_uuid

    def test_collector_supervisor_creates_host_record_on_fresh_db(
        self, fresh_session_factory, tmp_path: Path
    ):
        """Verify Supervisor runs 1 cycle, creates Host record, writes health."""
        host_id = "supervisor-acceptance-host"
        expected_uuid = resolve_host_uuid(host_id)

        pid_file = tmp_path / "supervisor_test.pid"
        health_file = tmp_path / "supervisor_health.json"

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
            user_provider=lambda: [],
        )
        supervisor = CollectorSupervisor(
            config=config,
            pid_file=pid_file,
            health_file=health_file,
            session_factory=fresh_session_factory,
            interval=0.1,
        )

        code = supervisor.start(watch=False, cycles=1)
        assert code == 0

        sess = fresh_session_factory()
        host = sess.get(Host, expected_uuid)
        sess.close()

        assert host is not None
        assert host.id == expected_uuid
        assert health_file.exists()

    def test_ensure_host_registered_creates_record_on_fresh_db(
        self, fresh_session_factory
    ):
        """Verify orchestrator.ensure_host_registered() registers Host on fresh DB."""
        host_id = "orchestrator-startup-host"
        expected_uuid = resolve_host_uuid(host_id)

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
        )
        orchestrator = CollectorOrchestrator(
            config,
            session_factory=fresh_session_factory,
        )

        host = orchestrator.ensure_host_registered()
        assert host is not None
        assert host.id == expected_uuid

        sess = fresh_session_factory()
        persisted = sess.get(Host, expected_uuid)
        sess.close()

        assert persisted is not None
        assert persisted.id == expected_uuid
        assert persisted.hostname is not None
        assert persisted.ip_address is None

    def test_registration_failure_marks_supervisor_health_unhealthy(
        self, fresh_session_factory, tmp_path: Path
    ):
        """Verify supervisor health file records healthy=False on registration error."""
        import json

        host_id = "fail-supervisor-host"
        pid_file = tmp_path / "fail_supervisor.pid"
        health_file = tmp_path / "fail_health.json"

        config = OrchestratorConfig(
            host_id=host_id,
            fs_backend=MockInotifyBackend(),
            user_provider=lambda: [],
        )
        supervisor = CollectorSupervisor(
            config=config,
            pid_file=pid_file,
            health_file=health_file,
            session_factory=fresh_session_factory,
            interval=0.1,
        )
        failing_service = HostRegistrationService()
        failing_service.register_or_get_host = MagicMock(
            side_effect=RuntimeError("Host registration failed during cycle")
        )
        supervisor.orchestrator.host_registration_service = failing_service

        # Avoid failing in start() so we test the run_cycle health propagation
        supervisor.orchestrator._host_registered = False

        res = supervisor.orchestrator.run_cycle(force_all=True)
        assert res.success is False
        assert "host_registration" in res.sink_errors

        supervisor.write_health_status()
        assert health_file.exists()

        health_data = json.loads(health_file.read_text(encoding="utf-8"))
        assert health_data["healthy"] is False
        assert "host_registration" in health_data.get("sink_errors", {})


# ============================================================================
# 6. EDGE CASES & BOUNDARY VALUE VALIDATION
# ============================================================================


class TestHostRegistrationEdgeCases:
    def test_hostname_truncation_boundary(self, fresh_session: Session):
        """Verify hostnames exceeding 255 characters are safely truncated."""
        long_hostname = "a" * 300
        service = HostRegistrationService()
        host = service.register_or_get_host(
            fresh_session,
            "truncation-host-id",
            hostname=long_hostname,
        )
        fresh_session.commit()
        assert len(host.hostname) == 255
        assert host.hostname == "a" * 255

    def test_os_info_truncation_boundary(self, fresh_session: Session):
        """Verify os_info exceeding 512 characters is safely truncated."""
        long_os_info = "Linux " + ("kernel-version-" * 40)
        service = HostRegistrationService()
        host = service.register_or_get_host(
            fresh_session,
            "truncation-os-host-id",
            os_info=long_os_info,
        )
        fresh_session.commit()
        assert len(host.os_info) == 512

    def test_empty_or_whitespace_hostname_fallback(self):
        """Verify empty or whitespace configured hostname falls back to system."""
        h1 = get_system_hostname("")
        h2 = get_system_hostname("   ")
        assert len(h1) > 0 and h1 != ""
        assert len(h2) > 0 and h2 != ""

    def test_existing_host_with_empty_hostname_is_repaired(
        self, fresh_session: Session
    ):
        """Verify if an existing host has empty hostname, it gets populated."""
        target_uuid = uuid.uuid4()
        existing = Host(
            id=target_uuid,
            hostname="",
            os_info="Linux Test",
            ip_address="10.0.0.1",
            created_at=datetime.now(timezone.utc),
        )
        fresh_session.add(existing)
        fresh_session.commit()

        service = HostRegistrationService()
        repaired = service.register_or_get_host(
            fresh_session,
            target_uuid,
            hostname="repaired-host",
        )
        fresh_session.commit()

        assert repaired.hostname == "repaired-host"
        assert repaired.ip_address == "10.0.0.1"  # IP preserved
        assert repaired.os_info == "Linux Test"    # OS info preserved

    def test_in_memory_mode_no_database(self):
        """Verify in-memory mode without session or factory returns None cleanly."""
        config = OrchestratorConfig(
            host_id="in-memory-host",
            fs_backend=MockInotifyBackend(),
            session_factory=None,
        )
        orchestrator = CollectorOrchestrator(
            config,
            session=None,
            session_factory=None,
        )
        res = orchestrator.ensure_host_registered()
        assert res is None

        # Cycle in in-memory mode runs without DB error
        orchestrator.process_collector = MagicMock()
        orchestrator.process_collector.collect_observations.return_value = []
        orchestrator.resource_collector = MagicMock()
        orchestrator.resource_collector.collect_observations.return_value = []
        orchestrator.filesystem_collector = MagicMock()
        orchestrator.filesystem_collector.collect_observations.return_value = []

        cycle_res = orchestrator.run_cycle(force_all=True)
        assert cycle_res.success is True

    def test_uuid_resolution_formats(self):
        """Verify canonical UUID generation across all host representation formats."""
        # UUID instance
        u = uuid.uuid4()
        assert resolve_host_uuid(u) == u

        # Hyphenated UUID string
        u_str = str(u)
        assert resolve_host_uuid(u_str) == u

        # Non-hyphenated hex string
        u_hex = u.hex
        assert resolve_host_uuid(u_hex) == u

        # Non-UUID hostname string (deterministic DNS namespace UUIDv5)
        host_name = "ubuntu-acceptance-host"
        res1 = resolve_host_uuid(host_name)
        res2 = resolve_host_uuid(f"  {host_name}  ")
        assert res1 == uuid.uuid5(uuid.NAMESPACE_DNS, host_name)
        assert res1 == res2

    def test_existing_host_with_empty_os_info_is_repaired(
        self, fresh_session: Session
    ):
        """Verify if an existing host has empty os_info, it gets populated."""
        target_uuid = uuid.uuid4()
        existing = Host(
            id=target_uuid,
            hostname="custom-admin-host",
            os_info="",
            ip_address="192.168.1.50",
            created_at=datetime.now(timezone.utc),
        )
        fresh_session.add(existing)
        fresh_session.commit()

        service = HostRegistrationService()
        repaired = service.register_or_get_host(
            fresh_session,
            target_uuid,
            os_info="Linux Repaired Kernel 6.8",
        )
        fresh_session.commit()

        assert repaired.hostname == "custom-admin-host"  # Hostname preserved
        assert repaired.ip_address == "192.168.1.50"    # IP preserved
        assert repaired.os_info == "Linux Repaired Kernel 6.8"

    def test_os_release_name_fallback(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ):
        """Verify parsing of /etc/os-release when PRETTY_NAME is missing."""
        fake_os_release = tmp_path / "os-release"
        fake_os_release.write_text("NAME=MinimalOS\nVERSION=1.0\n", encoding="utf-8")

        import backend.services.events.host_registration as hr_mod
        orig_path = hr_mod.Path

        def fake_path(p):
            if str(p) in ("/etc/os-release", "/usr/lib/os-release"):
                return fake_os_release
            return orig_path(p)

        monkeypatch.setattr(hr_mod, "Path", fake_path)
        if hasattr(hr_mod.platform, "freedesktop_os_release"):
            monkeypatch.setattr(
                hr_mod.platform,
                "freedesktop_os_release",
                MagicMock(side_effect=OSError),
            )

        os_info = get_system_os_info()
        assert os_info == "MinimalOS"


