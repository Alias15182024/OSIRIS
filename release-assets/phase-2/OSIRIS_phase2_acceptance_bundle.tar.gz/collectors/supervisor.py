"""Unified Collector Supervisor for OSIRIS.

Provides centralized management, single-instance enforcement (PID locking),
lifecycle monitoring, and health status reporting for all local collectors.
"""

from __future__ import annotations

import argparse
import atexit
import fcntl
import json
import logging
import os
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable

from sqlalchemy.orm import Session

from backend.config import settings
from collectors.filesystem.inotify import InotifyBackend, MockInotifyBackend
from collectors.orchestrator import (
    CollectorOrchestrator,
    OrchestratorConfig,
    OrchestratorState,
    resolve_host_uuid,
)

logger = logging.getLogger("osiris.collectors.supervisor")

DEFAULT_COLLECTOR_RUNTIME_DIR = "/run/osiris-collector"
DEFAULT_RUNTIME_DIR = DEFAULT_COLLECTOR_RUNTIME_DIR
DEFAULT_PID_FILE = "/run/osiris-collector/osiris_collector_supervisor.pid"
DEFAULT_HEALTH_FILE = "/run/osiris-collector/osiris_collector_health.json"


def get_default_runtime_dir() -> Path:
    """Resolve default collector runtime directory.

    In production: dedicated protected root-owned /run/osiris-collector directory.
    In development: private per-instance directory with mode 0700.
    """
    run_dir = Path(DEFAULT_COLLECTOR_RUNTIME_DIR)
    try:
        run_dir.mkdir(parents=True, exist_ok=True)
        if os.access(str(run_dir), os.W_OK):
            return run_dir
    except (PermissionError, OSError):
        pass

    from backend.services.events.ipc_broadcast import get_private_dev_runtime_dir

    return get_private_dev_runtime_dir()


def get_default_pid_file() -> Path:
    """Resolve default PID file path with secure fallback."""
    return get_default_runtime_dir() / "osiris_collector_supervisor.pid"


def get_default_health_file() -> Path:
    """Resolve default health status file path with secure fallback."""
    return get_default_runtime_dir() / "osiris_collector_health.json"


class SupervisorLockError(RuntimeError):
    """Raised when another collector supervisor instance is already running."""


class PIDLock:
    """Guarantees single supervisor instance execution using a secure file lock.

    Implements strict no-follow semantics (os.O_NOFOLLOW), regular file verification,
    UID ownership check via fstat, lock acquisition before truncation, and race-free
    inode verification during acquisition and release.
    """

    def __init__(self, pid_file: str | Path | None = None) -> None:
        if pid_file is None:
            self.pid_file = get_default_pid_file()
        else:
            self.pid_file = Path(pid_file)
        self._fd: int | None = None
        self._dev: int | None = None
        self._ino: int | None = None

    def acquire(self) -> None:
        """Acquire non-blocking exclusive lock or raise SupervisorLockError."""
        try:
            self.pid_file.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        try:
            if self.pid_file.is_symlink():
                raise SupervisorLockError(
                    f"PID file is a symlink (symlink attack prevented): {self.pid_file}"
                )
        except OSError as exc:
            raise SupervisorLockError(
                f"Cannot inspect PID file {self.pid_file}: {exc}"
            ) from exc

        flags = os.O_CREAT | os.O_RDWR
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW

        try:
            self._fd = os.open(str(self.pid_file), flags, 0o644)
        except OSError as exc:
            msg = (
                f"Failed to open PID file {self.pid_file} "
                f"(no-follow/permission check): {exc}"
            )
            raise SupervisorLockError(msg) from exc

        try:
            st = os.fstat(self._fd)
            import stat

            if not stat.S_ISREG(st.st_mode):
                raise SupervisorLockError(
                    f"PID file {self.pid_file} is not a regular file "
                    f"(mode: {oct(st.st_mode)})"
                )

            current_uid = os.geteuid()
            if st.st_uid != current_uid:
                raise SupervisorLockError(
                    f"PID file {self.pid_file} is owned by UID {st.st_uid}, "
                    f"but process runs as UID {current_uid}"
                )

            try:
                path_st = os.lstat(self.pid_file)
                if (path_st.st_dev, path_st.st_ino) != (st.st_dev, st.st_ino):
                    raise SupervisorLockError(
                        f"PID file {self.pid_file} replaced during acquisition"
                    )
            except OSError as exc:
                raise SupervisorLockError(
                    f"PID file {self.pid_file} unlinked during open: {exc}"
                ) from exc

            fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

            os.ftruncate(self._fd, 0)
            os.lseek(self._fd, 0, os.SEEK_SET)
            os.write(self._fd, f"{os.getpid()}\n".encode("ascii"))
            os.fsync(self._fd)
            self._dev = st.st_dev
            self._ino = st.st_ino

        except Exception as exc:
            if self._fd is not None:
                try:
                    fcntl.flock(self._fd, fcntl.LOCK_UN)
                except Exception:
                    pass
                try:
                    os.close(self._fd)
                except Exception:
                    pass
                self._fd = None
            if isinstance(exc, SupervisorLockError):
                raise
            msg = f"Another supervisor is running (PID lock: {self.pid_file})"
            raise SupervisorLockError(msg) from exc

    def release(self) -> None:
        """Release lock and safely remove PID file."""
        if self._fd is not None:
            try:
                if self._ino is not None and self.pid_file.exists():
                    try:
                        path_st = os.lstat(self.pid_file)
                        if (path_st.st_dev, path_st.st_ino) == (self._dev, self._ino):
                            self.pid_file.unlink(missing_ok=True)
                    except Exception:
                        pass
                fcntl.flock(self._fd, fcntl.LOCK_UN)
                os.close(self._fd)
            except Exception:
                pass
            self._fd = None
            self._dev = None
            self._ino = None


class CollectorSupervisor:
    """Central supervisor coordinating OSIRIS collector lifecycle and health status."""

    def __init__(
        self,
        config: OrchestratorConfig | None = None,
        *,
        pid_file: str | Path | None = None,
        health_file: str | Path | None = None,
        session_factory: Callable[[], Session] | None = None,
        session: Session | None = None,
        fs_backend: InotifyBackend | None = None,
        interval: float = 2.0,
    ) -> None:
        self.pid_lock = PIDLock(pid_file)
        self.health_file = (
            Path(health_file) if health_file is not None else get_default_health_file()
        )
        self.interval = interval
        self._stop_event = threading.Event()
        self._is_running = False

        # Resolve host ID
        host_uuid = resolve_host_uuid(config.host_id if config else settings.host_id)

        # Cross-platform inotify backend resolution
        effective_fs_backend = fs_backend
        if effective_fs_backend is None and sys.platform != "linux":
            effective_fs_backend = MockInotifyBackend()

        # Orchestrator configuration
        self.config = config or OrchestratorConfig(
            host_id=host_uuid,
            hostname=getattr(settings, "hostname", None),
            process_interval=self.interval,
            resource_interval=max(self.interval, 5.0),
            proc_dir="/proc",
            passwd_file="/etc/passwd",
            fs_backend=effective_fs_backend,
        )

        # Session factory
        if session is not None:
            self.orchestrator = CollectorOrchestrator(self.config, session=session)
        elif session_factory is not None:
            self.orchestrator = CollectorOrchestrator(
                self.config, session_factory=session_factory
            )
        else:
            if settings.database_url:
                settings.validate_database_url()
            elif not settings.debug:
                from backend.config import ConfigurationError

                raise ConfigurationError(
                    "OSIRIS_DATABASE_URL is not configured for collector supervisor."
                )
            from backend.db.session import SessionLocal

            self.orchestrator = CollectorOrchestrator(
                self.config, session_factory=SessionLocal
            )

    def write_health_status(self) -> None:
        """Write collector status JSON safely and atomically."""
        status = self.orchestrator.get_status()
        health_payload = {
            "supervisor_pid": os.getpid(),
            "status": "running" if self._is_running else "stopped",
            "healthy": status.get("healthy", True),
            "updated_at": time.time(),
            "cycle_count": status.get("cycle_count", 0),
            "observations_count": status.get("total_observations", 0),
            "events_count": status.get("total_events", 0),
            "last_cycle": status.get("last_cycle_timestamp"),
            "collectors": status.get("collectors", {}),
            "sink_errors": status.get("sink_errors", {}),
        }
        try:
            self.health_file.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        pid_suffix = os.getpid()
        tmp_name = f".{self.health_file.name}.tmp.{pid_suffix}"
        tmp_path = self.health_file.parent / tmp_name
        tmp_fd: int | None = None
        try:
            flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
            if hasattr(os, "O_NOFOLLOW"):
                flags |= os.O_NOFOLLOW
            tmp_fd = os.open(str(tmp_path), flags, 0o644)
            st = os.fstat(tmp_fd)
            import stat

            if not stat.S_ISREG(st.st_mode) or st.st_uid != os.geteuid():
                raise OSError("Invalid temporary health file descriptor")
            payload_bytes = json.dumps(health_payload, indent=2).encode("utf-8")
            os.write(tmp_fd, payload_bytes)
            os.fsync(tmp_fd)
            os.close(tmp_fd)
            tmp_fd = None
            os.replace(str(tmp_path), str(self.health_file))
        except Exception as exc:
            logger.debug("Failed to write collector health status: %s", exc)
            if tmp_fd is not None:
                try:
                    os.close(tmp_fd)
                except Exception:
                    pass
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass

    def start(self, watch: bool = True, cycles: int | None = None) -> int:
        """Start supervisor with PID lock and lifecycle handling."""
        self.pid_lock.acquire()
        atexit.register(self.pid_lock.release)
        self._is_running = True

        logger.info(
            "OSIRIS Collector Supervisor started (PID: %d, host: %s, watch: %s)",
            os.getpid(),
            self.config.host_id,
            watch,
        )

        completed = 0
        try:
            if (
                hasattr(self.orchestrator, "start")
                and getattr(self.orchestrator, "state", None) == OrchestratorState.STOPPED
            ):
                self.orchestrator.start(background=False)

            while not self._stop_event.is_set():
                self.orchestrator.run_cycle(force_all=False)
                completed += 1
                self.write_health_status()

                if not watch and cycles is not None and completed >= cycles:
                    break

                if self._stop_event.wait(timeout=self.interval):
                    break
        except Exception as exc:
            logger.error("Collector supervisor error: %s", exc, exc_info=True)
            return 1
        finally:
            self._is_running = False
            self.write_health_status()
            if hasattr(self.orchestrator, "stop"):
                try:
                    self.orchestrator.stop()
                except Exception as exc:
                    logger.warning("Error stopping orchestrator: %s", exc)
            self.pid_lock.release()
            logger.info("OSIRIS Collector Supervisor shutdown complete.")

        return 0

    def stop(self) -> None:
        """Request graceful shutdown of the collector loop."""
        self._stop_event.set()


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m collectors.supervisor",
        description="OSIRIS Centralized Collector Supervisor Daemon",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        default=True,
        help="Run continuously as background daemon (default).",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        default=False,
        help="Run single cycle and exit.",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=2.0,
        help="Polling interval in seconds (default: 2.0s).",
    )
    parser.add_argument(
        "--pid-file",
        type=str,
        default=None,
        help="Path to PID lock file (default: dynamic /run/osiris or /tmp).",
    )
    return parser


def main() -> None:
    parser = create_parser()
    args = parser.parse_args()

    watch = not args.once
    supervisor = CollectorSupervisor(
        pid_file=args.pid_file,
        interval=args.interval,
    )

    def _handle_signal(signum: int, frame: Any) -> None:
        logger.info("Received termination signal %d. Stopping...", signum)
        supervisor.stop()

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    exit_code = supervisor.start(watch=watch, cycles=1 if args.once else None)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
