# OSIRIS Service Lifecycle & Platform Management

## Architecture Overview

OSIRIS operates as a unified platform composed of three primary operational tiers:
1. **Persistent Database:** PostgreSQL relational storage for historical events, entity lifecycle, detection alerts, FIM baselines, and investigation workspaces.
2. **Central Application Server:** FastAPI backend serving the single-page application shell, REST API (64+ endpoints), and authenticated WebSocket streams (`/ws`).
3. **Unified Collector Supervisor:** Independent daemon managing local system collectors (Process, Resource, and Filesystem inotify) with single-instance PID locking (`/run/osiris-collector/osiris_collector_supervisor.pid` or private dev runtime directory) and health status reporting (`/run/osiris-collector/osiris_collector_health.json`).

```text
[ OSIRIS Systemd Target (osiris.target) ]
                  │
        ┌─────────┴─────────┐
        ▼                   ▼
 [ osiris-backend ]   [ osiris-collector ]
        │                   │
        ▼                   ▼
   wait_for_db         wait_for_db
        │                   │
        └─────────┬─────────┘
                  ▼
          [ PostgreSQL 15+ ]
```

## Systemd Service Installation (Ubuntu Deployment)

### 1. Prerequisites & Deployment Directory
- Ubuntu 22.04 LTS or 24.04 LTS
- PostgreSQL service enabled and running
- Dedicated acceptance database and least-privilege role created
- OSIRIS deployed to `/opt/osiris` with active Python virtual environment at `/opt/osiris/.venv`
- **Important**: Verify `/opt/osiris` does not already exist prior to deployment to prevent accidental overwrites of existing checkouts.

### 2. Service Units
The OSIRIS deployment provides three systemd units in `deployment/systemd/`:
- `osiris-backend.service`: Runs the FastAPI ASGI server (`uvicorn backend.main:app`) as unprivileged user `osiris:osiris` with pre-flight database readiness check (`scripts/wait_for_db.py`). Configures `RuntimeDirectory=osiris` (mode 0775) hosting the Unix domain socket (`osiris_ipc.sock`, mode 0660). Bound to `osiris.target` via `PartOf=osiris.target`.
- `osiris-collector.service`: Runs the unified collector supervisor daemon as `root:osiris` with PID locking and health status output in a protected root-owned runtime directory (`RuntimeDirectory=osiris-collector`, mode 0755). Bound to `osiris.target` via `PartOf=osiris.target`.
- `osiris.target`: Groups both services into a synchronized lifecycle target.

### 3. Separated Protected Runtime Directories & Security Isolation Model
- **Root Collector Runtime Directory (`/run/osiris-collector`)**:
  - Configured with `RuntimeDirectory=osiris-collector`, `RuntimeDirectoryMode=0755`, `User=root`, `Group=osiris`, and `UMask=0022`.
  - Protects the supervisor PID file (`/run/osiris-collector/osiris_collector_supervisor.pid`) and health status file (`/run/osiris-collector/osiris_collector_health.json`).
  - Mode 0755 prevents group write access, guaranteeing that the unprivileged backend user `osiris` cannot unlink, replace, or tamper with the collector supervisor's PID lock file, while still allowing the backend to read health metrics.
- **Backend IPC Runtime Directory (`/run/osiris`)**:
  - Configured with `RuntimeDirectory=osiris`, `RuntimeDirectoryMode=0775`, `User=osiris`, `Group=osiris`.
  - Hosts the IPC Unix domain socket bridge (`osiris_ipc.sock`) with mode 0660 (owner `osiris:osiris`).
  - Root collector connects via authorized group `osiris`.
  - Enforces Linux `SO_PEERCRED` caller verification, message size limits (64 KB), token-bucket rate-limiting, and authoritative health status hydration.
  - Development environments fall back to a private per-instance directory with mode 0700 (`/tmp/osiris_<uid>_<hash>/`). Insecure shared `/tmp/osiris_ipc.sock` is strictly prohibited.

### 4. Application Source & Virtual Environment Privilege Separation
To protect the root collector from executing backend-writable code:
- **Application Source Tree (`/opt/osiris`)**:
  - Owner: `root`, Group: `osiris`.
  - Directories: Mode `0750` (`rwxr-x---`).
  - Regular files: Mode `0640` (`rw-r-----`).
  - Executable scripts: Mode `0750` (`rwxr-x---`).
  - The unprivileged backend user `osiris` has read access only and CANNOT modify application code.
- **Python Virtual Environment (`/opt/osiris/.venv`)**:
  - Owner: `root:osiris`.
  - Mode `0750` for directories and `.venv/bin/*` executables; mode `0640` for library files.
  - Backend user cannot install, modify, or delete executable dependencies.
- **Production Configuration (`/opt/osiris/.env`)**:
  - Owner: `root`, Group: `osiris`, Mode `0640`.
  - Readable by both backend and collector; writable ONLY by `root`.
- **Enforcement Utility**:
  - `sudo ./scripts/osiris-service.sh secure-permissions [/opt/osiris]` automatically enforces these boundaries.

### 5. Installation Commands
```bash
# Verify target deployment path, establish root ownership, and install units
sudo ./scripts/osiris-service.sh install
```

## Daily Operations via `scripts/osiris-service.sh`

The administrator can manage OSIRIS through a single documented interface:

```bash
# Check status of target, backend, collector, database readiness, and collector health
./scripts/osiris-service.sh status

# Start OSIRIS platform (systemctl when installed, fallback in development)
./scripts/osiris-service.sh start

# Stop OSIRIS platform cleanly (uses systemctl exclusively when managed; dedicated PID file validation in dev)
./scripts/osiris-service.sh stop

# Restart OSIRIS platform
./scripts/osiris-service.sh restart
```

## Health Probes and Database Dependency Checks

1. **Pre-flight Dependency Probe (`scripts/wait_for_db.py`):**
   - Automatically executed by `ExecStartPre=` in systemd units and during script startup.
   - Retries database connectivity with configurable timeout (default: 60s for systemd, 30s for script).
   - Masks passwords in all log output.
   - Fails fast with non-zero exit code if database is unavailable.

2. **API Status Endpoint (`GET /api/status`):**
   - Live query executing `SELECT 1`.
   - Inspects active collector health file to expose collector cycles, observation counters, and per-collector status (`proc`, `resource`, `fs`).
