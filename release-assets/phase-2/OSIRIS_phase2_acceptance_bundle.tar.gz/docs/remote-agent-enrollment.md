# OSIRIS Remote Host Agent Enrollment Guide (Phase 3 Planned Architecture)

> [!NOTE]
> **Implementation Status: In-Design / Planned for Phase 3**
> The remote agent enrollment workflow, enrollment tokens (`AGENT_ENROLLMENT_TOKEN`), and agent artifact distribution endpoint (`/downloads/osiris-agent-linux.tar.gz`) described below represent the **planned Phase 3 architecture**. 
> They are **not currently implemented in the Phase 2 release**. In Phase 2, OSIRIS operates with a local Collector Supervisor (`collectors/supervisor.py`) executing directly on the monitored host.

---

## Architectural Boundary: Central Backend vs. Local Collector vs. Remote Agent

The OSIRIS central dashboard and local collectors inspect the machine on which they execute. Installing OSIRIS on a central server does **not** automatically grant visibility into remote endpoints.

Remote hosts must explicitly enroll as monitored systems:
1. **Central OSIRIS Platform:** Hosts the API, PostgreSQL database, WebSocket broker, and web UI.
2. **Local Monitored System (Phase 2):** The server hosting the central OSIRIS backend, monitored by the local Collector Supervisor (`ubuntu-osiris-live`).
3. **Remote Enrolled Host (Phase 3 Planned):** Any external Linux endpoint (`srv-prod-web01`, workstation, cloud instance) running a lightweight OSIRIS collector agent reporting back over TLS.

---

## Remote Agent Enrollment Model (Phase 3 Specification)

```text
[ Remote Host: srv-prod-web01 ]
     │
     ├─ ProcessCollector (/proc)
     ├─ ResourceCollector (/proc/stat, /proc/meminfo)
     └─ FilesystemCollector (inotify)
           │
           │ (HTTPS / mTLS / Encrypted REST Stream)
           ▼
[ OSIRIS Central Backend: https://osiris.example.com ]
```

### Step 1: Generate Host Enrollment Credentials *(Phase 3 Planned)*
On the central OSIRIS dashboard:
1. Navigate to **OBSERVE -> Hosts & Collectors**.
2. Click **Enroll New Host**.
3. Record the generated `HOST_ID` (UUID) and `AGENT_ENROLLMENT_TOKEN`.
*(Note: In Phase 2, hosts are provisioned via direct database/collector registration; the web token enrollment UI and token verification API are scheduled for Phase 3).*

### Step 2: Provision Remote Agent on Endpoint *(Phase 3 Planned)*
On the target endpoint (`srv-prod-web01`):
```bash
# 1. Download OSIRIS remote agent package (Planned endpoint in Phase 3)
curl -fsSL https://osiris.example.com/downloads/osiris-agent-linux.tar.gz -o osiris-agent.tar.gz
tar -xzf osiris-agent.tar.gz -C /opt/osiris-agent

# 2. Configure endpoint identity
cat <<EOF > /opt/osiris-agent/.env
OSIRIS_CENTRAL_URL=https://osiris.example.com
OSIRIS_HOST_ID=10000000-0000-4000-8000-000000000001
OSIRIS_ENROLLMENT_TOKEN=agt_sec_9918237198273
EOF

# 3. Enable and start agent service
sudo /opt/osiris-agent/scripts/install-agent.sh
sudo systemctl enable --now osiris-agent.service
```

### Step 3: Verification *(Phase 3 Planned)*
On the central OSIRIS dashboard:
- The remote host `srv-prod-web01` transitions from "pending" to "online".
- Real-time telemetry, processes, files, and detection rules immediately scope to the remote host.
