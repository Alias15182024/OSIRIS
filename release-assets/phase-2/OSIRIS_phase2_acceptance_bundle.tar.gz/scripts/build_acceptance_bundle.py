#!/usr/bin/env python3
"""Build and verify the OSIRIS Phase 2 Final Acceptance Testing Release Bundle.

Generates:
1. OSIRIS_phase2_acceptance_bundle.tar.gz
2. OSIRIS_phase2_acceptance_bundle.sha256
3. OSIRIS_phase2_acceptance_bundle.manifest.txt
4. OSIRIS_phase2_acceptance_bundle_README.md
and updates in-tree MANIFEST.txt.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import tarfile
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DESKTOP_DIR = Path("/Users/alias/Desktop")

BUNDLE_ARCHIVE = DESKTOP_DIR / "OSIRIS_phase2_acceptance_bundle.tar.gz"
BUNDLE_SHA256 = DESKTOP_DIR / "OSIRIS_phase2_acceptance_bundle.sha256"
BUNDLE_MANIFEST = DESKTOP_DIR / "OSIRIS_phase2_acceptance_bundle.manifest.txt"
BUNDLE_README = DESKTOP_DIR / "OSIRIS_phase2_acceptance_bundle_README.md"

IN_TREE_MANIFEST = PROJECT_ROOT / "MANIFEST.txt"
IN_TREE_README = PROJECT_ROOT / "README_ACCEPTANCE.md"

EXCLUDED_DIRS = {
    ".git",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
}

EXCLUDED_FILES = {
    ".env",
    "MANIFEST.txt",
    "OSIRIS_phase2_acceptance_bundle.tar.gz",
    "OSIRIS_phase2_acceptance_bundle.sha256",
    "OSIRIS_phase2_acceptance_bundle.manifest.txt",
    "OSIRIS_phase2_acceptance_bundle_README.md",
    "uv.lock",
}

EXCLUDED_EXTS = {
    ".pyc",
    ".pyo",
    ".pid",
    ".sock",
    ".log",
    ".DS_Store",
    ".sqlite",
    ".db",
}


def sha256_file(path: Path) -> str:
    """Compute hexadecimal SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def collect_release_files() -> list[str]:
    """Collect all files to be included in release bundle, relative to PROJECT_ROOT."""
    collected: list[str] = []
    for root, dirs, files in os.walk(PROJECT_ROOT):
        # Prune excluded directories in-place
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]
        for f in sorted(files):
            if f in EXCLUDED_FILES or f.startswith("._") or f.endswith(".DS_Store"):
                continue
            ext = os.path.splitext(f)[1]
            if ext in EXCLUDED_EXTS:
                continue
            full_path = Path(root) / f
            # Safety checks: no symlinks, regular file
            if full_path.is_symlink():
                raise RuntimeError(f"Unexpected symlink in release tree: {full_path}")
            if not full_path.is_file():
                continue
            rel_path = full_path.relative_to(PROJECT_ROOT).as_posix()
            # Path traversal check
            if rel_path.startswith("..") or "/../" in rel_path:
                raise RuntimeError(f"Path traversal detected in file list: {rel_path}")
            collected.append(rel_path)

    collected.sort()
    return collected


def generate_manifest(files: list[str]) -> str:
    """Generate SHA-256 manifest string sorted by relative path."""
    lines: list[str] = []
    for rel_path in files:
        full_path = PROJECT_ROOT / rel_path
        file_hash = sha256_file(full_path)
        lines.append(f"{file_hash}  {rel_path}")
    return "\n".join(lines) + "\n"


def build_bundle() -> None:
    print(f"Collecting release files from {PROJECT_ROOT}...")
    files = collect_release_files()
    print(f"Collected {len(files)} release files.")

    # 1. Generate in-tree MANIFEST.txt
    manifest_content = generate_manifest(files)
    IN_TREE_MANIFEST.write_text(manifest_content, encoding="utf-8")
    print(f"Updated in-tree {IN_TREE_MANIFEST} ({len(files)} entries).")

    # 2. Copy manifest to Desktop
    BUNDLE_MANIFEST.write_text(manifest_content, encoding="utf-8")
    print(f"Written desktop manifest: {BUNDLE_MANIFEST}")

    # 3. Copy README_ACCEPTANCE.md to Desktop
    shutil.copy2(IN_TREE_README, BUNDLE_README)
    print(f"Written desktop README: {BUNDLE_README}")

    # 4. Create tar.gz archive including all release files PLUS MANIFEST.txt
    archive_members = list(files) + ["MANIFEST.txt"]
    archive_members.sort()

    print(f"Creating archive {BUNDLE_ARCHIVE} ({len(archive_members)} members)...")
    with tarfile.open(BUNDLE_ARCHIVE, "w:gz", format=tarfile.PAX_FORMAT) as tar:
        for rel_path in archive_members:
            full_path = PROJECT_ROOT / rel_path
            # Verify file exists
            if not full_path.exists():
                raise RuntimeError(f"File missing during packaging: {full_path}")
            # Add with clean tarinfo (deterministic ownership)
            ti = tar.gettarinfo(name=str(full_path), arcname=rel_path)
            # Normalize permissions: dirs 0750, scripts 0750, files 0640
            if rel_path.endswith(".sh") or rel_path.startswith("scripts/"):
                ti.mode = 0o0750
            else:
                ti.mode = 0o0640
            ti.uid = 0
            ti.gid = 0
            ti.uname = "root"
            ti.gname = "root"
            with open(full_path, "rb") as f:
                tar.addfile(ti, f)

    print(
        f"Archive built successfully: {BUNDLE_ARCHIVE} "
        f"({BUNDLE_ARCHIVE.stat().st_size} bytes)"
    )

    # 5. Compute SHA-256 of the archive
    archive_hash = sha256_file(BUNDLE_ARCHIVE)
    BUNDLE_SHA256.write_text(
        f"{archive_hash}  {BUNDLE_ARCHIVE.name}\n", encoding="utf-8"
    )
    print(f"Written archive SHA-256: {BUNDLE_SHA256}")
    print(f"Archive SHA-256: {archive_hash}")

    # 6. Deep Verification: test extraction and manifest verification
    print("\nRunning Verification Checks...")

    # A. Verify desktop archive checksum
    with open(BUNDLE_SHA256, "r", encoding="utf-8") as f:
        expected_line = f.read().strip()
    calc_hash = sha256_file(BUNDLE_ARCHIVE)
    assert f"{calc_hash}  {BUNDLE_ARCHIVE.name}" == expected_line, (
        "Archive checksum verification failed!"
    )
    print(f"  [PASS] Archive checksum verified: {calc_hash}")

    # B. Verify in-tree manifest entries
    failed_manifest_entries = []
    for line in manifest_content.splitlines():
        if not line.strip():
            continue
        exp_hash, _, rel = line.partition("  ")
        target_path = PROJECT_ROOT / rel.strip()
        if not target_path.exists() or sha256_file(target_path) != exp_hash.strip():
            failed_manifest_entries.append(rel)
    assert not failed_manifest_entries, (
        f"Manifest entries failed verification: {failed_manifest_entries}"
    )
    print(f"  [PASS] All {len(files)} in-tree manifest entries verified.")

    # C. Verify test extraction in isolated temporary directory
    with tempfile.TemporaryDirectory() as tmp_dir:
        extract_path = Path(tmp_dir) / "extracted"
        extract_path.mkdir()
        with tarfile.open(BUNDLE_ARCHIVE, "r:gz") as tar:
            # Safe extraction check
            for member in tar.getmembers():
                if member.name.startswith("/") or ".." in member.name:
                    raise RuntimeError(f"Unsafe archive member: {member.name}")
            if hasattr(tarfile, "data_filter"):
                tar.extractall(path=extract_path, filter="data")
            else:
                tar.extractall(path=extract_path)

        # Verify all extracted files match manifest
        extracted_manifest = (extract_path / "MANIFEST.txt").read_text(encoding="utf-8")
        assert extracted_manifest == manifest_content, "Extracted MANIFEST.txt differs!"
        for line in extracted_manifest.splitlines():
            if not line.strip():
                continue
            exp_hash, _, rel = line.partition("  ")
            f_path = extract_path / rel.strip()
            assert f_path.exists(), f"Extracted file missing: {rel}"
            assert sha256_file(f_path) == exp_hash.strip(), (
                f"Extracted file hash mismatch: {rel}"
            )

        # Verify no forbidden files were extracted
        for root, dirs, extracted_files in os.walk(extract_path):
            for ef in extracted_files:
                assert ef not in {".env", ".DS_Store"} and not ef.startswith("._"), (
                    f"Forbidden file extracted: {ef}"
                )
                assert not ef.endswith(".pyc") and not ef.endswith(".log"), (
                    f"Forbidden file extracted: {ef}"
                )

        print(
            "  [PASS] Isolated archive extraction verified "
            f"({len(archive_members)} files, 100% manifest match, "
            "zero forbidden artifacts)."
        )

    print("\nRelease bundle generation and verification COMPLETED SUCCESSFULLY.")


if __name__ == "__main__":
    build_bundle()
