#!/usr/bin/env bash
# OSIRIS Unified Platform Service Management Script
# Provides start, stop, restart, status, and installation commands for OSIRIS.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
export PYTHONPATH="${PROJECT_ROOT}:${PYTHONPATH:-}"

usage() {
    cat <<EOF
Usage: $0 {start|stop|restart|status|install|secure-permissions}

Commands:
  start              Start OSIRIS platform services (database check -> backend -> collectors)
  stop               Stop OSIRIS platform services cleanly
  restart            Restart OSIRIS platform services
  status             Show current status of OSIRIS services, database readiness, and collector health
  install            Install systemd unit files on Ubuntu (requires sudo)
  secure-permissions Enforce root-owned deployment ownership and mode 0750/0640 permissions (requires sudo)
EOF
    exit 1
}

has_systemd() {
    command -v systemctl >/dev/null 2>&1 && [ -d /run/systemd/system ]
}

is_systemd_managed() {
    if ! has_systemd; then
        return 1
    fi
    if [ "${OSIRIS_NO_SYSTEMD:-0}" = "1" ]; then
        return 1
    fi
    if [ "${OSIRIS_FORCE_SYSTEMD:-0}" = "1" ]; then
        return 0
    fi
    # Systemd units target /opt/osiris; only dispatch to systemctl if PROJECT_ROOT is /opt/osiris
    if [ "${PROJECT_ROOT}" != "/opt/osiris" ]; then
        return 1
    fi
    if [ -f /etc/systemd/system/osiris.target ] || [ -f /lib/systemd/system/osiris.target ] || systemctl list-unit-files osiris.target >/dev/null 2>&1; then
        return 0
    fi
    return 1
}

run_systemctl() {
    if [ "$(id -u)" -eq 0 ]; then
        systemctl "$@"
    else
        sudo systemctl "$@"
    fi
}

resolve_python() {
    if [ -x "${PROJECT_ROOT}/.venv/bin/python" ]; then
        echo "${PROJECT_ROOT}/.venv/bin/python"
    elif command -v python3 >/dev/null 2>&1; then
        command -v python3
    elif command -v python >/dev/null 2>&1; then
        command -v python
    else
        echo "python3"
    fi
}

resolve_dev_runtime_dir() {
    # Dedicated per-instance development runtime directory
    # Keyed by UID and a hash of PROJECT_ROOT to prevent collisions between checkouts
    local inst_hash
    if command -v sha256sum >/dev/null 2>&1; then
        inst_hash="$(echo -n "${PROJECT_ROOT}" | sha256sum | cut -c1-12)"
    elif command -v shasum >/dev/null 2>&1; then
        inst_hash="$(echo -n "${PROJECT_ROOT}" | shasum -a 256 | cut -c1-12)"
    else
        inst_hash="$(echo -n "${PROJECT_ROOT}" | cksum | tr ' ' '_')"
    fi

    local fallback_dir="/tmp/osiris_${UID:-$(id -u)}_${inst_hash}"
    mkdir -p "${fallback_dir}" 2>/dev/null || true
    chmod 700 "${fallback_dir}" 2>/dev/null || true
    echo "${fallback_dir}"
}

resolve_backend_runtime_dir() {
    if [ "${PROJECT_ROOT}" = "/opt/osiris" ]; then
        if [ -d "/run/osiris" ] && [ -w "/run/osiris" ]; then
            echo "/run/osiris"
            return 0
        elif [ -w "/run" ] && [ "$(id -u)" -eq 0 ]; then
            mkdir -p "/run/osiris" 2>/dev/null || true
            chmod 0775 "/run/osiris" 2>/dev/null || true
            echo "/run/osiris"
            return 0
        fi
    fi
    resolve_dev_runtime_dir
}

resolve_collector_runtime_dir() {
    if [ "${PROJECT_ROOT}" = "/opt/osiris" ]; then
        if [ -d "/run/osiris-collector" ] && [ -w "/run/osiris-collector" ]; then
            echo "/run/osiris-collector"
            return 0
        elif [ -w "/run" ] && [ "$(id -u)" -eq 0 ]; then
            mkdir -p "/run/osiris-collector" 2>/dev/null || true
            chmod 0755 "/run/osiris-collector" 2>/dev/null || true
            echo "/run/osiris-collector"
            return 0
        fi
    fi
    resolve_dev_runtime_dir
}

resolve_runtime_dir() {
    resolve_backend_runtime_dir
}

get_backend_pid_file() {
    local run_dir
    run_dir="$(resolve_backend_runtime_dir)"
    echo "${run_dir}/osiris_backend.pid"
}

get_collector_pid_file() {
    local run_dir
    run_dir="$(resolve_collector_runtime_dir)"
    echo "${run_dir}/osiris_collector_supervisor.pid"
}

get_collector_health_file() {
    local run_dir
    run_dir="$(resolve_collector_runtime_dir)"
    if [ -f "${run_dir}/osiris_collector_health.json" ]; then
        echo "${run_dir}/osiris_collector_health.json"
    elif [ -f "/run/osiris-collector/osiris_collector_health.json" ]; then
        echo "/run/osiris-collector/osiris_collector_health.json"
    else
        echo "${run_dir}/osiris_collector_health.json"
    fi
}

stop_process_by_pid_file() {
    local service_name="$1"
    local pid_file="$2"
    local expected_pattern="$3"

    if [ ! -f "${pid_file}" ]; then
        echo "${service_name}: No active PID file found at ${pid_file}."
        return 0
    fi

    # Verify PID file ownership if not root
    if [ "$(id -u)" -ne 0 ] && [ -e "${pid_file}" ] && [ ! -O "${pid_file}" ]; then
        echo "Error: PID file ${pid_file} is not owned by current user ($(id -un)). Refusing to touch." >&2
        return 1
    fi

    local pid
    pid="$(tr -d '[:space:]' < "${pid_file}" 2>/dev/null || true)"
    if [ -z "${pid}" ] || ! [[ "${pid}" =~ ^[0-9]+$ ]]; then
        echo "Warning: ${service_name} PID file ${pid_file} contains invalid PID '${pid}'. Refusing to act." >&2
        return 1
    fi

    # Check if process is running
    if ! kill -0 "${pid}" 2>/dev/null; then
        echo "${service_name} (PID ${pid}) is not running. Cleaning up stale PID file."
        rm -f "${pid_file}"
        return 0
    fi

    # Validate process ownership (check both UID and user name)
    local proc_uid proc_user current_uid current_user
    proc_uid="$(ps -p "${pid}" -o uid= 2>/dev/null | tr -d ' ' || true)"
    proc_user="$(ps -p "${pid}" -o user= 2>/dev/null | tr -d ' ' || true)"
    current_uid="$(id -u 2>/dev/null || true)"
    current_user="$(id -un 2>/dev/null || true)"

    if [ "${current_uid}" -ne 0 ]; then
        if [ -n "${proc_uid}" ] && [ "${proc_uid}" != "${current_uid}" ]; then
            echo "Error: Process ${pid} is owned by UID '${proc_uid}', not current UID '${current_uid}'. Refusing to terminate." >&2
            return 1
        fi
        if [ -n "${proc_user}" ] && [ "${proc_user}" != "${current_user}" ] && [ "${proc_user}" != "${current_uid}" ]; then
            echo "Error: Process ${pid} is owned by user '${proc_user}', not current user '${current_user}'. Refusing to terminate." >&2
            return 1
        fi
    fi

    # Validate process identity (command line must contain expected pattern)
    local proc_cmd
    proc_cmd="$(ps -p "${pid}" -o args= 2>/dev/null || true)"
    if [ -z "${proc_cmd}" ] || [[ "${proc_cmd}" != *"${expected_pattern}"* ]]; then
        echo "Error: Process ${pid} command line does not match expected pattern '${expected_pattern}' (command: '${proc_cmd}'). Refusing to terminate unrelated process." >&2
        return 1
    fi

    # Validate instance ownership (process must belong to this OSIRIS instance)
    local proc_cwd=""
    if [ -d "/proc/${pid}" ] && [ -e "/proc/${pid}/cwd" ]; then
        proc_cwd="$(readlink -f "/proc/${pid}/cwd" 2>/dev/null || readlink "/proc/${pid}/cwd" 2>/dev/null || true)"
    elif command -v lsof >/dev/null 2>&1; then
        proc_cwd="$(lsof -a -p "${pid}" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1 || true)"
    fi

    local canonical_project_root
    canonical_project_root="$(cd "${PROJECT_ROOT}" 2>/dev/null && pwd -P || echo "${PROJECT_ROOT}")"

    if [ -n "${proc_cwd}" ]; then
        local canonical_proc_cwd
        canonical_proc_cwd="$(cd "${proc_cwd}" 2>/dev/null && pwd -P || echo "${proc_cwd}")"
        if [ "${canonical_proc_cwd}" != "${canonical_project_root}" ] && [[ "${canonical_proc_cwd}" != "${canonical_project_root}"/* ]]; then
            echo "Error: Process ${pid} working directory ('${proc_cwd}') does not belong to this OSIRIS instance ('${PROJECT_ROOT}'). Refusing to terminate unrelated process." >&2
            return 1
        fi
    else
        # Fallback: verify command line or python binary path contains PROJECT_ROOT
        if [[ "${proc_cmd}" != *"${PROJECT_ROOT}"* ]] && [[ "${proc_cmd}" != *"${canonical_project_root}"* ]] && [ "${PROJECT_ROOT}" != "/opt/osiris" ]; then
            echo "Warning: Unable to verify working directory for process ${pid}, and command line does not contain '${PROJECT_ROOT}'." >&2
        fi
    fi

    echo "Terminating ${service_name} (PID ${pid})..."
    kill -TERM "${pid}" 2>/dev/null || true

    local waited=0
    while kill -0 "${pid}" 2>/dev/null; do
        sleep 0.5
        waited=$((waited + 1))
        if [ "${waited}" -ge 30 ]; then
            echo "Warning: ${service_name} (PID ${pid}) did not shut down within 15s. Sending SIGKILL..." >&2
            kill -KILL "${pid}" 2>/dev/null || true
            sleep 1
            break
        fi
    done

    # Verify shutdown before deleting PID file
    if kill -0 "${pid}" 2>/dev/null; then
        echo "Error: ${service_name} (PID ${pid}) failed to shut down. PID file retained at ${pid_file}." >&2
        return 1
    fi

    echo "${service_name} (PID ${pid}) stopped cleanly."
    rm -f "${pid_file}"
    return 0
}

apply_secure_permissions() {
    local target_dir="${1:-/opt/osiris}"
    if [ ! -d "${target_dir}" ]; then
        echo "Error: Directory ${target_dir} does not exist." >&2
        return 1
    fi

    # Verify that target_dir is genuinely an OSIRIS installation
    if [ ! -f "${target_dir}/alembic.ini" ] || [ ! -f "${target_dir}/backend/main.py" ] || [ ! -f "${target_dir}/collectors/supervisor.py" ]; then
        echo "Error: Directory ${target_dir} exists but is missing OSIRIS markers. Refusing to alter unrelated directory." >&2
        return 1
    fi

    echo "Applying root-owned security model and privilege separation to ${target_dir}..."

    # 1. Ensure system user 'osiris' exists
    if ! id -u osiris >/dev/null 2>&1; then
        echo "Creating system user and group 'osiris'..."
        useradd -r -s /usr/sbin/nologin -U osiris 2>/dev/null || useradd -r -s /bin/false -U osiris
    fi

    # 2. Establish root:osiris ownership across application tree (NEVER recursive chown to osiris:osiris)
    chown -R root:osiris "${target_dir}"

    # 3. Set directory permissions to mode 0750 (root rwx, osiris rx, other none)
    find "${target_dir}" -type d -exec chmod 0750 {} +

    # 4. Set regular file permissions to mode 0640 (root rw, osiris r, other none)
    find "${target_dir}" -type f -exec chmod 0640 {} +

    # 5. Set executable scripts and binaries to mode 0750
    if [ -d "${target_dir}/scripts" ]; then
        find "${target_dir}/scripts" -type f \( -name "*.sh" -o -name "*.py" \) -exec chmod 0750 {} +
    fi

    # 6. Virtual environment: root-owned, not writable by backend user
    if [ -d "${target_dir}/.venv" ]; then
        chown -R root:osiris "${target_dir}/.venv"
        find "${target_dir}/.venv" -type d -exec chmod 0750 {} +
        find "${target_dir}/.venv" -type f -exec chmod 0640 {} +
        if [ -d "${target_dir}/.venv/bin" ]; then
            chmod -R 0750 "${target_dir}/.venv/bin"
        fi
    fi

    # 7. Secure production .env if present
    if [ -f "${target_dir}/.env" ]; then
        chown root:osiris "${target_dir}/.env"
        chmod 0640 "${target_dir}/.env"
        echo "Secured ${target_dir}/.env as root:osiris mode 0640."
    fi

    # 8. Establish separated runtime directories
    mkdir -p /run/osiris
    chown osiris:osiris /run/osiris
    chmod 0775 /run/osiris

    mkdir -p /run/osiris-collector
    chown root:osiris /run/osiris-collector
    chmod 0755 /run/osiris-collector

    echo "Privilege separation established cleanly."
    return 0
}

case "${1:-}" in
    start)
        echo "Starting OSIRIS Platform..."
        if is_systemd_managed; then
            echo "Starting OSIRIS via systemd (systemctl start osiris.target)..."
            run_systemctl start osiris.target
            echo "Started OSIRIS via systemd."
            exit 0
        fi

        echo "Running database dependency check..."
        PYTHON_BIN="$(resolve_python)"
        if ! "${PYTHON_BIN}" "${SCRIPT_DIR}/wait_for_db.py" --timeout 30; then
            echo "Error: Database dependency readiness check failed. Cannot start OSIRIS." >&2
            exit 1
        fi

        RUN_DIR="$(resolve_runtime_dir)"
        COLLECTOR_PID_FILE="$(get_collector_pid_file)"
        BACKEND_PID_FILE="$(get_backend_pid_file)"

        if [ -f "${COLLECTOR_PID_FILE}" ]; then
            OLD_CPID="$(tr -d '[:space:]' < "${COLLECTOR_PID_FILE}" 2>/dev/null || true)"
            OLD_CCMD="$(ps -p "${OLD_CPID}" -o args= 2>/dev/null || true)"
            if [ -n "${OLD_CPID}" ] && kill -0 "${OLD_CPID}" 2>/dev/null && [[ "${OLD_CCMD}" == *"collectors.supervisor"* ]]; then
                echo "Collector Supervisor is already running (PID ${OLD_CPID})."
            else
                rm -f "${COLLECTOR_PID_FILE}"
            fi
        fi

        if [ ! -f "${COLLECTOR_PID_FILE}" ]; then
            echo "Starting Collector Supervisor..."
            "${PYTHON_BIN}" -m collectors.supervisor --watch --pid-file "${COLLECTOR_PID_FILE}" > /tmp/osiris_supervisor.log 2>&1 &
            echo "Collector Supervisor started in background (log: /tmp/osiris_supervisor.log)."
        fi

        if [ -f "${BACKEND_PID_FILE}" ]; then
            OLD_BPID="$(tr -d '[:space:]' < "${BACKEND_PID_FILE}" 2>/dev/null || true)"
            OLD_BCMD="$(ps -p "${OLD_BPID}" -o args= 2>/dev/null || true)"
            if [ -n "${OLD_BPID}" ] && kill -0 "${OLD_BPID}" 2>/dev/null && [[ "${OLD_BCMD}" == *"backend.main:app"* ]]; then
                echo "FastAPI Backend is already running (PID ${OLD_BPID})."
            else
                rm -f "${BACKEND_PID_FILE}"
            fi
        fi

        if [ ! -f "${BACKEND_PID_FILE}" ]; then
            echo "Starting FastAPI Backend..."
            (
                cd "${PROJECT_ROOT}"
                "${PYTHON_BIN}" -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 > /tmp/osiris_backend.log 2>&1 &
                echo $! > "${BACKEND_PID_FILE}"
            )
            echo "FastAPI Backend started in background (log: /tmp/osiris_backend.log)."
        fi
        ;;
    stop)
        echo "Stopping OSIRIS Platform..."
        if is_systemd_managed; then
            echo "Stopping OSIRIS via systemd (systemctl stop osiris.target osiris-backend.service osiris-collector.service)..."
            run_systemctl stop osiris.target osiris-backend.service osiris-collector.service
            echo "Stopped OSIRIS via systemd."
            exit 0
        fi

        echo "Stopping development fallback processes..."
        COLLECTOR_PID_FILE="$(get_collector_pid_file)"
        BACKEND_PID_FILE="$(get_backend_pid_file)"

        stop_err=0
        stop_process_by_pid_file "Collector Supervisor" "${COLLECTOR_PID_FILE}" "collectors.supervisor" || stop_err=1
        stop_process_by_pid_file "FastAPI Backend" "${BACKEND_PID_FILE}" "backend.main:app" || stop_err=1

        if [ "${stop_err}" -ne 0 ]; then
            echo "Error: One or more OSIRIS processes failed to stop cleanly." >&2
            exit 1
        fi
        echo "Development stop completed."
        ;;
    restart)
        echo "Restarting OSIRIS Platform..."
        if is_systemd_managed; then
            echo "Restarting OSIRIS via systemd (systemctl restart osiris.target osiris-backend.service osiris-collector.service)..."
            run_systemctl restart osiris.target osiris-backend.service osiris-collector.service
            echo "Restarted OSIRIS via systemd."
            exit 0
        fi

        "$0" stop
        sleep 2
        "$0" start
        ;;
    status)
        echo "=========================================="
        echo "         OSIRIS PLATFORM STATUS           "
        echo "=========================================="

        # 1. Target & Services (systemd or fallback)
        if is_systemd_managed; then
            echo "-- Target Status (systemd) --"
            if systemctl is-active --quiet osiris.target 2>/dev/null; then
                echo "osiris.target: ACTIVE"
            else
                echo "osiris.target: INACTIVE"
            fi
            systemctl status osiris.target --no-pager 2>/dev/null || true

            echo ""
            echo "-- Backend Service Status --"
            systemctl status osiris-backend.service --no-pager 2>/dev/null || echo "osiris-backend: not active"

            echo ""
            echo "-- Collector Service Status --"
            systemctl status osiris-collector.service --no-pager 2>/dev/null || echo "osiris-collector: not active"
        else
            echo "-- Target: Development Mode (systemd inactive or units not installed) --"
            echo ""
            echo "-- Backend Process Status --"
            BACKEND_PID_FILE="$(get_backend_pid_file)"
            if [ -f "${BACKEND_PID_FILE}" ]; then
                BPID="$(tr -d '[:space:]' < "${BACKEND_PID_FILE}" 2>/dev/null || true)"
                if [ -n "${BPID}" ] && kill -0 "${BPID}" 2>/dev/null; then
                    echo "Backend running (PID ${BPID}, PID file: ${BACKEND_PID_FILE})"
                else
                    echo "Backend PID file exists (${BACKEND_PID_FILE}) but PID ${BPID} is not running (stale)"
                fi
            else
                echo "Backend: not running (no PID file at ${BACKEND_PID_FILE})"
            fi

            echo ""
            echo "-- Collector Supervisor Process Status --"
            COLLECTOR_PID_FILE="$(get_collector_pid_file)"
            if [ -f "${COLLECTOR_PID_FILE}" ]; then
                CPID="$(tr -d '[:space:]' < "${COLLECTOR_PID_FILE}" 2>/dev/null || true)"
                if [ -n "${CPID}" ] && kill -0 "${CPID}" 2>/dev/null; then
                    echo "Collector Supervisor running (PID ${CPID}, PID file: ${COLLECTOR_PID_FILE})"
                else
                    echo "Collector Supervisor PID file exists (${COLLECTOR_PID_FILE}) but PID ${CPID} is not running (stale)"
                fi
            else
                echo "Collector Supervisor: not running (no PID file at ${COLLECTOR_PID_FILE})"
            fi
        fi

        # 2. Database Readiness
        echo ""
        echo "-- Database Readiness --"
        PYTHON_BIN="$(resolve_python)"
        if "${PYTHON_BIN}" "${SCRIPT_DIR}/wait_for_db.py" --timeout 3 --interval 1 >/dev/null 2>&1; then
            echo "Database: READY (connection verified)"
        else
            echo "Database: NOT READY or UNREACHABLE"
        fi

        # 3. Collector Health Snapshot
        echo ""
        echo "-- Collector Health Snapshot --"
        HEALTH_FILE="$(get_collector_health_file)"
        if [ -f "${HEALTH_FILE}" ]; then
            cat "${HEALTH_FILE}"
        else
            echo "No active collector health file found at ${HEALTH_FILE}"
        fi

        # 4. API Probe
        echo ""
        echo "-- API Probe --"
        if command -v curl >/dev/null 2>&1; then
            API_OUT="$(curl -s --max-time 3 http://127.0.0.1:8000/api/status 2>/dev/null || true)"
            if [ -n "${API_OUT}" ]; then
                echo "${API_OUT}"
            else
                echo "Backend API not responding on http://127.0.0.1:8000/api/status"
            fi
        else
            echo "curl not found, skipping API probe"
        fi
        echo ""
        ;;
    secure-permissions)
        if [ "$(id -u)" -ne 0 ]; then
            echo "Error: 'secure-permissions' requires root/sudo privileges." >&2
            exit 1
        fi
        apply_secure_permissions "${2:-/opt/osiris}"
        ;;
    install)
        if [ "$(id -u)" -ne 0 ]; then
            echo "Error: 'install' requires root/sudo privileges." >&2
            exit 1
        fi

        TARGET_DIR="/opt/osiris"

        # Verify deployment path /opt/osiris
        if [ "${PROJECT_ROOT}" != "${TARGET_DIR}" ]; then
            echo "Notice: Current source directory is ${PROJECT_ROOT}."
            if [ ! -d "${TARGET_DIR}" ]; then
                echo "Error: Target deployment directory ${TARGET_DIR} does not exist." >&2
                echo "OSIRIS systemd units are configured for ${TARGET_DIR}." >&2
                echo "Please deploy OSIRIS into ${TARGET_DIR} before installing systemd units." >&2
                exit 1
            fi
        fi

        # Refuse to operate if /opt/osiris exists but is an unrelated checkout
        if [ ! -f "${TARGET_DIR}/alembic.ini" ] || [ ! -f "${TARGET_DIR}/backend/main.py" ] || [ ! -f "${TARGET_DIR}/collectors/supervisor.py" ]; then
            echo "Error: Directory ${TARGET_DIR} exists but is missing OSIRIS markers. Refusing to operate on unrelated directory." >&2
            exit 1
        fi

        apply_secure_permissions "${TARGET_DIR}"

        echo "Installing OSIRIS systemd service units to /etc/systemd/system/..."
        cp "${PROJECT_ROOT}/deployment/systemd/osiris-backend.service" /etc/systemd/system/
        cp "${PROJECT_ROOT}/deployment/systemd/osiris-collector.service" /etc/systemd/system/
        cp "${PROJECT_ROOT}/deployment/systemd/osiris.target" /etc/systemd/system/
        systemctl daemon-reload
        systemctl enable osiris.target osiris-backend.service osiris-collector.service
        echo "Installation complete. Start with: sudo systemctl start osiris.target"
        ;;
    *)
        usage
        ;;
esac
