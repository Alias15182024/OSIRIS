#!/usr/bin/env python3
"""OSIRIS Deployment Environment Preflight Validator.

Enforces fail-closed configuration security for deployed OSIRIS services:
- Verifies /opt/osiris/.env exists as a regular file with restrictive
  permissions (0600/0640).
- Verifies file ownership matches expected service user ('osiris') or root.
- Requires explicit OSIRIS_DEBUG=false.
- Requires explicit, strong OSIRIS_SECRET_KEY (minimum 32 characters,
  no placeholders).
- Requires explicit OSIRIS_DATABASE_URL pointing to a dedicated PostgreSQL
  database.
- Strictly rejects default credentials (osiris:osiris) and insecure passwords.
- Strictly rejects protected database names (osiris, osiris_phase2_review,
  osiris_phase2_demo, validation DBs).
- Masks all credentials and secrets in error messages and logs.
"""

from __future__ import annotations

import argparse
import logging
import os
import stat
import sys
from pathlib import Path
from urllib.parse import urlparse

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from backend.config import (
    KNOWN_INSECURE_SECRETS,
    PROTECTED_DATABASE_NAMES,
    sanitize_url,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] osiris.preflight: %(message)s",
)
logger = logging.getLogger("osiris.preflight")

DEFAULT_DEPLOYMENT_ENV_FILE = "/opt/osiris/.env"


def parse_env_file(file_path: Path) -> dict[str, str]:
    """Parse environment variables from a .env file securely."""
    env_vars: dict[str, str] = {}
    content = file_path.read_text(encoding="utf-8")
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, sep, val = line.partition("=")
        key = key.strip()
        val = val.strip()
        # Remove surrounding quotes if present
        if len(val) >= 2 and (
            (val.startswith('"') and val.endswith('"'))
            or (val.startswith("'") and val.endswith("'"))
        ):
            val = val[1:-1]
        if key:
            env_vars[key] = val
    return env_vars


def validate_deployment_environment(
    env_file_path: str | Path = DEFAULT_DEPLOYMENT_ENV_FILE,
    strict_ownership: bool = True,
) -> tuple[bool, list[str]]:
    """Validate deployment environment configuration fail-closed.

    Returns (is_valid, list_of_errors).
    All error messages are guaranteed not to expose secret values.
    """
    errors: list[str] = []
    path = Path(env_file_path)

    # 1. File existence and type verification
    if not path.exists():
        errors.append(
            f"Mandatory deployment environment file does not exist: {path}. "
            "Startup cannot proceed without an explicit environment file."
        )
        return False, errors

    try:
        lstat_result = os.lstat(str(path))
    except OSError as exc:
        errors.append(f"Cannot inspect environment file {path}: {exc}")
        return False, errors

    if stat.S_ISLNK(lstat_result.st_mode):
        errors.append(
            f"Environment file {path} is a symlink. Symlinks are strictly "
            "prohibited for deployment environment files."
        )
        return False, errors

    if not stat.S_ISREG(lstat_result.st_mode):
        errors.append(f"Environment file {path} is not a regular file.")
        return False, errors

    # 2. File permissions verification
    file_mode = lstat_result.st_mode & 0o777
    # Owner must have read permission
    if (file_mode & 0o400) == 0:
        errors.append(
            f"Environment file {path} is not owner-readable ({oct(file_mode)}). "
            "Owner read permission is mandatory."
        )
    # World permissions must be 0
    if (file_mode & 0o007) != 0:
        errors.append(
            f"Environment file {path} has insecure world permissions "
            f"({oct(file_mode)}). World permissions must be 0 "
            "(e.g., mode 0600 or 0640)."
        )
    # Group must not be writable
    if (file_mode & 0o020) != 0:
        errors.append(
            f"Environment file {path} is group-writable ({oct(file_mode)}). "
            "Group write permission is prohibited."
        )
    # Execute bits must not be set
    if (file_mode & 0o111) != 0:
        errors.append(
            f"Environment file {path} has execute permissions ({oct(file_mode)}). "
            "Execute permission is prohibited on environment files."
        )

    # 3. File ownership verification
    if strict_ownership:
        osiris_uid: int | None = None
        osiris_gid: int | None = None
        try:
            import pwd

            osiris_pw = pwd.getpwnam("osiris")
            osiris_uid = osiris_pw.pw_uid
            osiris_gid = osiris_pw.pw_gid
        except (KeyError, ImportError, Exception):
            pass

        file_uid = lstat_result.st_uid
        file_gid = lstat_result.st_gid
        current_uid = os.geteuid() if hasattr(os, "geteuid") else 0

        if osiris_uid is not None:
            # On systems where user 'osiris' exists (Ubuntu deployment):
            # The file MUST be owned by root (UID 0) to prevent the unprivileged
            # backend user 'osiris' from modifying the production configuration.
            if file_uid != 0:
                errors.append(
                    f"Environment file {path} is owned by UID {file_uid}. "
                    "Production environment configuration must be owned by 'root' "
                    f"(UID 0) to prevent the backend user 'osiris' (UID {osiris_uid}) "
                    "from modifying it."
                )
            if osiris_gid is not None and (
                file_gid != osiris_gid or (file_mode & 0o040) == 0
            ):
                errors.append(
                    f"Environment file {path} owned by root must have group 'osiris' "
                    f"(GID {osiris_gid}) and group-read permission (mode 0640) "
                    "so the backend service can read it."
                )
        else:
            # On systems where user 'osiris' does not exist (dev workstation):
            # File must be owned by current user or root
            if file_uid not in (0, current_uid):
                errors.append(
                    f"Environment file {path} is owned by unexpected UID {file_uid}."
                )

    # 4. Read access check
    if not os.access(str(path), os.R_OK):
        errors.append(
            f"Environment file {path} is not readable by process (UID {os.geteuid()})."
        )
        return False, errors

    # 5. Parse environment variables directly from file
    # (ambient os.environ must NOT mask missing file keys)
    try:
        env_vars = parse_env_file(path)
    except Exception as exc:
        errors.append(f"Failed to parse environment file {path}: {exc}")
        return False, errors

    # 6. Validate OSIRIS_DEBUG
    raw_debug = env_vars.get("OSIRIS_DEBUG")
    if raw_debug is None or not raw_debug.strip():
        errors.append(
            "OSIRIS_DEBUG is not defined. Deployed service requires explicit "
            "OSIRIS_DEBUG=false."
        )
    else:
        norm_debug = raw_debug.strip().lower()
        if norm_debug not in ("false", "0", "no", "off"):
            errors.append(
                "OSIRIS_DEBUG must be explicitly set to 'false' for deployed service "
                f"(found: '{norm_debug}'). Debug mode is strictly prohibited "
                "in deployment."
            )

    # 7. Validate OSIRIS_SECRET_KEY
    raw_secret = env_vars.get("OSIRIS_SECRET_KEY")
    if not raw_secret or not raw_secret.strip():
        errors.append(
            "OSIRIS_SECRET_KEY is missing or empty. A cryptographically strong "
            "signing secret must be provided."
        )
    else:
        norm_secret = raw_secret.strip().lower()
        if norm_secret in KNOWN_INSECURE_SECRETS:
            errors.append(
                "OSIRIS_SECRET_KEY matches a known insecure or placeholder "
                "secret template."
            )
        elif len(raw_secret.strip()) < 32:
            errors.append(
                f"OSIRIS_SECRET_KEY is too short ({len(raw_secret.strip())} chars). "
                "Minimum required length for deployment is 32 characters."
            )
        elif "change-me" in norm_secret or "changeme" in norm_secret:
            errors.append("OSIRIS_SECRET_KEY contains placeholder template markers.")

    # 8. Validate OSIRIS_DATABASE_URL
    raw_db_url = env_vars.get("OSIRIS_DATABASE_URL")
    if not raw_db_url or not raw_db_url.strip():
        errors.append(
            "OSIRIS_DATABASE_URL is missing or empty. An explicit database "
            "connection URL is mandatory for deployment."
        )
    else:
        raw_db_url = raw_db_url.strip()
        safe_url = sanitize_url(raw_db_url)

        try:
            from sqlalchemy.engine import make_url

            parsed_url = make_url(raw_db_url)
            driver = parsed_url.drivername.lower()
            db_name = (parsed_url.database or "").strip().lower()
            username = parsed_url.username or ""
            password = parsed_url.password or ""
        except Exception:
            u = urlparse(raw_db_url)
            driver = u.scheme.lower()
            db_name = u.path.lstrip("/").strip().lower()
            username = u.username or ""
            password = u.password or ""

        # Scheme check
        if not driver.startswith("postgresql"):
            errors.append(
                f"OSIRIS_DATABASE_URL scheme '{driver}' is invalid for deployment. "
                "Production deployment requires a PostgreSQL connection (postgresql://)."
            )

        # Database name check
        if not db_name:
            errors.append(
                "OSIRIS_DATABASE_URL does not specify a target database name "
                f"({safe_url})."
            )
        elif (
            db_name in PROTECTED_DATABASE_NAMES
            or "validation" in db_name
            or "phase2_review" in db_name
            or "phase2_demo" in db_name
        ):
            errors.append(
                f"OSIRIS_DATABASE_URL targets protected database '{db_name}'. "
                "Deployment requires a dedicated, disposable database name."
            )

        # Credential checks
        if not username or not password:
            errors.append(
                "OSIRIS_DATABASE_URL must specify explicit non-empty credentials "
                f"({safe_url})."
            )
        else:
            norm_user = username.strip().lower()
            norm_pass = password.strip().lower()

            if norm_user == "osiris" and norm_pass == "osiris":
                errors.append(
                    "OSIRIS_DATABASE_URL uses default database credentials "
                    "('osiris:osiris'). Default credentials are strictly rejected "
                    "in deployment."
                )
            if norm_pass in KNOWN_INSECURE_SECRETS:
                errors.append(
                    "OSIRIS_DATABASE_URL uses a known insecure or placeholder "
                    "database password."
                )
            trivial_users = ("admin", "root", "test", "osiris", "guest")
            if norm_user == norm_pass and norm_user in trivial_users:
                errors.append(
                    "OSIRIS_DATABASE_URL uses trivial identical username and password."
                )

    # 9. Validate CORS configuration (no wildcard in production/deployment)
    raw_cors = env_vars.get("OSIRIS_CORS_ALLOWED_ORIGINS")
    if raw_cors is not None:
        raw_cors_trimmed = raw_cors.strip()
        if not raw_cors_trimmed:
            errors.append(
                "OSIRIS_CORS_ALLOWED_ORIGINS is defined but empty. "
                "Explicit allowed origins are required."
            )
        else:
            cors_list = [o.strip() for o in raw_cors_trimmed.split(",") if o.strip()]
            if not cors_list:
                errors.append("OSIRIS_CORS_ALLOWED_ORIGINS contains no valid origins.")
            elif "*" in cors_list:
                errors.append(
                    "Wildcard CORS origin '*' is strictly prohibited in deployment. "
                    "Configure explicit allowed origins via "
                    "OSIRIS_CORS_ALLOWED_ORIGINS."
                )

    return len(errors) == 0, errors


def main() -> None:
    parser = argparse.ArgumentParser(
        description="OSIRIS Deployment Environment Preflight Validator"
    )
    parser.add_argument(
        "--env-file",
        type=str,
        default=DEFAULT_DEPLOYMENT_ENV_FILE,
        help=(
            "Path to deployment environment file "
            f"(default: {DEFAULT_DEPLOYMENT_ENV_FILE})"
        ),
    )
    parser.add_argument(
        "--strict-ownership",
        action="store_true",
        default=True,
        help="Enforce strict file ownership checks (default: True)",
    )
    parser.add_argument(
        "--no-strict-ownership",
        action="store_false",
        dest="strict_ownership",
        help="Disable strict ownership checks (for non-root testing)",
    )
    args = parser.parse_args()

    logger.info(
        "Running deployment environment preflight check on %s...", args.env_file
    )
    is_valid, errors = validate_deployment_environment(
        env_file_path=args.env_file,
        strict_ownership=args.strict_ownership,
    )

    if not is_valid:
        logger.error(
            "Deployment preflight validation FAILED with %d error(s):", len(errors)
        )
        for err in errors:
            logger.error("  - %s", err)
        sys.exit(1)

    logger.info("Deployment preflight validation PASSED cleanly.")
    sys.exit(0)


if __name__ == "__main__":
    main()
