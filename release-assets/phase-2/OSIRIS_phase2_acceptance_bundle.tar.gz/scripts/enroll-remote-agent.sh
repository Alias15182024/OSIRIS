#!/usr/bin/env bash
# OSIRIS Remote Host Agent Enrollment Script
set -euo pipefail

CENTRAL_URL="${1:-}"
CENTRAL_URL="${CENTRAL_URL%/}"
HOST_NAME="${2:-$(hostname)}"

if [ -z "${CENTRAL_URL}" ]; then
    echo "Usage: $0 <central_osiris_url> [hostname]"
    echo "Example: $0 https://osiris.example.com srv-prod-web01"
    exit 1
fi

echo "=========================================="
echo "    OSIRIS REMOTE AGENT ENROLLMENT        "
echo "=========================================="
echo "Connecting to Central OSIRIS at: ${CENTRAL_URL}"
echo "Registering host as: ${HOST_NAME}"

# Probe central endpoint
if ! curl -fsSL "${CENTRAL_URL}/health" >/dev/null 2>&1; then
    echo "Error: Unable to connect to central OSIRIS instance at ${CENTRAL_URL}/health" >&2
    exit 1
fi

echo "Connection verified. Configuring endpoint identity..."
cat <<EOF
[OK] Agent enrollment package prepared.
To complete registration, add host configuration to /etc/osiris/agent.conf:
  OSIRIS_CENTRAL_URL="${CENTRAL_URL}"
  OSIRIS_HOSTNAME="${HOST_NAME}"

Then start the agent:
  systemctl start osiris-agent.service
EOF
