#!/usr/bin/env python3
"""Database dependency readiness checker for OSIRIS startup lifecycle."""

from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import create_engine, text

from backend.config import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] osiris.startup: %(message)s",
)
logger = logging.getLogger("osiris.startup.wait_for_db")


def sanitize_url(url: str) -> str:
    """Mask password in database URL for safe logging."""
    if "@" in url and "://" in url:
        scheme_user, host_db = url.split("@", 1)
        if ":" in scheme_user:
            scheme, _ = scheme_user.rsplit(":", 1)
            return f"{scheme}:***@{host_db}"
    return url


def wait_for_database(
    max_wait_seconds: float = 60.0, retry_interval: float = 2.0
) -> bool:
    """Poll the configured database until connection succeeds or timeout expires."""
    db_url = settings.database_url
    if not db_url:
        logger.error(
            "Database connection URL is not configured. "
            "Please configure OSIRIS_DATABASE_URL in the environment or /opt/osiris/.env."
        )
        return False
    safe_url = sanitize_url(db_url)
    logger.info("Verifying database readiness at %s...", safe_url)

    engine = create_engine(db_url, pool_pre_ping=True)
    start_time = time.monotonic()

    while True:
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            elapsed = round(time.monotonic() - start_time, 2)
            logger.info("Database is READY and reachable (elapsed: %ss).", elapsed)
            engine.dispose()
            return True
        except Exception as exc:
            elapsed = time.monotonic() - start_time
            if elapsed >= max_wait_seconds:
                logger.error(
                    "Database readiness timeout (%ss). Failed to connect to %s: %s",
                    max_wait_seconds,
                    safe_url,
                    exc.__class__.__name__,
                )
                engine.dispose()
                return False

            logger.warning(
                "Database not ready yet (%s). Retrying in %ss...",
                exc.__class__.__name__,
                retry_interval,
            )
            time.sleep(retry_interval)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Wait for OSIRIS database to become ready."
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=60.0,
        help="Maximum wait time in seconds (default: 60.0s).",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=2.0,
        help="Retry poll interval in seconds (default: 2.0s).",
    )
    args = parser.parse_args()

    ready = wait_for_database(
        max_wait_seconds=args.timeout, retry_interval=args.interval
    )
    if not ready:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
